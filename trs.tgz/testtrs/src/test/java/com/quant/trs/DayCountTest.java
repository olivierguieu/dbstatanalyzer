package com.quant.trs;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DayCountTest {

    private static final double EPS = 1e-9;

    @Test
    void act360CountsActualDaysOver360() {
        LocalDate s = LocalDate.of(2026, 5, 20);
        LocalDate e = LocalDate.of(2026, 8, 20);   // 92 actual days
        assertEquals(92.0 / 360.0, DayCount.fraction(s, e, DayCountConvention.ACT_360), EPS);
    }

    @Test
    void act365CountsActualDaysOver365() {
        LocalDate s = LocalDate.of(2026, 5, 20);
        LocalDate e = LocalDate.of(2026, 8, 20);   // 92 actual days
        assertEquals(92.0 / 365.0, DayCount.fraction(s, e, DayCountConvention.ACT_365), EPS);
    }

    @Test
    void thirty360TreatsEachMonthAs30Days() {
        LocalDate s = LocalDate.of(2026, 5, 20);
        LocalDate e = LocalDate.of(2026, 8, 20);   // exactly 3 * 30 days
        assertEquals(90.0 / 360.0, DayCount.fraction(s, e, DayCountConvention.THIRTY_360), EPS);
    }

    @Test
    void thirty360AdjustsDay31OfStartTo30() {
        LocalDate s = LocalDate.of(2026, 1, 31);
        LocalDate e = LocalDate.of(2026, 2, 28);   // d1 31->30, d2 28 : 30 + (28-30) = 28
        assertEquals(28.0 / 360.0, DayCount.fraction(s, e, DayCountConvention.THIRTY_360), EPS);
    }

    @Test
    void thirty360AdjustsDay31OfEndWhenStartIs30() {
        LocalDate s = LocalDate.of(2026, 1, 31);   // d1 -> 30
        LocalDate e = LocalDate.of(2026, 7, 31);   // d2 31, d1==30 -> d2 30
        assertEquals(180.0 / 360.0, DayCount.fraction(s, e, DayCountConvention.THIRTY_360), EPS);
    }

    @Test
    void fractionIsZeroForIdenticalDates() {
        LocalDate d = LocalDate.of(2026, 5, 20);
        assertEquals(0.0, DayCount.fraction(d, d, DayCountConvention.ACT_360), EPS);
    }
}
