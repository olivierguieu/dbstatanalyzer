package com.quant.trs;

/**
 * Domain enumerations for the TRS Equity cashflow generator.
 * Kept package-private in a single file; the whole application lives in one package.
 */

/** Direction of a cashflow from the booking party's perspective. */
enum PayReceive { PAY, RECEIVE }

/** The leg a cashflow belongs to. */
enum LegType { FUNDING, EQUITY_PERFORMANCE, DIVIDEND }

/** Whether the booking party receives or pays the equity total return. */
enum EquityReturnDirection { RECEIVE, PAY }

/** Accrual day count conventions supported for the funding leg. */
enum DayCountConvention { ACT_360, ACT_365, THIRTY_360 }

/** Payment / reset frequency. AT_TERMINATION produces a single period. */
enum Frequency {
    MONTHLY(1), QUARTERLY(3), SEMI_ANNUAL(6), ANNUAL(12), AT_TERMINATION(0);

    /** Number of months between dates; 0 means a single period to termination. */
    final int months;

    Frequency(int months) { this.months = months; }
}
