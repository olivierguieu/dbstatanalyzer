package com.quant.trs;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CashflowGeneratorTest {

    private static final double EPS = 1e-6;

    /** A trade: 100,000 shares @ 50.00, 1Y, quarterly funding at 3.70% all-in. */
    private TrsTrade baseTrade() {
        TrsTrade t = new TrsTrade();
        t.tradeId = "TRS-TEST";
        t.counterparty = "CP";
        t.underlyingName = "ACME";
        t.currency = "EUR";
        t.numberOfShares = 100_000;
        t.initialPrice = 50.0;
        t.tradeDate = LocalDate.of(2026, 5, 18);
        t.effectiveDate = LocalDate.of(2026, 5, 20);
        t.terminationDate = LocalDate.of(2027, 5, 20);
        t.equityReturnDirection = EquityReturnDirection.RECEIVE;
        t.referenceIndex = "EURIBOR-3M";
        t.indexRate = 0.032;
        t.spread = 0.005;
        t.dayCountConvention = DayCountConvention.ACT_360;
        t.fundingFrequency = Frequency.QUARTERLY;
        t.equityResetFrequency = Frequency.AT_TERMINATION;
        t.dividendPassThrough = 1.0;
        return t;
    }

    private List<Cashflow> ofLeg(List<Cashflow> all, LegType leg) {
        return all.stream().filter(c -> c.legType == leg).collect(Collectors.toList());
    }

    @Test
    void fundingLegHasOneCashflowPerQuarter() {
        List<Cashflow> funding = ofLeg(new CashflowGenerator().generate(baseTrade()), LegType.FUNDING);
        assertEquals(4, funding.size());
    }

    @Test
    void fundingAmountUsesNotionalRateAndDayCountFraction() {
        Cashflow cf = ofLeg(new CashflowGenerator().generate(baseTrade()), LegType.FUNDING).get(0);
        double expected = 5_000_000.0 * 0.037 * cf.dayCountFraction;
        assertEquals(0.037, cf.rate, EPS);
        assertEquals(5_000_000.0, cf.nominal, EPS);
        assertEquals(expected, Math.abs(cf.amount), 1e-4);
    }

    @Test
    void receiverOfEquityPaysTheFundingLeg() {
        Cashflow cf = ofLeg(new CashflowGenerator().generate(baseTrade()), LegType.FUNDING).get(0);
        assertSame(PayReceive.PAY, cf.payReceive);
        assertTrue(cf.amount < 0, "funding amount must be negative for the equity receiver");
    }

    @Test
    void payingEquityReturnFlipsAllSigns() {
        TrsTrade t = baseTrade();
        t.equityReturnDirection = EquityReturnDirection.PAY;
        List<Cashflow> cfs = new CashflowGenerator().generate(t);

        Cashflow funding = ofLeg(cfs, LegType.FUNDING).get(0);
        assertSame(PayReceive.RECEIVE, funding.payReceive);
        assertTrue(funding.amount > 0, "funding is received when we pay the equity return");
    }

    @Test
    void equityPerformanceAmountIsSharesTimesPriceChange() {
        TrsTrade t = baseTrade();
        t.priceFixings.add(new PriceFixing(t.terminationDate, 58.0));
        Cashflow cf = ofLeg(new CashflowGenerator().generate(t), LegType.EQUITY_PERFORMANCE).get(0);

        assertEquals(50.0, cf.priceStart, EPS);
        assertEquals(58.0, cf.priceEnd, EPS);
        assertEquals(100_000 * (58.0 - 50.0), cf.amount, EPS);
        assertSame(PayReceive.RECEIVE, cf.payReceive);
    }

    @Test
    void equityPerformanceIsZeroWhenNoFinalFixingSupplied() {
        Cashflow cf = ofLeg(new CashflowGenerator().generate(baseTrade()), LegType.EQUITY_PERFORMANCE).get(0);
        assertEquals(0.0, cf.amount, EPS);
    }

    @Test
    void dividendInScopeProducesPassThroughCashflow() {
        TrsTrade t = baseTrade();
        t.dividends.add(new DividendEvent(LocalDate.of(2026, 9, 15), 1.25));
        List<Cashflow> divs = ofLeg(new CashflowGenerator().generate(t), LegType.DIVIDEND);

        assertEquals(1, divs.size());
        assertEquals(100_000 * 1.25, divs.get(0).amount, EPS);
    }

    @Test
    void dividendPassThroughRatioScalesTheAmount() {
        TrsTrade t = baseTrade();
        t.dividendPassThrough = 0.7;
        t.dividends.add(new DividendEvent(LocalDate.of(2026, 9, 15), 1.25));
        Cashflow cf = ofLeg(new CashflowGenerator().generate(t), LegType.DIVIDEND).get(0);
        assertEquals(100_000 * 1.25 * 0.7, cf.amount, EPS);
    }

    @Test
    void dividendsOutsideTheTradeWindowAreIgnored() {
        TrsTrade t = baseTrade();
        t.dividends.add(new DividendEvent(t.effectiveDate.minusDays(1), 1.0));
        t.dividends.add(new DividendEvent(t.terminationDate.plusDays(1), 1.0));
        assertTrue(ofLeg(new CashflowGenerator().generate(t), LegType.DIVIDEND).isEmpty());
    }

    @Test
    void cashflowsAreSortedByPaymentDate() {
        TrsTrade t = baseTrade();
        t.dividends.add(new DividendEvent(LocalDate.of(2026, 9, 15), 1.25));
        List<Cashflow> cfs = new CashflowGenerator().generate(t);
        for (int i = 1; i < cfs.size(); i++) {
            assertTrue(!cfs.get(i).paymentDate.isBefore(cfs.get(i - 1).paymentDate),
                    "cashflows must be ordered by payment date");
        }
    }
}
