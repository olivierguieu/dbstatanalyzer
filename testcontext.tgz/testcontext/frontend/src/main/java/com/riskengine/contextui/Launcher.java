package com.riskengine.contextui;

public class Launcher {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
