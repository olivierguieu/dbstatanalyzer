package com.riskengine.context.dto;

import com.riskengine.context.entity.Context;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContextDto {
    private Long id;
    private LocalDate fromDate;
    private LocalDate endDate;
    private String label;

    public static ContextDto from(Context c) {
        return ContextDto.builder()
                .id(c.getId())
                .fromDate(c.getFromDate())
                .endDate(c.getEndDate())
                .label(c.getLabel())
                .build();
    }
}
