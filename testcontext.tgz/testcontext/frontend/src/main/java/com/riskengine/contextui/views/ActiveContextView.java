package com.riskengine.contextui.views;

import com.riskengine.contextui.ApiClient;
import com.riskengine.contextui.AsyncUtil;
import com.riskengine.contextui.Models.ContextDto;
import com.riskengine.contextui.Models.ContextVersions;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.function.Consumer;

public class ActiveContextView extends VBox {

    private final ApiClient api;
    private final DatePicker datePicker = new DatePicker(LocalDate.now());
    private final Label result = new Label();
    private final Label versions = new Label();
    private final Button openDetailBtn = new Button("Open detail");
    private Long resolvedId = null;

    public ActiveContextView(ApiClient api, Consumer<Long> openDetail) {
        this.api = api;
        setSpacing(10);
        setPadding(new Insets(12));

        Label title = new Label("Active context for a date");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Button find = new Button("Find");
        find.setOnAction(e -> search());
        openDetailBtn.setDisable(true);
        openDetailBtn.setOnAction(e -> {
            if (resolvedId != null) openDetail.accept(resolvedId);
        });

        HBox row = new HBox(8, new Label("Date:"), datePicker, find, openDetailBtn);
        result.setStyle("-fx-font-size: 14px;");

        getChildren().addAll(title, row, result, versions);
    }

    private void search() {
        result.setText("Searching…");
        versions.setText("");
        openDetailBtn.setDisable(true);
        LocalDate target = datePicker.getValue();
        if (target == null) {
            result.setText("Pick a date first.");
            return;
        }
        AsyncUtil.run(() -> api.getActive(target),
                ctx -> {
                    resolvedId = ctx.id();
                    result.setText("Context #" + ctx.id() + " — " + ctx.label()
                            + "  (from " + ctx.fromDate() + ", end "
                            + (ctx.endDate() == null ? "—" : ctx.endDate()) + ")");
                    openDetailBtn.setDisable(false);
                    AsyncUtil.run(() -> api.versions(ctx.id()),
                            (ContextVersions v) -> versions.setText("Versions: " + v.versions()),
                            err -> versions.setText("Couldn't load versions: " + err.getMessage()));
                },
                err -> {
                    if (err instanceof ApiClient.ApiException ae && ae.status() == 404) {
                        result.setText("No active context for that date.");
                    } else {
                        result.setText("Failed: " + err.getMessage());
                    }
                });
    }
}
