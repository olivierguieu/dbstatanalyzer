package com.example.mdx;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

import org.olap4j.CellSet;
import org.olap4j.OlapConnection;
import org.olap4j.OlapStatement;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 * Minimal JavaFX app that runs an MDX query against SSAS via olap4j (XMLA) and
 * renders the result in a {@link TableView}.
 *
 * <p><b>Authentication:</b> none is passed in code. The app relies on the JVM's
 * native Kerberos/SPNEGO support (the same {@code -Djava.security.krb5.conf},
 * {@code -Djava.security.auth.login.config}, {@code -Djavax.security.auth.useSubjectCredsOnly=false}
 * flags proven by the kerberos-smoketest). Run it via {@code mvn javafx:run},
 * which sets those flags from the pom.
 *
 * <p>Endpoint, catalog and MDX can be overridden via JavaFX args (arg 0 = endpoint,
 * arg 1 = catalog) or the system properties {@code ssas.endpoint}, {@code ssas.catalog},
 * {@code ssas.mdx}.
 */
public class MdxTableViewApp extends Application {

    private static final String DEFAULT_ENDPOINT =
        "https://ssas.yourcorp.com/olap/msmdpump.dll";
    private static final String DEFAULT_CATALOG = "Adventure Works DW";
    private static final String DEFAULT_MDX =
        "SELECT [Measures].[Sales Amount] ON COLUMNS, "
        + "[Date].[Calendar].[Calendar Year].Members ON ROWS "
        + "FROM [Adventure Works]";

    /** Visual connection lifecycle states, each with a dot colour and label. */
    private enum ConnectionState {
        IDLE("Not connected", Color.web("#9e9e9e")),
        CONNECTING("Connecting…", Color.web("#ef6c00")),
        CONNECTED("Connected", Color.web("#2e7d32")),
        ERROR("Connection failed", Color.web("#c62828"));

        final String text;
        final Color color;

        ConnectionState(String text, Color color) {
            this.text = text;
            this.color = color;
        }
    }

    private final TableView<List<String>> tableView = new TableView<>();
    private final Label status = new Label("Ready.");
    private final TextArea mdxInput = new TextArea();

    // Connection status indicator (top-right of the window).
    private final Circle statusDot = new Circle(7, ConnectionState.IDLE.color);
    private final Label connLabel = new Label(ConnectionState.IDLE.text);

    private String endpoint;
    private String catalog;

    @Override
    public void init() {
        List<String> args = getParameters().getRaw();
        endpoint = args.size() > 0 ? args.get(0)
            : System.getProperty("ssas.endpoint", DEFAULT_ENDPOINT);
        catalog = args.size() > 1 ? args.get(1)
            : System.getProperty("ssas.catalog", DEFAULT_CATALOG);
    }

    @Override
    public void start(Stage stage) {
        mdxInput.setText(System.getProperty("ssas.mdx", DEFAULT_MDX));
        mdxInput.setPrefRowCount(4);
        mdxInput.setWrapText(true);

        Button run = new Button("Run MDX");
        run.setOnAction(e -> runQuery(run));

        // Header row: endpoint label on the left, connection indicator pinned right.
        Label endpointLabel = new Label("MDX (endpoint: " + endpoint + "):");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox indicator = new HBox(6, statusDot, connLabel);
        indicator.setAlignment(Pos.CENTER_RIGHT);
        HBox header = new HBox(10, endpointLabel, spacer, indicator);
        header.setAlignment(Pos.CENTER_LEFT);

        VBox top = new VBox(6, header, mdxInput, run);
        top.setPadding(new Insets(10));

        BorderPane root = new BorderPane();
        root.setTop(top);
        root.setCenter(tableView);
        root.setBottom(status);
        BorderPane.setMargin(status, new Insets(6, 10, 8, 10));

        stage.setScene(new Scene(root, 900, 600));
        stage.setTitle("MDX → SSAS → JavaFX");
        stage.show();
    }

    /** Runs the query off the FX thread so the UI never freezes on network I/O. */
    private void runQuery(Button trigger) {
        final String mdx = mdxInput.getText();
        trigger.setDisable(true);
        status.setText("Connecting and executing…");
        setConnectionState(ConnectionState.CONNECTING);

        // Tracks whether the connection actually opened, so a later query-only
        // failure doesn't mislabel the connection indicator as failed.
        final AtomicBoolean connected = new AtomicBoolean(false);

        Task<CellSetFlattener.Table> task = new Task<>() {
            @Override
            protected CellSetFlattener.Table call() throws Exception {
                return execute(mdx, () -> {
                    connected.set(true);
                    setConnectionState(ConnectionState.CONNECTED);
                });
            }
        };

        task.setOnSucceeded(e -> {
            populate(task.getValue());
            status.setText("Done: " + task.getValue().rows.size() + " row(s).");
            trigger.setDisable(false);
        });
        task.setOnFailed(e -> {
            Throwable ex = task.getException();
            status.setText("ERROR: " + ex.getClass().getSimpleName() + ": " + ex.getMessage());
            // Red dot only if we never connected; a query error leaves the link green.
            if (!connected.get()) {
                setConnectionState(ConnectionState.ERROR);
            }
            trigger.setDisable(false);
        });

        Thread t = new Thread(task, "mdx-query");
        t.setDaemon(true);
        t.start();
    }

    /**
     * @param onConnected run once the olap4j connection is established (off the FX
     *                    thread); used to flip the indicator to CONNECTED.
     */
    private CellSetFlattener.Table execute(String mdx, Runnable onConnected) throws Exception {
        Class.forName("org.olap4j.driver.xmla.XmlaOlap4jDriver");

        // No User/Password: the JVM negotiates Kerberos on the underlying HttpURLConnection.
        Properties props = new Properties();
        props.put("Catalog", catalog);

        String url = "jdbc:xmla:Server=" + endpoint;
        try (Connection connection = DriverManager.getConnection(url, props);
             OlapConnection olap = connection.unwrap(OlapConnection.class);
             OlapStatement statement = olap.createStatement()) {

            olap.setCatalog(catalog);
            onConnected.run();
            CellSet cellSet = statement.executeOlapQuery(mdx);
            // Flatten while the connection/cellSet are still open; the result is detached.
            return CellSetFlattener.flatten(cellSet);
        }
    }

    /** Updates the connection indicator; safe to call from any thread. */
    private void setConnectionState(ConnectionState state) {
        Runnable apply = () -> {
            statusDot.setFill(state.color);
            connLabel.setText(state.text);
        };
        if (Platform.isFxApplicationThread()) {
            apply.run();
        } else {
            Platform.runLater(apply);
        }
    }

    /** Rebuilds the TableView columns and data from a flattened table. */
    private void populate(CellSetFlattener.Table table) {
        tableView.getColumns().clear();

        // Column 0: the row-member labels.
        TableColumn<List<String>, String> rowHeaderCol = new TableColumn<>(
            table.rowAxisHeader.isEmpty() ? " " : table.rowAxisHeader);
        rowHeaderCol.setCellValueFactory(cd -> cellAt(cd.getValue(), 0));
        rowHeaderCol.setPrefWidth(220);
        tableView.getColumns().add(rowHeaderCol);

        // One column per measure/COLUMNS-axis position. Data list index is offset by 1.
        for (int i = 0; i < table.columnHeaders.size(); i++) {
            final int dataIndex = i + 1;
            TableColumn<List<String>, String> col = new TableColumn<>(table.columnHeaders.get(i));
            col.setCellValueFactory(cd -> cellAt(cd.getValue(), dataIndex));
            tableView.getColumns().add(col);
        }

        ObservableList<List<String>> data = FXCollections.observableArrayList(table.rows);
        tableView.setItems(data);
    }

    /** Read-only cell value binding that tolerates short rows. */
    private static javafx.beans.value.ObservableValue<String> cellAt(List<String> row, int index) {
        String value = index < row.size() ? row.get(index) : "";
        return new javafx.beans.property.ReadOnlyStringWrapper(value);
    }

    public static void main(String[] args) {
        // Surface an early, friendly hint if the Kerberos flags weren't set.
        if (System.getProperty("java.security.auth.login.config") == null) {
            System.err.println("[warn] java.security.auth.login.config is not set — "
                + "Kerberos will likely fail. Run via 'mvn javafx:run' or pass the JVM flags "
                + "from kerberos-smoketest/README.md.");
        }
        launch(args);
    }
}
