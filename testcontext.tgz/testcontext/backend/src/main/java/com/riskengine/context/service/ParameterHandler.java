package com.riskengine.context.service;

import java.util.List;
import java.util.Map;

/**
 * Contract for a parameter table. Each Spring bean implementing this interface
 * is auto-registered with {@link ContextService}, so adding a new parameter
 * table just means adding a new bean — no change to ContextService is needed.
 */
public interface ParameterHandler {

    /** Unique identifier used in URLs and the association table. */
    String name();

    /** Field descriptors for dynamic forms / schema discovery. */
    List<FieldSpec> schema();

    /** Persist a brand-new version row and return its version id. */
    Long saveNewVersion(Map<String, Object> payload);

    /** Read a version row back as a plain map (field name → value). */
    Map<String, Object> read(Long versionId);

    record FieldSpec(String name, String type, boolean required) {}
}
