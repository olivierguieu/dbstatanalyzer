package com.quant.trs;

import java.time.LocalDate;

/** A declared dividend on the underlying equity, passed through on the equity leg. */
public class DividendEvent {

    public final LocalDate exDate;
    public final double dividendPerShare;

    public DividendEvent(LocalDate exDate, double dividendPerShare) {
        this.exDate = exDate;
        this.dividendPerShare = dividendPerShare;
    }

    @Override
    public String toString() {
        return exDate + "  div/share=" + dividendPerShare;
    }
}
