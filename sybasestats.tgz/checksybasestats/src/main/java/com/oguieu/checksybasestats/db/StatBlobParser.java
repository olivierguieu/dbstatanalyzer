package com.oguieu.checksybasestats.db;

import com.oguieu.checksybasestats.model.ColumnInfo;
import com.oguieu.checksybasestats.model.HistogramStep;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StatBlobParser {

    // syscolumns.type codes for Sybase ASE
    public static final int TINYINT        = 48;
    public static final int SMALLINT       = 52;
    public static final int INT            = 56;
    public static final int BIGINT         = 127;
    public static final int REAL           = 59;
    public static final int FLOAT          = 62;
    public static final int MONEY          = 60;
    public static final int SMALLMONEY     = 122;
    public static final int DATETIME       = 61;
    public static final int SMALLDATETIME  = 58;
    public static final int CHAR           = 47;
    public static final int VARCHAR        = 39;
    public static final int NCHAR          = 175;
    public static final int NVARCHAR       = 167;
    public static final int BINARY         = 45;
    public static final int VARBINARY      = 37;
    public static final int NUMERIC        = 108;
    public static final int DECIMAL        = 106;
    public static final int BIT            = 50;

    public static List<HistogramStep> parse(byte[] blob, int steps, ColumnInfo col) {
        return parse(blob, steps, col, 0);
    }

    public static List<HistogramStep> parse(byte[] blob, int steps, ColumnInfo col, int blobOffset) {
        ByteBuffer buf = ByteBuffer.wrap(blob).order(ByteOrder.LITTLE_ENDIAN);
        buf.position(blobOffset);
        List<HistogramStep> result = new ArrayList<>(Math.min(steps, 512));

        for (int i = 0; i < steps && buf.remaining() >= valueSize(col) + 8; i++) {
            String value    = readValue(buf, col);
            float  eqRows   = buf.getFloat();
            float  rangeRows = buf.getFloat();
            result.add(new HistogramStep(value, eqRows, rangeRows));
        }
        return result;
    }

    public static String hexDump(byte[] blob, int maxBytes) {
        int limit = Math.min(blob.length, maxBytes);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < limit; i++) {
            if (i > 0 && i % 16 == 0) sb.append('\n');
            sb.append(String.format("%02x ", blob[i]));
        }
        sb.append(String.format("%n%n(%d bytes total)", blob.length));
        return sb.toString();
    }

    // -------------------------------------------------------------------------

    private static int valueSize(ColumnInfo col) {
        switch (col.type()) {
            case BIT:
            case TINYINT:
                return 1;
            case SMALLINT:
                return 2;
            case INT:
            case REAL:
            case SMALLMONEY:
            case SMALLDATETIME:
                return 4;
            case BIGINT:
            case FLOAT:
            case MONEY:
            case DATETIME:
                return 8;
            case NUMERIC:
            case DECIMAL:
                return numericByteCount(col.prec());
            default:
                return col.length();
        }
    }

    private static String readValue(ByteBuffer buf, ColumnInfo col) {
        try {
            switch (col.type()) {
                case BIT:
                    return String.valueOf(buf.get() != 0);
                case TINYINT:
                    return String.valueOf(Byte.toUnsignedInt(buf.get()));
                case SMALLINT:
                    return String.valueOf(buf.getShort());
                case INT:
                    return String.valueOf(buf.getInt());
                case BIGINT:
                    return String.valueOf(buf.getLong());
                case REAL:
                    return String.format("%.6g", buf.getFloat());
                case FLOAT:
                    return String.format("%.10g", buf.getDouble());
                case MONEY:
                    return String.format("%.4f", buf.getLong() / 10000.0);
                case SMALLMONEY:
                    return String.format("%.4f", buf.getInt() / 10000.0);
                case DATETIME: {
                    int days = buf.getInt();
                    int tu   = buf.getInt();
                    return formatDatetime(days, tu);
                }
                case SMALLDATETIME: {
                    int days    = Short.toUnsignedInt(buf.getShort());
                    int minutes = Short.toUnsignedInt(buf.getShort());
                    return formatSmallDatetime(days, minutes);
                }
                case CHAR:
                case NCHAR:
                case VARCHAR:
                case NVARCHAR: {
                    byte[] bytes = new byte[col.length()];
                    buf.get(bytes);
                    return rtrim(new String(bytes));
                }
                case BINARY:
                case VARBINARY: {
                    byte[] bytes = new byte[col.length()];
                    buf.get(bytes);
                    return "0x" + bytesToHex(bytes);
                }
                case NUMERIC:
                case DECIMAL: {
                    int n = numericByteCount(col.prec());
                    byte[] bytes = new byte[n];
                    buf.get(bytes);
                    return parseNumeric(bytes, col.scale());
                }
                default:
                    buf.position(buf.position() + col.length());
                    return "?[type=" + col.type() + "]";
            }
        } catch (Exception e) {
            return "!err:" + e.getMessage();
        }
    }

    private static String formatDatetime(int days, int timeUnits) {
        LocalDate date = LocalDate.of(1900, 1, 1).plusDays(days);
        int totalSecs = timeUnits / 300;
        int ms = (timeUnits % 300) * 1000 / 300;
        return String.format("%s %02d:%02d:%02d.%03d",
                date, totalSecs / 3600, (totalSecs % 3600) / 60, totalSecs % 60, ms);
    }

    private static String formatSmallDatetime(int days, int minutes) {
        LocalDate date = LocalDate.of(1900, 1, 1).plusDays(days);
        return String.format("%s %02d:%02d", date, minutes / 60, minutes % 60);
    }

    private static int numericByteCount(int prec) {
        if (prec <=  2) return  2;
        if (prec <=  4) return  3;
        if (prec <=  9) return  5;
        if (prec <= 18) return  9;
        if (prec <= 28) return 13;
        return 17;
    }

    private static String parseNumeric(byte[] bytes, int scale) {
        if (bytes.length < 2) return "?";
        boolean positive = bytes[0] == 1;
        java.math.BigInteger raw = java.math.BigInteger.ZERO;
        for (int i = bytes.length - 1; i >= 1; i--) {
            raw = raw.shiftLeft(8).or(java.math.BigInteger.valueOf(bytes[i] & 0xFF));
        }
        if (!positive) raw = raw.negate();
        if (scale == 0) return raw.toString();
        return new java.math.BigDecimal(raw, scale).toPlainString();
    }

    private static String rtrim(String s) {
        int i = s.length() - 1;
        while (i >= 0 && s.charAt(i) <= ' ') i--;
        return s.substring(0, i + 1);
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
