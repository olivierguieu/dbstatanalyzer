package com.example.mdx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.olap4j.CellSet;
import org.olap4j.CellSetAxis;
import org.olap4j.Position;
import org.olap4j.metadata.Member;

/**
 * Turns a 2-axis olap4j {@link CellSet} into a plain header + rows structure that
 * a JavaFX {@code TableView} can bind to, with no olap4j types leaking into the UI.
 *
 * <p>An MDX result is a grid: the COLUMNS axis (axis 0) defines the columns, the
 * ROWS axis (axis 1) defines the rows, and each cell is addressed by
 * (columnOrdinal, rowOrdinal). Each axis position can be a <em>tuple</em> of
 * members (crossjoins), so a header/row label may combine several captions.
 */
public final class CellSetFlattener {

    /** Immutable flattened view: column headers + the leading row-header column + data rows. */
    public static final class Table {
        /** Header for the first column (the row members); e.g. "Calendar Year". */
        public final String rowAxisHeader;
        /** Headers for the measure/data columns, one per COLUMNS-axis position. */
        public final List<String> columnHeaders;
        /** Each row: index 0 is the row-member label, then one formatted cell value per column. */
        public final List<List<String>> rows;

        Table(String rowAxisHeader, List<String> columnHeaders, List<List<String>> rows) {
            this.rowAxisHeader = rowAxisHeader;
            this.columnHeaders = columnHeaders;
            this.rows = rows;
        }
    }

    private CellSetFlattener() {
    }

    public static Table flatten(CellSet cellSet) {
        List<CellSetAxis> axes = cellSet.getAxes();
        if (axes.isEmpty()) {
            throw new IllegalArgumentException("CellSet has no axes (a scalar result is not a table).");
        }

        CellSetAxis columnsAxis = axes.get(0);
        // A query may have only a COLUMNS axis (no ROWS); synthesize a single empty row in that case.
        CellSetAxis rowsAxis = axes.size() > 1 ? axes.get(1) : null;

        List<String> columnHeaders = new ArrayList<>();
        for (Position colPos : columnsAxis.getPositions()) {
            columnHeaders.add(label(colPos));
        }

        String rowAxisHeader = rowsAxis != null ? hierarchyName(rowsAxis) : "";
        List<List<String>> rows = new ArrayList<>();

        if (rowsAxis == null) {
            // Single implicit row: just the column cells, ordinal = column position only.
            List<String> row = new ArrayList<>();
            row.add(""); // empty row-header cell
            for (int col = 0; col < columnHeaders.size(); col++) {
                row.add(cellValue(cellSet, col));
            }
            rows.add(row);
        } else {
            for (Position rowPos : rowsAxis.getPositions()) {
                List<String> row = new ArrayList<>();
                row.add(label(rowPos));
                for (Position colPos : columnsAxis.getPositions()) {
                    row.add(cellValue(cellSet, colPos.getOrdinal(), rowPos.getOrdinal()));
                }
                rows.add(row);
            }
        }

        return new Table(rowAxisHeader, columnHeaders, rows);
    }

    /** Joins the members of a tuple into one human label, e.g. "2013 / Bikes". */
    private static String label(Position position) {
        List<String> parts = new ArrayList<>();
        for (Member m : position.getMembers()) {
            parts.add(m.getCaption());
        }
        return String.join(" / ", parts);
    }

    /** Best-effort header for the row axis, taken from the first position's hierarchies. */
    private static String hierarchyName(CellSetAxis rowsAxis) {
        if (rowsAxis.getPositions().isEmpty()) {
            return "";
        }
        List<String> parts = new ArrayList<>();
        for (Member m : rowsAxis.getPositions().get(0).getMembers()) {
            parts.add(m.getHierarchy().getCaption());
        }
        return String.join(" / ", parts);
    }

    private static String cellValue(CellSet cellSet, int columnOrdinal, int rowOrdinal) {
        return cellSet.getCell(Arrays.asList(columnOrdinal, rowOrdinal)).getFormattedValue();
    }

    private static String cellValue(CellSet cellSet, int columnOrdinal) {
        return cellSet.getCell(Arrays.asList(columnOrdinal)).getFormattedValue();
    }
}
