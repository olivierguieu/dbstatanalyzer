package com.riskengine.contextui.views;

import com.riskengine.contextui.Models.FieldSpec;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds a GridPane of label + TextField rows for a list of FieldSpecs.
 * Returns both the rendered Node and the TextField map so callers can read
 * the values back later.
 */
public final class FormBuilder {

    private FormBuilder() {}

    public static Result build(List<FieldSpec> schema, Map<String, Object> initial) {
        GridPane grid = new GridPane();
        grid.setHgap(8);
        grid.setVgap(6);
        grid.setPadding(new Insets(4));

        Map<String, TextField> fields = new LinkedHashMap<>();
        int row = 0;
        for (FieldSpec f : schema) {
            Label label = new Label(f.name() + (f.required() ? " *" : "") + ":");
            TextField tf = new TextField();
            tf.setPromptText(f.type());
            if (initial != null && initial.get(f.name()) != null) {
                tf.setText(String.valueOf(initial.get(f.name())));
            }
            grid.add(label, 0, row);
            grid.add(tf, 1, row);
            fields.put(f.name(), tf);
            row++;
        }
        return new Result(grid, fields);
    }

    public static Map<String, Object> readValues(Map<String, TextField> fields, List<FieldSpec> schema) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (FieldSpec f : schema) {
            String raw = fields.get(f.name()).getText();
            if ("number".equals(f.type()) && raw != null && !raw.isBlank()) {
                out.put(f.name(), new java.math.BigDecimal(raw));
            } else {
                out.put(f.name(), raw);
            }
        }
        return out;
    }

    public record Result(GridPane node, Map<String, TextField> fields) {}
}
