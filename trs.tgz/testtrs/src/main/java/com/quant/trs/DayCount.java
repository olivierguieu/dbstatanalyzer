package com.quant.trs;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Day count fraction calculations for funding leg accruals. */
public final class DayCount {

    private DayCount() { }

    /** Accrual fraction for [start, end) under the given convention. */
    public static double fraction(LocalDate start, LocalDate end, DayCountConvention c) {
        switch (c) {
            case ACT_365:
                return actualDays(start, end) / 365.0;
            case THIRTY_360:
                return days30360(start, end) / 360.0;
            case ACT_360:
            default:
                return actualDays(start, end) / 360.0;
        }
    }

    private static long actualDays(LocalDate s, LocalDate e) {
        return ChronoUnit.DAYS.between(s, e);
    }

    /** 30/360 (US / Bond basis) day count. */
    private static long days30360(LocalDate s, LocalDate e) {
        int d1 = s.getDayOfMonth();
        int d2 = e.getDayOfMonth();
        if (d1 == 31) d1 = 30;
        if (d2 == 31 && d1 == 30) d2 = 30;
        return 360L * (e.getYear() - s.getYear())
                + 30L * (e.getMonthValue() - s.getMonthValue())
                + (d2 - d1);
    }
}
