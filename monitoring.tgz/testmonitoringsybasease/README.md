# ASE Workload Monitor

A lightweight continuous "top" for **Sybase ASE**, written in Java. It connects
over the open-source **jTDS** JDBC driver and samples the MDA (monitoring)
tables on an interval, reporting:

- **CPU / engines / device I/O** — delta per interval (cumulative counters differenced)
- **Locks & contention** — blocking chains + active lock count
- **Active sessions & SQL** — top sessions by CPU, with their current SQL text

## Build

```bash
mvn package
```

Produces a runnable fat-jar at `target/ase-workload-monitor.jar`.

## Run

```bash
java -jar target/ase-workload-monitor.jar <host> <port> <user> <password> [intervalSeconds]
# example
java -jar target/ase-workload-monitor.jar dbhost 5000 mon_user secret 10
```

Or via environment variables (override the positional args):
`ASE_HOST`, `ASE_PORT`, `ASE_USER`, `ASE_PASSWORD`, `ASE_INTERVAL`.

## Server prerequisites

The MDA tables must be installed and monitoring enabled, and the login needs
`mon_role`:

```sql
sp_configure 'enable monitoring', 1
sp_configure 'wait event timing', 1
sp_configure 'SQL batch capture', 1
sp_configure 'per object statistics active', 1
sp_role 'grant', mon_role, <login>
```

(MDA tables are installed once per server with the `installmontables` script
shipped with ASE.)
