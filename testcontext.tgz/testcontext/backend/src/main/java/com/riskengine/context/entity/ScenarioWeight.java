package com.riskengine.context.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "scenario_weight")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ScenarioWeight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "version_id")
    private Long versionId;

    @Column(nullable = false)
    private String scenarioCode;

    @Column(nullable = false, precision = 19, scale = 6)
    private BigDecimal weight;
}
