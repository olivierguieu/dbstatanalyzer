package com.riskengine.context.repository;

import com.riskengine.context.entity.RiskFactor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RiskFactorRepository extends JpaRepository<RiskFactor, Long> {
}
