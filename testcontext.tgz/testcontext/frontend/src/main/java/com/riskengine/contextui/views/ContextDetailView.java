package com.riskengine.contextui.views;

import com.riskengine.contextui.ApiClient;
import com.riskengine.contextui.AsyncUtil;
import com.riskengine.contextui.Models.ContextDto;
import com.riskengine.contextui.Models.ContextVersions;
import com.riskengine.contextui.Models.ParameterTable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class ContextDetailView extends ScrollPane {

    private final ApiClient api;
    private Runnable refreshList = () -> {};
    private final VBox root = new VBox(12);
    private final Label header = new Label("Pick a context from the list");
    private final Label info = new Label();
    private final Label versionsLabel = new Label();
    private final VBox parametersBox = new VBox(10);
    private final VBox renewBox = new VBox(6);
    private final Label status = new Label();

    private Long contextId;
    private ContextDto current;
    private List<ParameterTable> tables = List.of();
    private Map<String, Long> versions = Map.of();

    public ContextDetailView(ApiClient api) {
        this.api = api;
        header.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        root.setPadding(new Insets(12));
        root.getChildren().addAll(header, info, new Separator(),
                new Label("Parameter versions:"), versionsLabel,
                new Separator(), parametersBox,
                new Separator(), renewBox, status);

        setContent(root);
        setFitToWidth(true);
    }

    public void setRefreshList(Runnable r) { this.refreshList = r; }

    public void load(Long id) {
        contextId = id;
        header.setText("Loading context #" + id + "…");
        info.setText("");
        versionsLabel.setText("");
        parametersBox.getChildren().clear();
        renewBox.getChildren().clear();
        status.setText("");

        AsyncUtil.run(() -> {
            ContextDto ctx = api.getContext(id);
            ContextVersions v = api.versions(id);
            List<ParameterTable> ts = api.parameterTables();
            return new Bundle(ctx, v, ts);
        }, this::render, err -> status.setText("Failed: " + err.getMessage()));
    }

    private void render(Bundle b) {
        current = b.ctx();
        versions = b.versions().versions();
        tables = b.tables();
        boolean closed = current.endDate() != null;

        header.setText("Context #" + current.id() + " — " + current.label());
        info.setText("From: " + current.fromDate()
                + "    End: " + (current.endDate() == null ? "—" : current.endDate())
                + "    Status: " + (closed ? "closed" : "active"));
        versionsLabel.setText(versions.toString());

        parametersBox.getChildren().clear();
        for (ParameterTable t : tables) {
            Long versionId = versions.get(t.name());
            if (versionId == null) continue;

            TitledPane pane = new TitledPane();
            pane.setText(t.name() + " (version " + versionId + ")");
            pane.setExpanded(false);

            VBox body = new VBox(8);
            body.setPadding(new Insets(8));
            body.getChildren().add(new Label("Loading current values…"));
            pane.setContent(body);

            AsyncUtil.run(() -> api.readParameter(t.name(), versionId),
                    values -> populateEditor(body, t, values, closed),
                    err -> body.getChildren().setAll(new Label("Failed: " + err.getMessage())));

            parametersBox.getChildren().add(pane);
        }

        renewBox.getChildren().clear();
        renewBox.getChildren().add(new Label("Renew this context"));
        TextField renewLabel = new TextField(current.label() + " renewed");
        DatePicker renewFrom = new DatePicker(LocalDate.now());
        Button renewBtn = new Button("Close & duplicate");
        renewBtn.setDisable(closed);
        renewBtn.setOnAction(e -> renew(renewLabel.getText(), renewFrom.getValue()));
        renewBox.getChildren().add(new HBox(8,
                new Label("New label:"), renewLabel,
                new Label("From:"), renewFrom,
                renewBtn));
    }

    private void populateEditor(VBox body,
                                ParameterTable t,
                                Map<String, Object> values,
                                boolean closed) {
        body.getChildren().clear();
        FormBuilder.Result form = FormBuilder.build(t.schema(), values);
        DatePicker effective = new DatePicker(LocalDate.now());
        Button save = new Button("Save " + t.name());
        save.setDisable(closed);
        save.setOnAction(e -> saveParameter(t, form, effective.getValue()));

        body.getChildren().addAll(
                new Label("Current version ID: " + versions.get(t.name())),
                form.node(),
                new HBox(8, new Label("Effective date:"), effective, save));
    }

    private void saveParameter(ParameterTable t, FormBuilder.Result form, LocalDate effective) {
        Map<String, Object> payload = FormBuilder.readValues(form.fields(), t.schema());
        status.setText("Saving " + t.name() + "…");
        AsyncUtil.run(() -> api.modifyParameter(contextId, t.name(), effective, payload),
                ctx -> {
                    status.setText("Saved — now showing new context #" + ctx.id());
                    refreshList.run();
                    load(ctx.id());
                },
                err -> status.setText("Failed: " + err.getMessage()));
    }

    private void renew(String label, LocalDate from) {
        status.setText("Renewing…");
        AsyncUtil.run(() -> api.renew(contextId, label, from),
                ctx -> {
                    status.setText("Renewed into context #" + ctx.id());
                    refreshList.run();
                    load(ctx.id());
                },
                err -> status.setText("Failed: " + err.getMessage()));
    }

    private record Bundle(ContextDto ctx, ContextVersions versions, List<ParameterTable> tables) {}
}
