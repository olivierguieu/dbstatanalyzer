package com.riskengine.contextui;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.riskengine.contextui.Models.ContextDto;
import com.riskengine.contextui.Models.ContextVersions;
import com.riskengine.contextui.Models.ParameterTable;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class ApiClient {

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    private final String base;

    public ApiClient() {
        this(System.getProperty("contextApi.base",
                System.getenv().getOrDefault("CONTEXT_API_BASE", "http://localhost:8080/api")));
    }

    public ApiClient(String base) {
        this.base = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
    }

    public String baseUrl() {
        return base;
    }

    // ---- endpoints

    public List<ParameterTable> parameterTables() {
        return getList("/parameter-tables", new TypeReference<>() {});
    }

    public List<ContextDto> listContexts() {
        return getList("/contexts", new TypeReference<>() {});
    }

    public ContextDto getActive(LocalDate date) {
        return getOne("/contexts/active?date=" + date, ContextDto.class);
    }

    public ContextDto getContext(Long id) {
        return getOne("/contexts/" + id, ContextDto.class);
    }

    public ContextVersions versions(Long id) {
        return getOne("/contexts/" + id + "/versions", ContextVersions.class);
    }

    public Map<String, Object> readParameter(String name, Long versionId) {
        return getOne("/contexts/parameters/" + enc(name) + "/versions/" + versionId,
                new TypeReference<>() {});
    }

    public ContextDto createInitial(String label, LocalDate fromDate,
                                    Map<String, Map<String, Object>> parameters) {
        Map<String, Object> body = Map.of(
                "label", label,
                "fromDate", fromDate.toString(),
                "parameters", parameters
        );
        return postJson("/contexts", body, ContextDto.class);
    }

    public ContextDto renew(Long id, String label, LocalDate from) {
        String path = "/contexts/" + id + "/renew?label=" + enc(label) + "&from=" + from;
        return postJson(path, null, ContextDto.class);
    }

    public ContextDto modifyParameter(Long id, String name, LocalDate effectiveDate,
                                      Map<String, Object> payload) {
        String path = "/contexts/" + id + "/parameters/" + enc(name)
                + "?effectiveDate=" + effectiveDate;
        return putJson(path, payload, ContextDto.class);
    }

    // ---- transport

    private <T> T getOne(String path, Class<T> type) {
        return parse(send(get(path)), type);
    }

    private <T> T getOne(String path, TypeReference<T> type) {
        return parse(send(get(path)), type);
    }

    private <T> List<T> getList(String path, TypeReference<List<T>> type) {
        return parse(send(get(path)), type);
    }

    private <T> T postJson(String path, Object body, Class<T> type) {
        return parse(send(jsonRequest("POST", path, body)), type);
    }

    private <T> T putJson(String path, Object body, Class<T> type) {
        return parse(send(jsonRequest("PUT", path, body)), type);
    }

    private HttpRequest get(String path) {
        return HttpRequest.newBuilder(URI.create(base + path)).GET().build();
    }

    private HttpRequest jsonRequest(String method, String path, Object body) {
        HttpRequest.BodyPublisher publisher = body == null
                ? HttpRequest.BodyPublishers.noBody()
                : HttpRequest.BodyPublishers.ofString(writeJson(body));
        return HttpRequest.newBuilder(URI.create(base + path))
                .header("Content-Type", "application/json")
                .method(method, publisher)
                .build();
    }

    private HttpResponse<String> send(HttpRequest req) {
        try {
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() >= 400) {
                throw new ApiException(resp.statusCode(), resp.body());
            }
            return resp;
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("API call failed: " + e.getMessage(), e);
        }
    }

    private <T> T parse(HttpResponse<String> resp, Class<T> type) {
        try {
            return mapper.readValue(resp.body(), type);
        } catch (IOException e) {
            throw new RuntimeException("Failed to parse response: " + e.getMessage(), e);
        }
    }

    private <T> T parse(HttpResponse<String> resp, TypeReference<T> type) {
        try {
            return mapper.readValue(resp.body(), type);
        } catch (IOException e) {
            throw new RuntimeException("Failed to parse response: " + e.getMessage(), e);
        }
    }

    private String writeJson(Object body) {
        try {
            return mapper.writeValueAsString(body);
        } catch (IOException e) {
            throw new RuntimeException("Failed to serialise body", e);
        }
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    public static class ApiException extends RuntimeException {
        private final int status;
        public ApiException(int status, String body) {
            super("HTTP " + status + ": " + body);
            this.status = status;
        }
        public int status() { return status; }
    }
}
