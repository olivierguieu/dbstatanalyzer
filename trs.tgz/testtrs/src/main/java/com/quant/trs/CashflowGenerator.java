package com.quant.trs;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Builds the full set of cashflows for a TRS Equity trade:
 *  - Funding leg : one interest cashflow per payment period.
 *  - Equity leg  : one performance cashflow per reset period.
 *  - Dividends   : one pass-through cashflow per dividend event in scope.
 *
 * All amounts are signed from the booking party's perspective. The party
 * that receives the equity total return pays the funding leg and receives
 * the dividend pass-through.
 */
public class CashflowGenerator {

    public List<Cashflow> generate(TrsTrade t) {
        List<Cashflow> result = new ArrayList<>();

        // +1 if we receive the equity return, -1 if we pay it.
        double dirSign = (t.equityReturnDirection == EquityReturnDirection.RECEIVE) ? 1.0 : -1.0;

        PayReceive equityPR = (dirSign > 0) ? PayReceive.RECEIVE : PayReceive.PAY;
        PayReceive fundingPR = (dirSign > 0) ? PayReceive.PAY : PayReceive.RECEIVE;

        double notional = t.notional();
        double allInRate = t.indexRate + t.spread;

        // --- Funding leg ---
        for (ScheduleGenerator.Period p :
                ScheduleGenerator.generate(t.effectiveDate, t.terminationDate, t.fundingFrequency)) {
            double dcf = DayCount.fraction(p.start(), p.end(), t.dayCountConvention);
            Cashflow cf = new Cashflow();
            cf.legType = LegType.FUNDING;
            cf.payReceive = fundingPR;
            cf.periodStart = p.start();
            cf.periodEnd = p.end();
            cf.paymentDate = p.end();
            cf.nominal = notional;
            cf.rate = allInRate;
            cf.dayCountFraction = dcf;
            cf.currency = t.currency;
            cf.referenceIndex = t.referenceIndex;
            cf.amount = -dirSign * notional * allInRate * dcf;
            result.add(cf);
        }

        // --- Equity performance leg ---
        for (ScheduleGenerator.Period p :
                ScheduleGenerator.generate(t.effectiveDate, t.terminationDate, t.equityResetFrequency)) {
            double priceStart = priceAt(t, p.start());
            double priceEnd = priceAt(t, p.end());
            Cashflow cf = new Cashflow();
            cf.legType = LegType.EQUITY_PERFORMANCE;
            cf.payReceive = equityPR;
            cf.periodStart = p.start();
            cf.periodEnd = p.end();
            cf.paymentDate = p.end();
            cf.nominal = t.numberOfShares * priceStart;
            cf.priceStart = priceStart;
            cf.priceEnd = priceEnd;
            cf.currency = t.currency;
            cf.amount = dirSign * t.numberOfShares * (priceEnd - priceStart);
            result.add(cf);
        }

        // --- Dividend pass-through ---
        for (DividendEvent d : t.dividends) {
            if (d.exDate == null) continue;
            if (d.exDate.isBefore(t.effectiveDate) || d.exDate.isAfter(t.terminationDate)) continue;
            Cashflow cf = new Cashflow();
            cf.legType = LegType.DIVIDEND;
            cf.payReceive = equityPR;
            cf.periodStart = d.exDate;
            cf.periodEnd = d.exDate;
            cf.paymentDate = d.exDate;
            cf.nominal = t.numberOfShares;
            cf.dividendPerShare = d.dividendPerShare;
            cf.currency = t.currency;
            cf.amount = dirSign * t.numberOfShares * d.dividendPerShare * t.dividendPassThrough;
            result.add(cf);
        }

        result.sort(Comparator.comparing((Cashflow c) -> c.paymentDate)
                .thenComparing(c -> c.legType.name()));
        return result;
    }

    /**
     * Price of the underlying on (or just before) {@code date}: the latest
     * supplied fixing dated on or before {@code date}, falling back to the
     * trade's initial price.
     */
    private double priceAt(TrsTrade t, LocalDate date) {
        double price = t.initialPrice;
        LocalDate best = t.effectiveDate;
        for (PriceFixing f : t.priceFixings) {
            if (f.date == null || f.date.isAfter(date)) continue;
            if (best == null || !f.date.isBefore(best)) {
                best = f.date;
                price = f.price;
            }
        }
        return price;
    }
}
