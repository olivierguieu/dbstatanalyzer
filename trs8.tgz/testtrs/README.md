# TRS Equity – Cashflow Generator

A JavaFX desktop application to capture the characteristics of a **TRS (Total
Return Swap) Equity** trade and export all associated cashflows to an XML file.
A standalone Perl port of the same cashflow logic is included.

---

## Table of contents

- [Overview](#overview)
- [Background: the TRS Equity trade](#background-the-trs-equity-trade)
- [Requirements](#requirements)
- [Build and run](#build-and-run)
- [Using the application](#using-the-application)
- [Trade inputs](#trade-inputs)
- [Cashflow logic](#cashflow-logic)
- [XML output schema](#xml-output-schema)
- [Worked example](#worked-example)
- [Unit tests](#unit-tests)
- [Perl port](#perl-port)
- [Project layout](#project-layout)
- [Assumptions and limitations](#assumptions-and-limitations)

---

## Overview

You enter the characteristics of a TRS Equity trade on a form; the application
generates the cashflows of **both legs** and writes them to a readable custom
XML schema. Each cashflow describes its nominal, rate, accrual dates, day count
fraction and signed amount.

Generated cashflows:

| Leg | Cashflow | Amount formula |
|-----|----------|----------------|
| Funding | One per payment period | `notional × (indexRate + spread) × dayCountFraction` |
| Equity performance | One per reset period | `numberOfShares × (priceEnd − priceStart)` |
| Dividend | One per dividend event in scope | `numberOfShares × dividendPerShare × passThrough` |

All amounts are **signed from the booking party's perspective**.

---

## Background: the TRS Equity trade

A Total Return Swap on equity exchanges two streams of cashflows between two
parties over the life of the trade:

- The **equity leg** pays the *total return* of an underlying equity — the
  price performance plus any dividends.
- The **funding leg** pays a financing cost, here a floating reference index
  (e.g. EURIBOR-3M) plus a spread, accrued on the trade notional.

The party that **receives** the equity total return **pays** the funding leg
and **receives** the dividend pass-through. The party that **pays** the equity
total return has the mirror-image position. This direction is captured by the
`equityReturnDirection` input, and every generated amount is signed
accordingly (negative = paid out, positive = received).

---

## Requirements

| Tool | Version |
|------|---------|
| JDK | 8, **with JavaFX bundled** |
| Maven | 3.8 or later |
| Perl | 5.10+ (for the Perl port; core modules only) |

The project targets **Java 8**. JavaFX is **not** a Maven dependency — it is
expected to ship inside the JDK. Use a JDK 8 distribution that bundles JavaFX:

- Oracle JDK 8
- Azul Zulu FX 8
- BellSoft Liberica Full 8

On these JDKs, JavaFX sits on the extension classpath and is found
automatically at both compile and run time.

---

## Build and run

Run the desktop application:

```bash
mvn exec:java
```

Compile only:

```bash
mvn compile
```

Run the unit tests:

```bash
mvn test
```

Build a jar:

```bash
mvn package
```

---

## Using the application

1. Launch with `mvn exec:java`.
2. Fill in the **Trade**, **Legs**, **Dividend events** and **Equity price
   fixings** sections of the form.
3. Click **Generate Cashflows** to compute the cashflows and preview the XML
   in the lower panel.
4. Click **Export XML…** to save the document to disk. The suggested file
   name is `<tradeId>_cashflows.xml`.

Invalid input (missing dates, non-numeric fields, effective date not before
termination date) is reported with an error dialog.

---

## Trade inputs

### Trade

| Field | Description |
|-------|-------------|
| Trade ID | Identifier used in the XML and the export file name |
| Counterparty | Name of the counterparty |
| Underlying | Name / ticker of the underlying equity |
| Currency | Trade currency (EUR, USD, GBP, JPY, CHF) |
| Number of shares | Quantity of the underlying |
| Initial price | Equity price at the effective date |
| Trade date | Date the trade was agreed |
| Effective date | Start of the trade (first accrual date) |
| Termination date | End of the trade |

The **notional** is computed as `numberOfShares × initialPrice`.

### Legs

| Field | Description |
|-------|-------------|
| Equity return direction | `RECEIVE` or `PAY` the equity total return |
| Reference index | Funding leg floating index name (e.g. EURIBOR-3M) |
| Index rate (%) | Flat reference index level, entered in percent |
| Spread (%) | Funding spread over the index, entered in percent |
| Day count convention | `ACT_360`, `ACT_365` or `THIRTY_360` |
| Funding payment frequency | `MONTHLY`, `QUARTERLY`, `SEMI_ANNUAL`, `ANNUAL`, `AT_TERMINATION` |
| Equity reset frequency | Same set of frequencies, for equity performance periods |
| Dividend pass-through (%) | Fraction of declared dividends passed through |

### Dividend events

Each row is an ex-date and a dividend amount per share. Events with an ex-date
outside `[effectiveDate, terminationDate]` are ignored.

### Equity price fixings

Observed equity prices used to value each equity performance reset. The
effective-date price defaults to the trade's initial price. When a reset date
has no exact fixing, the latest fixing dated on or before it is used.

---

## Cashflow logic

### Schedule generation

Periods roll forward from the effective date by the leg frequency. The final
period is truncated so it ends exactly on the termination date.
`AT_TERMINATION` produces a single period spanning the whole trade.

### Day count fractions

| Convention | Fraction |
|------------|----------|
| `ACT_360` | actual days / 360 |
| `ACT_365` | actual days / 365 |
| `THIRTY_360` | 30/360 (US / bond basis) days / 360 |

The 30/360 rule adjusts a start day of 31 to 30, and an end day of 31 to 30
when the (adjusted) start day is 30.

### Funding leg

One cashflow per funding payment period:

```
allInRate = indexRate + spread
amount    = −dirSign × notional × allInRate × dayCountFraction
```

### Equity performance leg

One cashflow per equity reset period:

```
amount = dirSign × numberOfShares × (priceEnd − priceStart)
```

`priceStart` / `priceEnd` are taken from the price fixings (see above).

### Dividend leg

One cashflow per dividend event whose ex-date falls within the trade window:

```
amount = dirSign × numberOfShares × dividendPerShare × dividendPassThrough
```

### Sign convention

`dirSign = +1` when `equityReturnDirection = RECEIVE`, `−1` when `PAY`.

| Direction | Equity perf | Dividends | Funding |
|-----------|-------------|-----------|---------|
| `RECEIVE` | received | received | paid |
| `PAY` | paid | paid | received |

Cashflows are sorted by payment date, then by leg type.

---

## XML output schema

A simple, readable custom schema:

```xml
<trsTrade product="EquityTotalReturnSwap" generated="YYYY-MM-DD">
  <tradeHeader>
    <tradeId/> <tradeDate/> <counterparty/> <equityReturnDirection/>
  </tradeHeader>
  <equityUnderlier>
    <name/> <numberOfShares/> <initialPrice/> <currency/>
  </equityUnderlier>
  <terms>
    <effectiveDate/> <terminationDate/> <notional/> <currency/>
    <fundingLeg>
      <referenceIndex/> <indexRate/> <spread/> <allInRate/>
      <dayCountConvention/> <paymentFrequency/>
    </fundingLeg>
    <equityLeg>
      <resetFrequency/> <dividendPassThrough/>
    </equityLeg>
  </terms>
  <cashflows count="N">
    <cashflow type="FUNDING|EQUITY_PERFORMANCE|DIVIDEND">
      <payReceive/> <paymentDate/> <periodStartDate/> <periodEndDate/>
      <nominal/>
      <!-- funding only:  --> <referenceIndex/> <rate/> <dayCountFraction/>
      <!-- equity only:   --> <priceStart/> <priceEnd/>
      <!-- dividend only: --> <dividendPerShare/>
      <currency/> <amount/>
    </cashflow>
  </cashflows>
</trsTrade>
```

Elements not relevant to a cashflow's leg are omitted.

---

## Worked example

100,000 shares at 50.00 EUR, 1-year trade, quarterly funding at 3.20% index +
0.50% spread (ACT/360), semi-annual equity resets, one dividend and two price
fixings produces **7 cashflows**: 4 funding, 2 equity performance, 1 dividend.

For the first funding period (92 days, ACT/360):

```
amount = −1 × 5,000,000 × 0.037 × (92/360) = −47,277.78 EUR
```

For the first equity reset (price 50 → 55):

```
amount = +1 × 100,000 × (55 − 50) = +500,000.00 EUR
```

For the dividend (1.25 per share, 100% pass-through):

```
amount = +1 × 100,000 × 1.25 × 1.0 = +125,000.00 EUR
```

---

## Unit tests

JUnit 5 tests live under `src/test/java/com/quant/trs/` and run with
`mvn test`. **25 tests** across 4 classes:

| Test class | Tests | Covers |
|------------|-------|--------|
| `DayCountTest` | 6 | ACT/360, ACT/365, 30/360 incl. day-31 adjustment rules, zero-length period |
| `ScheduleGeneratorTest` | 5 | Period counts, contiguity, `AT_TERMINATION`, final-period truncation, invalid date ranges |
| `CashflowGeneratorTest` | 10 | Funding count and accrual formula, pay/receive signs, direction flip, equity performance, dividend pass-through and windowing, ordering |
| `XmlExporterTest` | 4 | Well-formed XML, root element, `count` attribute consistency, core fields, file round-trip |

---

## Perl port

`perl/trs_cashflows.pl` is a standalone, dependency-free (core modules only)
port of the cashflow logic — identical schedule, day count, cashflow and XML
rules. It is verified to produce the same cashflow output as the Java engine.

Run with the built-in sample trade:

```bash
perl perl/trs_cashflows.pl
```

Run with overrides and dividends / fixings:

```bash
perl perl/trs_cashflows.pl \
  --equity-freq SEMI_ANNUAL \
  --dividend 2026-09-15:1.25 \
  --fixing 2026-11-20:55.0 --fixing 2027-05-20:58.0 \
  --out trade.xml
```

### Options

| Option | Description |
|--------|-------------|
| `--trade-id`, `--counterparty`, `--underlying` | Trade header strings |
| `--currency` | Trade currency |
| `--shares`, `--initial-price` | Underlier quantity and price |
| `--trade-date`, `--effective`, `--termination` | Dates (`YYYY-MM-DD`) |
| `--direction` | `RECEIVE` or `PAY` |
| `--index`, `--index-rate`, `--spread` | Funding index name and rates (percent) |
| `--day-count` | `ACT_360`, `ACT_365`, `THIRTY_360` |
| `--funding-freq`, `--equity-freq` | Leg frequencies |
| `--pass-through` | Dividend pass-through (percent) |
| `--dividend YYYY-MM-DD:AMOUNT` | A dividend event (repeatable) |
| `--fixing YYYY-MM-DD:PRICE` | An equity price fixing (repeatable) |
| `--out FILE` | Output file (default: stdout) |

The full option list is also documented in the script's header comment.

> Note: number formatting uses `sprintf` (C-library rounding) in Perl versus
> `BigDecimal` HALF_UP in Java. They may differ by one unit in the last
> printed digit on an exact `.xxx5` tie; the cashflow body is otherwise
> identical.

---

## Project layout

```
.
├── pom.xml                            Maven build (Java 8, JUnit 5)
├── README.md
├── perl/
│   └── trs_cashflows.pl               Standalone Perl port of the engine
└── src/
    ├── main/java/com/quant/trs/
    │   ├── TrsApp.java                JavaFX application + input form
    │   ├── TrsTrade.java              Trade characteristics model
    │   ├── Cashflow.java              Generated cashflow model
    │   ├── DividendEvent.java         Dividend input row
    │   ├── PriceFixing.java           Equity price fixing input row
    │   ├── Enums.java                 PayReceive, LegType,
    │   │                              EquityReturnDirection,
    │   │                              DayCountConvention, Frequency
    │   ├── ScheduleGenerator.java     Period schedule builder
    │   ├── DayCount.java              Day count fraction calculations
    │   ├── CashflowGenerator.java     Cashflow generation for both legs
    │   └── XmlExporter.java           XML serialisation
    └── test/java/com/quant/trs/
        ├── DayCountTest.java
        ├── ScheduleGeneratorTest.java
        ├── CashflowGeneratorTest.java
        └── XmlExporterTest.java
```

---

## Assumptions and limitations

- **Funding notional is constant** at the initial notional; it does not reset
  to follow the equity price.
- **Floating rate is a flat input** — the index level is entered by the user;
  there is no market data feed or forward curve.
- **No business-day adjustment or holiday calendar** — schedule dates are
  unadjusted calendar dates, and the payment date equals the period end date
  (no payment lag).
- **Equity performance valuation** depends on the price fixings supplied; a
  reset with no fixing on or before its date falls back to the initial price
  (zero performance).
- Intended as a trade-capture / cashflow-projection tool, not a pricing or
  risk engine — there is no discounting or present-value calculation.
