package com.oguieu.checksybasestats.model;

public final class ColumnInfo {
    private final int    colId;
    private final String name;
    private final int    type;
    private final int    length;
    private final int    prec;
    private final int    scale;

    public ColumnInfo(int colId, String name, int type, int length, int prec, int scale) {
        this.colId  = colId;
        this.name   = name;
        this.type   = type;
        this.length = length;
        this.prec   = prec;
        this.scale  = scale;
    }

    public int    colId()  { return colId; }
    public String name()   { return name;  }
    public int    type()   { return type;  }
    public int    length() { return length;}
    public int    prec()   { return prec;  }
    public int    scale()  { return scale; }
}
