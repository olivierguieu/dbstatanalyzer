package com.quant.trs;

import java.time.LocalDate;

/**
 * An observed price of the underlying equity on a given date.
 * Used to value equity performance periods. The effective-date price
 * is taken from the trade's initial price when no fixing is supplied.
 */
public class PriceFixing {

    public final LocalDate date;
    public final double price;

    public PriceFixing(LocalDate date, double price) {
        this.date = date;
        this.price = price;
    }

    @Override
    public String toString() {
        return date + "  price=" + price;
    }
}
