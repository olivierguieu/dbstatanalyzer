package com.riskengine.context.service;

import com.riskengine.context.entity.ScenarioWeight;
import com.riskengine.context.exception.ResourceNotFoundException;
import com.riskengine.context.repository.ScenarioWeightRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class ScenarioWeightHandler implements ParameterHandler {

    private final ScenarioWeightRepository repository;

    @Override
    public String name() {
        return "scenario_weight";
    }

    @Override
    public List<FieldSpec> schema() {
        return List.of(
                new FieldSpec("scenarioCode", "string", true),
                new FieldSpec("weight", "number", true)
        );
    }

    @Override
    public Long saveNewVersion(Map<String, Object> payload) {
        ScenarioWeight saved = repository.save(ScenarioWeight.builder()
                .scenarioCode(String.valueOf(payload.get("scenarioCode")))
                .weight(new BigDecimal(String.valueOf(payload.get("weight"))))
                .build());
        return saved.getVersionId();
    }

    @Override
    public Map<String, Object> read(Long versionId) {
        ScenarioWeight sw = repository.findById(versionId)
                .orElseThrow(() -> new ResourceNotFoundException("scenario_weight version not found: " + versionId));
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("versionId", sw.getVersionId());
        out.put("scenarioCode", sw.getScenarioCode());
        out.put("weight", sw.getWeight());
        return out;
    }
}
