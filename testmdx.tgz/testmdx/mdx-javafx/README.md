# mdx-javafx

JavaFX app that runs an MDX query against SSAS via **olap4j (XMLA)** and renders
the result in a `TableView`. Authentication is **Kerberos/SPNEGO**, negotiated by
the JVM — no credentials in code. It reuses the exact JVM flags proven by
`../kerberos-smoketest`.

## Layout

| File | Purpose |
|---|---|
| `pom.xml` | Maven build. Note the IMPORTANT block about sourcing the XMLA driver. |
| `CellSetFlattener.java` | Turns a 2-axis olap4j `CellSet` into headers + rows (no UI deps; testable). |
| `MdxTableViewApp.java` | JavaFX UI: MDX text box → background query → `TableView`. |

## Prerequisites

- **JDK 17+** (JavaFX 21 + `release 17`).
- A working Kerberos chain to SSAS — validate it first with `../kerberos-smoketest`.
- The olap4j **XMLA driver jar**, which is **not on Maven Central** (see below).

## ⚠️ Getting the XMLA driver (the one real snag)

Maven Central has only olap4j *core*. The driver (`XmlaOlap4jDriver`) ships in a
separate `olap4j-xmla` jar that is **not** on Central. Build it from source once
with the included script — it pulls only olap4j-core + xercesImpl from Central
(no Pentaho repos, no Ant/Ivy) and installs `org.olap4j:olap4j-xmla:1.2.0` into
your `~/.m2`:

```bash
./build-olap4j-xmla.sh
```

This recipe is verified on JDK 8–21. After it runs, the `pom.xml` dependency
resolves with no extra repository config. (The driver imports `org.apache.xerces.*`
directly, so the pom also declares `xerces:xercesImpl:2.6.0` for runtime.)

## Run

```bash
mvn javafx:run                       # uses defaults + Kerberos flags from pom
# override endpoint/catalog/MDX:
mvn javafx:run -Dssas.endpoint=https://ssas.yourcorp.com/olap/msmdpump.dll \
               -Dssas.catalog="Adventure Works DW" \
               -Dssas.mdx="SELECT ... ON COLUMNS, ... ON ROWS FROM [Adventure Works]"
```

The pom passes the Kerberos flags (`-Djava.security.krb5.conf`,
`-Djava.security.auth.login.config`, `-Djavax.security.auth.useSubjectCredsOnly=false`)
pointing at `../kerberos-smoketest/krb5.conf` and `jaas.conf`. Adjust those paths
if you move things.

## How the CellSet maps to the table

- COLUMNS axis (axis 0) → table columns (one per position; tuples joined with " / ").
- ROWS axis (axis 1) → table rows; the first column holds the row-member label.
- Each cell = `cellSet.getCell(col, row).getFormattedValue()` (server-formatted string).
- Queries with only a COLUMNS axis render as a single row; a scalar (no axes) is rejected.

## Notes

- The query runs on a background `Task` thread so the UI never freezes on network I/O.
- `CellSetFlattener` returns a detached structure, so the olap4j connection is
  closed (try-with-resources) before the data reaches the FX thread.
- No `User`/`Password` is set — that is deliberate, so the JVM uses Kerberos.
