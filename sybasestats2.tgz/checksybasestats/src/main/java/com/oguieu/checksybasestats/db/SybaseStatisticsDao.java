package com.oguieu.checksybasestats.db;

import com.oguieu.checksybasestats.model.ColumnInfo;
import com.oguieu.checksybasestats.model.HistogramData;
import com.oguieu.checksybasestats.model.HistogramStep;
import com.oguieu.checksybasestats.model.StatEntry;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.sql.*;
import java.util.*;

public class SybaseStatisticsDao implements AutoCloseable {

    private final Connection connection;
    private String diagnosticInfo  = "";
    private String currentDatabase = "";

    public SybaseStatisticsDao(ConnectionConfig config) throws SQLException {
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("jTDS driver not found on classpath", e);
        }
        Properties props = new Properties();
        props.setProperty("user", config.username());
        props.setProperty("password", config.password());
        this.connection = DriverManager.getConnection(config.jdbcUrl(), props);
        try (Statement st = this.connection.createStatement()) {
            st.execute("USE " + config.database());
            st.execute("SET QUOTED_IDENTIFIER ON");
        }
    }

    public String getDiagnosticInfo()  { return diagnosticInfo;  }
    public String getCurrentDatabase() { return currentDatabase; }

    // -------------------------------------------------------------------------
    //  Table listing
    // -------------------------------------------------------------------------

    public List<String> loadTableNames() throws SQLException {
        try (Statement st = connection.createStatement()) {
            try (ResultSet rs = st.executeQuery("SELECT db_name()")) {
                currentDatabase = rs.next() ? rs.getString(1).trim() : "?";
            }
            StringBuilder diag = new StringBuilder("db_name() = ").append(currentDatabase).append("\n\n");
            diag.append("sysobjects type counts:\n");
            try (ResultSet rs = st.executeQuery(
                    "SELECT type, count(*) AS n FROM sysobjects GROUP BY type ORDER BY type")) {
                boolean any = false;
                while (rs.next()) {
                    diag.append("  type='").append(rs.getString("type").trim())
                        .append("'  count=").append(rs.getInt("n")).append("\n");
                    any = true;
                }
                if (!any) diag.append("  (no rows)\n");
            }
            diagnosticInfo = diag.toString();

            List<String> names = new ArrayList<>();
            try (ResultSet rs = st.executeQuery(
                    "SELECT name FROM sysobjects WHERE type = 'U' ORDER BY name")) {
                while (rs.next()) names.add(rs.getString("name").trim());
            }
            if (!names.isEmpty()) return names;

            try (ResultSet rs = connection.getMetaData()
                    .getTables(connection.getCatalog(), null, "%", new String[]{"TABLE"})) {
                while (rs.next()) names.add(rs.getString("TABLE_NAME").trim());
            }
            names.sort(String.CASE_INSENSITIVE_ORDER);
            return names;
        }
    }

    // -------------------------------------------------------------------------
    //  Stats entry listing  (formatid = 100 rows only = Column / ColumnGroup Stats)
    // -------------------------------------------------------------------------

    public List<StatEntry> loadStatEntries(String tableName) throws SQLException {
        int tableId = resolveObjectId(tableName);
        if (tableId == 0) throw new SQLException("Table not found: " + tableName);

        Map<Integer, ColumnInfo> cols = loadColumns(tableId);
        double totalRows = getTableRowCount(tableId);

        List<StatEntry> result = new ArrayList<>();

        // One row per column or columngroup, differentiated by colidarray.
        // indid=0 selects table-level stats; statid=0 selects real (non-simulated) stats.
        String sql =
            "SELECT statid, indid, colidarray, usedcount, c0 " +
            "FROM sysstatistics " +
            "WHERE id = ? AND formatid = 100 AND indid = 0 AND statid = 0 " +
            "ORDER BY statid, sequence";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tableId);
            try (ResultSet rs = ps.executeQuery()) {
                // Track colidarray bytes seen to avoid duplicates when colidarray is null
                Set<String> seenKeys = new LinkedHashSet<>();

                while (rs.next()) {
                    int    statId         = rs.getInt("statid");
                    int    indid          = rs.getInt("indid");
                    byte[] colidarrayBytes = readBytes(rs, "colidarray");
                    int[]  colIds          = decodeColIds(colidarrayBytes);

                    // When colidarray comes back null or empty, fall back to sysindexes
                    if (colIds.length == 0) colIds = resolveKeyColIds(tableId, indid, statId);

                    // Deduplicate by colidarray bytes (when null, each row still appears once)
                    String key = colidarrayBytes == null
                            ? "null#" + result.size()
                            : bytesToHex(colidarrayBytes);
                    if (!seenKeys.add(key)) continue;

                    String label = colIds.length > 0
                            ? buildLabel(colIds, cols)
                            : resolveIndexName(tableId, indid, statId);

                    // Store raw c0 bytes (contains density value) for hex display
                    byte[] c0bytes = readBytes(rs, "c0");

                    result.add(new StatEntry(statId, indid, colIds, label,
                            0, 0.0, totalRows, 0.0, c0bytes));
                }
            }
        }

        // Fallback: if indid=0/statid=0 returned nothing, query without those filters
        if (result.isEmpty()) {
            result = loadStatEntriesFallback(tableId, cols, totalRows);
        }
        return result;
    }

    private List<StatEntry> loadStatEntriesFallback(int tableId,
            Map<Integer, ColumnInfo> cols, double totalRows) throws SQLException {
        List<StatEntry> result = new ArrayList<>();
        String sql =
            "SELECT statid, indid, colidarray, usedcount, c0 " +
            "FROM sysstatistics WHERE id = ? AND formatid = 100 " +
            "ORDER BY indid, statid, sequence";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tableId);
            try (ResultSet rs = ps.executeQuery()) {
                int lastStatId = Integer.MIN_VALUE;
                while (rs.next()) {
                    int statId = rs.getInt("statid");
                    int indid  = rs.getInt("indid");
                    if (statId == lastStatId) continue;
                    lastStatId = statId;

                    byte[] colidarrayBytes = readBytes(rs, "colidarray");
                    int[]  colIds          = decodeColIds(colidarrayBytes);
                    if (colIds.length == 0) colIds = resolveKeyColIds(tableId, indid, statId);

                    String label = colIds.length > 0
                            ? buildLabel(colIds, cols)
                            : resolveIndexName(tableId, indid, statId);
                    byte[] c0bytes = readBytes(rs, "c0");
                    result.add(new StatEntry(statId, indid, colIds, label,
                            0, 0.0, totalRows, 0.0, c0bytes));
                }
            }
        }
        return result;
    }

    // -------------------------------------------------------------------------
    //  Histogram building  (formatid 102 = Values, 104 = Weights)
    // -------------------------------------------------------------------------

    public HistogramData buildHistogram(String tableName, StatEntry entry) throws Exception {
        int tableId = resolveObjectId(tableName);
        Map<Integer, ColumnInfo> cols = loadColumns(tableId);

        // Resolve the first column in this stat's key
        int[] colIds = entry.colIds().length > 0 ? entry.colIds()
                     : resolveKeyColIds(tableId, entry.indid(), entry.statId());
        ColumnInfo col = colIds.length > 0 ? cols.get(colIds[0]) : null;
        if (col == null && !cols.isEmpty()) col = cols.values().iterator().next();
        if (col == null) throw new Exception("No column metadata for table id=" + tableId);

        double totalRows = entry.rows() > 0 ? entry.rows() : getTableRowCount(tableId);
        double density   = readDensity(tableId, entry.statId(), entry.indid());

        // Re-encode colIds → colidarray bytes to use as an additional filter when available.
        // This correctly scopes histogram rows to a single column when multiple columns
        // share statid=0 and indid=0 (differentiated only by colidarray).
        byte[] colidarray = colIds.length > 0 ? encodeColIds(colIds) : null;

        // Read values and weights; pair positionally to form histogram cells
        List<byte[]> rawValues  = readCellVector(tableId, entry.statId(), entry.indid(), 102, colidarray);
        List<byte[]> rawWeights = readCellVector(tableId, entry.statId(), entry.indid(), 104, colidarray);

        List<HistogramStep> steps = pairCells(rawValues, rawWeights, col, totalRows);

        return new HistogramData(tableName, entry.label(),
                steps.size(), density, totalRows, 0.0, steps);
    }

    // -------------------------------------------------------------------------
    //  Cell vector reading
    // -------------------------------------------------------------------------

    /**
     * Reads all cell data (values or weights) for one sysstatistics formatid vector.
     * Returns one byte[] per cell, in order; null entry = SQL NULL cell (placeholder).
     * Respects usedcount per row and ordering by sequence.
     *
     * When colidarray is non-null it is included as an extra filter so that rows for a
     * specific column are isolated even when multiple columns share the same statid/indid.
     */
    private List<byte[]> readCellVector(int tableId, int statId, int indid, int formatid,
                                        byte[] colidarray) throws SQLException {
        StringBuilder cols = new StringBuilder("usedcount");
        for (int i = 0; i < 80; i++) cols.append(", c").append(i);

        boolean filterByColidarray = (colidarray != null && colidarray.length > 0);
        String sql = "SELECT " + cols +
                " FROM sysstatistics " +
                "WHERE id = ? AND statid = ? AND indid = ? AND formatid = ?" +
                (filterByColidarray ? " AND colidarray = ?" : "") +
                " ORDER BY sequence";

        List<byte[]> result = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tableId);
            ps.setInt(2, statId);
            ps.setInt(3, indid);
            ps.setInt(4, formatid);
            if (filterByColidarray) ps.setBytes(5, colidarray);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int usedcount = rs.getInt("usedcount");
                    if (usedcount <= 0) continue;
                    for (int i = 0; i < usedcount && i < 80; i++) {
                        // rs.getBytes() returns null for SQL NULL — correct for
                        // placeholder range-cell values (zero-weight, null-value)
                        byte[] bytes = rs.getBytes("c" + i);
                        result.add(bytes);
                    }
                }
            }
        } catch (SQLException e) {
            // If colidarray filter caused an error (e.g. type mismatch), retry without it
            if (filterByColidarray) return readCellVector(tableId, statId, indid, formatid, null);
            throw e;
        }
        return result;
    }

    // -------------------------------------------------------------------------
    //  Cell pairing  (Values + Weights → HistogramStep list)
    // -------------------------------------------------------------------------

    /**
     * Pairs cell values (formatid 102) with cell weights (formatid 104) positionally.
     *
     * Cell types per PDF "Sybase Statistics Demystified":
     *   Placeholder Range Cell : weight = 0, value = SQL NULL → skip, mark next as Frequency
     *   Frequency Cell         : cell immediately after a Placeholder → eqRows  = weight * totalRows
     *   Range Cell             : everything else                      → rangeRows = weight * totalRows
     *
     * Weight is stored as a 4-byte IEEE-754 little-endian float, fraction of total rows (0-1).
     */
    private List<HistogramStep> pairCells(List<byte[]> rawValues, List<byte[]> rawWeights,
                                           ColumnInfo col, double totalRows) {
        List<HistogramStep> steps = new ArrayList<>();
        int n = Math.min(rawValues.size(), rawWeights.size());
        boolean nextIsFrequency = false;

        for (int i = 0; i < n; i++) {
            byte[] vBytes = rawValues.get(i);
            byte[] wBytes = rawWeights.get(i);
            float  w      = bytesToFloat(wBytes);

            boolean nullValue  = (vBytes == null);
            boolean zeroWeight = (w == 0f);

            if (nullValue && zeroWeight) {
                // Placeholder Range Cell — the next cell is a Frequency Cell
                nextIsFrequency = true;
                continue;
            }

            String value = nullValue ? "(null)"
                         : StatBlobParser.parseOneValue(vBytes, col);
            double rowCount = totalRows > 0 ? w * totalRows : w;

            if (nextIsFrequency) {
                steps.add(new HistogramStep(value, rowCount, 0.0));
                nextIsFrequency = false;
            } else {
                steps.add(new HistogramStep(value, 0.0, rowCount));
            }
        }
        return steps;
    }

    // -------------------------------------------------------------------------
    //  Density & row count helpers
    // -------------------------------------------------------------------------

    private double readDensity(int tableId, int statId, int indid) {
        String sql = "SELECT c0, c1 " +
                "FROM sysstatistics WHERE id = ? AND statid = ? AND indid = ? AND formatid = 100";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tableId);
            ps.setInt(2, statId);
            ps.setInt(3, indid);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // c1 = total density (8-byte double, little-endian)
                    byte[] c1 = rs.getBytes("c1");
                    if (c1 != null && c1.length >= 8)
                        return ByteBuffer.wrap(c1).order(ByteOrder.LITTLE_ENDIAN).getDouble();
                    // fallback: c0 = range cell density
                    byte[] c0 = rs.getBytes("c0");
                    if (c0 != null && c0.length >= 8)
                        return ByteBuffer.wrap(c0).order(ByteOrder.LITTLE_ENDIAN).getDouble();
                }
            }
        } catch (SQLException ignored) {}
        return 0.0;
    }

    private double getTableRowCount(int tableId) {
        // systabstats.rowcnt holds the cached row count for the table (indid=0, partitionid=0)
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT rowcnt FROM systabstats WHERE id = ? AND indid = 0 AND partitionid = 0")) {
            ps.setInt(1, tableId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble("rowcnt");
            }
        } catch (SQLException ignored) {}
        // systabstats unavailable or no entry → weights will be shown as fractions (0-1)
        return 0.0;
    }

    // -------------------------------------------------------------------------
    //  Object / column resolution helpers
    // -------------------------------------------------------------------------

    private int resolveObjectId(String tableName) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT id FROM sysobjects WHERE name = ? AND type = 'U'")) {
            ps.setString(1, tableName);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("id") : 0;
            }
        }
    }

    private Map<Integer, ColumnInfo> loadColumns(int tableId) throws SQLException {
        Map<Integer, ColumnInfo> map = new LinkedHashMap<>();
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT colid, name, type, length, prec, scale " +
                "FROM syscolumns WHERE id = ? ORDER BY colid")) {
            ps.setInt(1, tableId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("colid");
                    map.put(id, new ColumnInfo(id,
                            rs.getString("name"),
                            rs.getInt("type"),
                            rs.getInt("length"),
                            rs.getInt("prec"),
                            rs.getInt("scale")));
                }
            }
        }
        return map;
    }

    /**
     * Resolves key column IDs from sysindexes when colidarray is unavailable.
     * Strategy 1: match by indid (reliable when indid > 0).
     * Strategy 2: try sysindexes.statid column (ASE 16, not always present).
     */
    private int[] resolveKeyColIds(int tableId, int indid, int statId) throws SQLException {
        if (indid > 0) {
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT keys1 FROM sysindexes WHERE id = ? AND indid = ?")) {
                ps.setInt(1, tableId);
                ps.setInt(2, indid);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int[] ids = decodeColIds(rs.getBytes("keys1"));
                        if (ids.length > 0) return ids;
                    }
                }
            }
        }
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT keys1 FROM sysindexes WHERE id = ? AND statid = ?")) {
            ps.setInt(1, tableId);
            ps.setInt(2, statId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int[] ids = decodeColIds(rs.getBytes("keys1"));
                    if (ids.length > 0) return ids;
                }
            }
        } catch (SQLException ignored) {}
        return new int[0];
    }

    private String resolveIndexName(int tableId, int indid, int statId) throws SQLException {
        if (indid > 0) {
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT name FROM sysindexes WHERE id = ? AND indid = ?")) {
                ps.setInt(1, tableId);
                ps.setInt(2, indid);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String n = rs.getString("name");
                        if (n != null && !n.trim().isEmpty()) return n.trim();
                    }
                }
            }
        }
        return "stat#" + statId;
    }

    // -------------------------------------------------------------------------
    //  Low-level helpers
    // -------------------------------------------------------------------------

    /**
     * Reads a binary column, falling back to getBinaryStream for IMAGE columns
     * that jTDS may return null for via getBytes().
     */
    private static byte[] readBytes(ResultSet rs, String col) throws SQLException {
        byte[] b = rs.getBytes(col);
        if (b != null) return b;
        try (InputStream is = rs.getBinaryStream(col)) {
            if (is == null) return null;
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] tmp = new byte[4096];
            int n;
            while ((n = is.read(tmp)) != -1) buf.write(tmp, 0, n);
            return buf.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Decodes colidarray: an array of 2-byte little-endian words, each a colid.
     * No header — just words until a zero word or end of array.
     */
    private static int[] decodeColIds(byte[] arr) {
        if (arr == null) return new int[0];
        List<Integer> ids = new ArrayList<>();
        for (int i = 0; i + 1 < arr.length; i += 2) {
            int id = (arr[i] & 0xFF) | ((arr[i + 1] & 0xFF) << 8);
            if (id == 0) break;
            ids.add(id);
        }
        int[] result = new int[ids.size()];
        for (int i = 0; i < ids.size(); i++) result[i] = ids.get(i);
        return result;
    }

    private static String buildLabel(int[] colIds, Map<Integer, ColumnInfo> cols) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < colIds.length; i++) {
            if (i > 0) sb.append(", ");
            ColumnInfo c = cols.get(colIds[i]);
            sb.append(c != null ? c.name() : "col#" + colIds[i]);
        }
        return sb.toString();
    }

    /** Inverse of decodeColIds: re-encodes a colId array to colidarray bytes. */
    private static byte[] encodeColIds(int[] colIds) {
        if (colIds == null || colIds.length == 0) return null;
        byte[] result = new byte[colIds.length * 2];
        for (int i = 0; i < colIds.length; i++) {
            result[i * 2]     = (byte) (colIds[i]       & 0xFF);
            result[i * 2 + 1] = (byte) ((colIds[i] >> 8) & 0xFF);
        }
        return result;
    }

    private static float bytesToFloat(byte[] b) {
        if (b == null || b.length < 4) return 0f;
        return ByteBuffer.wrap(b, 0, 4).order(ByteOrder.LITTLE_ENDIAN).getFloat();
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    @Override
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) connection.close();
    }
}
