package com.quant.trs;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Builds the period schedule for a leg between the effective and termination dates. */
public final class ScheduleGenerator {

    private ScheduleGenerator() { }

    /** A single accrual / reset period. */
    public record Period(LocalDate start, LocalDate end) { }

    /**
     * Generate consecutive periods from {@code start} to {@code end}.
     * Periods roll forward from the start date; the final period is
     * truncated so it ends exactly on {@code end}.
     */
    public static List<Period> generate(LocalDate start, LocalDate end, Frequency freq) {
        List<Period> periods = new ArrayList<>();
        if (start == null || end == null || !start.isBefore(end)) {
            return periods;
        }
        if (freq == null || freq.months == 0) {            // AT_TERMINATION
            periods.add(new Period(start, end));
            return periods;
        }
        LocalDate current = start;
        int step = 1;
        while (current.isBefore(end)) {
            LocalDate next = start.plusMonths((long) freq.months * step);
            if (next.isAfter(end)) {
                next = end;
            }
            periods.add(new Period(current, next));
            current = next;
            step++;
        }
        return periods;
    }
}
