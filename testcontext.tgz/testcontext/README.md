# Financial Risk Engine — Context Management

Spring Boot + Angular application that manages financial risk engine contexts with
full auditability. Each context references versioned parameter tables through an
association table. Modifying a parameter closes the current context, duplicates it
with a new parameter version, and opens a new one.

The service layer is **parameter-table-agnostic**: adding a new parameter table
requires only a new JPA entity, repository, and `ParameterHandler` bean — no
changes to `ContextService` or `ContextController`.

## Architecture

- **backend/** — Spring Boot 3.2, JPA, SQLite (production) / H2 (tests)
- **frontend/** — JavaFX desktop application (schema-driven)

### Data model

| Table | Purpose |
| --- | --- |
| `contexts` | `id`, `from_date`, `end_date` (nullable), `label` |
| `risk_factor` | `version_id`, `factor_code`, `currency`, `factor_value` |
| `scenario_weight` | `version_id`, `scenario_code`, `weight` |
| `context_association` | one row per (context, parameter table): `context_id`, `parameter_name`, `version_id` |

### Active-context rule

The active context for any requested date is the one with the **highest id** whose
`from_date <= date < end_date` (or `end_date` is `NULL`).

### Adding a new parameter table

Imagine a new `volatility_surface` parameter table is needed. Three steps:

1. **Entity** — `entity/VolatilitySurface.java` with `@Id @GeneratedValue` `versionId`
   and whatever keys + value columns are needed.
2. **Repository** — `repository/VolatilitySurfaceRepository extends JpaRepository<…, Long>`.
3. **Handler** — implement `ParameterHandler` as a `@Component`:
   ```java
   @Component
   @RequiredArgsConstructor
   public class VolatilitySurfaceHandler implements ParameterHandler {
       private final VolatilitySurfaceRepository repository;
       public String name() { return "volatility_surface"; }
       public List<FieldSpec> schema() { return List.of(/* describe fields */); }
       public Long saveNewVersion(Map<String, Object> payload) { /* save new row */ }
       public Map<String, Object> read(Long versionId) { /* read row as map */ }
   }
   ```

Spring auto-discovers the new handler. The REST API, the service, and the
JavaFX UI all pick it up immediately — they iterate over the registered
handlers, and the frontend renders form fields from the schema returned by
`GET /api/parameter-tables`.

## REST API

| Method | Path | Description |
| --- | --- | --- |
| GET    | `/api/parameter-tables` | List registered parameter tables + their field schema |
| GET    | `/api/contexts` | List all contexts |
| GET    | `/api/contexts/active?date=YYYY-MM-DD` | Active context for a date |
| GET    | `/api/contexts/{id}` | One context |
| GET    | `/api/contexts/{id}/versions` | All parameter version ids for a context |
| GET    | `/api/contexts/parameters/{name}/versions/{versionId}` | Read a specific parameter version |
| POST   | `/api/contexts` | Create the initial context (one payload per parameter table) |
| POST   | `/api/contexts/{id}/renew?label=...&from=...` | Close current, duplicate association rows |
| PUT    | `/api/contexts/{id}/parameters/{name}?effectiveDate=...` | Modify one parameter (close + version + renew) |

## Build & run — backend

```bash
cd backend
mvn test          # 34 tests; JaCoCo coverage report at target/site/jacoco/index.html
mvn verify        # also enforces >= 80% coverage rule
mvn spring-boot:run
```

Backend listens on `http://localhost:8080`. SQLite database file is `backend/context.db`
(created on first run).

## Build & run — frontend (JavaFX)

```bash
cd frontend
mvn javafx:run            # launches the desktop application
```

The `javafx-maven-plugin` downloads the platform-specific JavaFX runtime on
first run; no manual SDK install is required. The app talks to
`http://localhost:8080/api` by default — start the backend first. Point it
elsewhere with `CONTEXT_API_BASE`:

```bash
CONTEXT_API_BASE=http://my-host:8080/api mvn javafx:run
```

The list / detail / create tabs render parameter forms dynamically from
`GET /api/parameter-tables`, so a new backend handler shows up in the UI
without touching the JavaFX code.

### Project layout

```
frontend/
├── pom.xml
└── src/main/java/com/riskengine/contextui/
    ├── Launcher.java           – entry point (avoids the "JavaFX runtime
    │                             missing" error when running outside the plugin)
    ├── MainApp.java            – Application; wires the four tabs
    ├── ApiClient.java          – java.net.http.HttpClient + Jackson
    ├── AsyncUtil.java          – Task-based background runner
    ├── Models.java             – record types for the API DTOs
    └── views/
        ├── ContextListView.java
        ├── ActiveContextView.java
        ├── ContextDetailView.java
        ├── CreateInitialView.java
        └── FormBuilder.java     – builds rows of label + TextField from a schema
```

### Tabs

- **All contexts** — TableView of every context with status column; double-click
  a row to open it in the detail tab.
- **Active for date** — DatePicker + Find button; on success shows the resolved
  context and its parameter version map, with a button to open detail.
- **Context detail** — shows the selected context, a TitledPane per parameter
  table for editing (each save closes the context and opens a renewed one),
  and a renew section.
- **Create initial** — bootstrap the very first context with one form section
  per registered parameter table.

## Coverage

JaCoCo is configured to fail the build below 80% instruction coverage on services and
controllers. Current measured coverage is **100%** on those packages
(entities, DTOs and config are intentionally excluded).

## API examples (curl)

Start the backend first (`cd backend && mvn spring-boot:run`), then:

### 1. Discover the registered parameter tables

```bash
curl http://localhost:8080/api/parameter-tables
```

```json
[
  {"name":"risk_factor","schema":[
      {"name":"factorCode","type":"string","required":true},
      {"name":"currency","type":"string","required":true},
      {"name":"value","type":"number","required":true}]},
  {"name":"scenario_weight","schema":[
      {"name":"scenarioCode","type":"string","required":true},
      {"name":"weight","type":"number","required":true}]}
]
```

### 2. Create the initial context

The `parameters` map must contain a payload for every registered handler.

```bash
curl -X POST http://localhost:8080/api/contexts \
  -H 'Content-Type: application/json' \
  -d '{
    "label": "Initial 2026",
    "fromDate": "2026-01-01",
    "parameters": {
      "risk_factor":     {"factorCode":"EUR.IR.1Y","currency":"EUR","value":0.025},
      "scenario_weight": {"scenarioCode":"HIST_2008","weight":0.5}
    }
  }'
```

Response:

```json
{"id":1,"fromDate":"2026-01-01","endDate":null,"label":"Initial 2026"}
```

### 3. List all contexts

```bash
curl http://localhost:8080/api/contexts
```

### 4. Get the active context for a date

```bash
curl 'http://localhost:8080/api/contexts/active?date=2026-05-14'
```

Returns `404` when no context covers that date.

### 5. List parameter version IDs for a context

```bash
curl http://localhost:8080/api/contexts/1/versions
```

```json
{"contextId":1,"versions":{"risk_factor":1,"scenario_weight":1}}
```

### 6. Read a specific parameter version

```bash
curl http://localhost:8080/api/contexts/parameters/risk_factor/versions/1
curl http://localhost:8080/api/contexts/parameters/scenario_weight/versions/1
```

### 7. Modify a parameter

Closes context `1`, creates a new version row through the handler, opens a new
context whose association points to the new version:

```bash
curl -X PUT 'http://localhost:8080/api/contexts/1/parameters/risk_factor?effectiveDate=2026-04-01' \
  -H 'Content-Type: application/json' \
  -d '{"factorCode":"EUR.IR.1Y","currency":"EUR","value":0.030}'
```

Response: the **new** context, e.g.
`{"id":2,"fromDate":"2026-04-01","endDate":null,"label":"Initial 2026 (rev)"}`.

The same endpoint shape works for every registered parameter table — only the
`{name}` segment and the body change:

```bash
curl -X PUT 'http://localhost:8080/api/contexts/2/parameters/scenario_weight?effectiveDate=2026-06-01' \
  -H 'Content-Type: application/json' \
  -d '{"scenarioCode":"HIST_2008","weight":0.75}'
```

### 8. Renew a context (close + duplicate the association as-is)

```bash
curl -X POST 'http://localhost:8080/api/contexts/3/renew?label=Q3%20refresh&from=2026-07-01'
```

Use `--data-urlencode` if the label contains spaces:

```bash
curl -G -X POST http://localhost:8080/api/contexts/3/renew \
  --data-urlencode 'label=Q3 refresh' \
  --data-urlencode 'from=2026-07-01'
```

### 9. Inspect the audit trail

After a few modifications, the history is preserved. The active context for any
date shows which versions were in effect at that point:

```bash
curl http://localhost:8080/api/contexts | jq
curl 'http://localhost:8080/api/contexts/active?date=2026-05-01' | jq
curl 'http://localhost:8080/api/contexts/active?date=2026-08-01' | jq
```

### Notes

- Dates are ISO `YYYY-MM-DD`.
- Modifying a parameter or renewing a context that is already closed returns
  `400 Bad Request` (handled by `GlobalExceptionHandler`). Referencing an unknown
  parameter table name also returns `400`.
- Reading an unknown id (context, parameter version) returns `404 Not Found`.
