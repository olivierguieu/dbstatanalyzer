package com.riskengine.contextui.views;

import com.riskengine.contextui.ApiClient;
import com.riskengine.contextui.AsyncUtil;
import com.riskengine.contextui.Models.ContextDto;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.function.Consumer;

public class ContextListView extends VBox {

    private final ApiClient api;
    private final TableView<ContextDto> table = new TableView<>();
    private final Label status = new Label();

    public ContextListView(ApiClient api, Consumer<Long> openDetail) {
        this.api = api;
        setSpacing(8);
        setPadding(new Insets(12));

        Button refresh = new Button("Refresh");
        refresh.setOnAction(e -> reload());

        Label title = new Label("All contexts");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        HBox toolbar = new HBox(8, title, refresh, status);

        buildColumns();
        table.setItems(FXCollections.observableArrayList());
        table.setRowFactory(tv -> {
            TableRow<ContextDto> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    openDetail.accept(row.getItem().id());
                }
            });
            return row;
        });

        Label hint = new Label("Double-click a row to open the detail view.");
        hint.setStyle("-fx-text-fill: #666;");

        getChildren().addAll(toolbar, table, hint);
        VBox.setVgrow(table, javafx.scene.layout.Priority.ALWAYS);

        reload();
    }

    @SuppressWarnings("unchecked")
    private void buildColumns() {
        TableColumn<ContextDto, Number> id = new TableColumn<>("ID");
        id.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<ContextDto, String> label = new TableColumn<>("Label");
        label.setCellValueFactory(new PropertyValueFactory<>("label"));
        label.setPrefWidth(220);

        TableColumn<ContextDto, String> from = new TableColumn<>("From");
        from.setCellValueFactory(d ->
                new SimpleStringProperty(String.valueOf(d.getValue().fromDate())));

        TableColumn<ContextDto, String> end = new TableColumn<>("End");
        end.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().endDate() == null
                        ? "—" : d.getValue().endDate().toString()));

        TableColumn<ContextDto, String> stat = new TableColumn<>("Status");
        stat.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().endDate() == null ? "active" : "closed"));

        table.getColumns().addAll(id, label, from, end, stat);
    }

    public void reload() {
        status.setText("Loading…");
        AsyncUtil.run(api::listContexts,
                items -> {
                    table.setItems(FXCollections.observableArrayList(items));
                    status.setText(items.size() + " context(s)");
                },
                err -> status.setText("Failed: " + err.getMessage()));
    }
}
