package com.quant.trs;

import java.time.LocalDate;

/**
 * A single cashflow generated for a TRS Equity trade.
 * Fields not relevant to a given leg are left null / zero.
 */
public class Cashflow {

    public LegType legType;
    public PayReceive payReceive;

    public LocalDate paymentDate;
    public LocalDate periodStart;
    public LocalDate periodEnd;

    public double nominal;            // funding: notional; equity: shares * priceStart; dividend: number of shares
    public double rate;               // funding leg all-in rate (index + spread); 0 otherwise
    public double dayCountFraction;   // funding leg accrual fraction; 0 otherwise

    public String currency;
    public double amount;             // signed amount from the booking party's perspective

    public String referenceIndex;     // funding leg only
    public Double priceStart;         // equity performance leg only
    public Double priceEnd;           // equity performance leg only
    public Double dividendPerShare;   // dividend leg only
}
