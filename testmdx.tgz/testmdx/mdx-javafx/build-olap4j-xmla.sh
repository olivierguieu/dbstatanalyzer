#!/usr/bin/env bash
#
# Build the olap4j XMLA *client* driver (olap4j-xmla-1.2.0.jar) from source and
# install it into the local Maven repo. The driver is NOT on Maven Central — only
# the core API is — so this is the dependency-free way to obtain it.
#
# Verified to work on JDK 8 through 21 (anything >= 1.7). It deliberately avoids
# olap4j's Ant/Ivy/subfloor build and the flaky Pentaho repos: it pulls only
# olap4j-core and xercesImpl (both on Central) and compiles just the driver package.
#
# Usage:  ./build-olap4j-xmla.sh
# Result: org.olap4j:olap4j-xmla:1.2.0 in ~/.m2, ready for the pom dependency.

set -euo pipefail

REV=1.2.0
TAG=1.2.0-R
XERCES_VER=2.6.0          # version olap4j's ivy-xmla.xml declares; present on Central
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo ">> 1/5 cloning olap4j source @ $TAG"
git clone --depth 1 --branch "$TAG" https://github.com/olap4j/olap4j.git "$WORK/repo" -q
SRC="$WORK/repo/src"

echo ">> 2/5 fetching compile deps from Maven Central"
mvn -q dependency:get -Dartifact="org.olap4j:olap4j:$REV"
mvn -q dependency:get -Dartifact="xerces:xercesImpl:$XERCES_VER"
CORE="$HOME/.m2/repository/org/olap4j/olap4j/$REV/olap4j-$REV.jar"
XERCES="$HOME/.m2/repository/xerces/xercesImpl/$XERCES_VER/xercesImpl-$XERCES_VER.jar"

echo ">> 3/5 generating the version class the Ant build would normally emit"
# build.xml writes this via <echo>; recreate it so XmlaOlap4jDriver compiles.
cat > "$SRC/org/olap4j/driver/xmla/XmlaOlap4jDriverVersion.java" <<EOF
/* Project version information. Generated - do not modify. */
package org.olap4j.driver.xmla;
class XmlaOlap4jDriverVersion {
    static final String NAME = "olap4j driver for XML/A";
    static final String VERSION = "$REV";
    static final int MAJOR_VERSION = ${REV%%.*};
    static final int MINOR_VERSION = $(echo "$REV" | cut -d. -f2);
}
EOF

echo ">> 4/5 compiling driver package (excluding pre-JDBC-4.1 Factory impls)"
# Only FactoryJdbc41Impl is valid on JDK 1.7+; the JDBC 3 / 4.0 impls don't
# satisfy modern java.sql interfaces and must be left out.
mkdir -p "$WORK/classes"
find "$SRC/org/olap4j/driver" -name '*.java' \
  ! -name 'FactoryJdbc3Impl.java' \
  ! -name 'FactoryJdbc4Impl.java' > "$WORK/sources.txt"
javac -nowarn -cp "$CORE:$XERCES" -d "$WORK/classes" @"$WORK/sources.txt"

echo ">> 5/5 jarring and installing to ~/.m2"
JAR="$WORK/olap4j-xmla-$REV.jar"
jar cf "$JAR" -C "$WORK/classes" org
mvn -q install:install-file -Dfile="$JAR" \
  -DgroupId=org.olap4j -DartifactId=olap4j-xmla -Dversion="$REV" -Dpackaging=jar

echo "OK: org.olap4j:olap4j-xmla:$REV installed."
echo "    (Driver class org.olap4j.driver.xmla.XmlaOlap4jDriver; needs xercesImpl:$XERCES_VER at runtime — declared in pom.xml.)"
