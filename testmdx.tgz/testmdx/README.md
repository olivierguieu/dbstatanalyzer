# testmdx

Run an MDX query against **SQL Server Analysis Services (SSAS)** over XMLA using
**Kerberos/SPNEGO** authentication — no credentials in code — and render the
result in a JavaFX table.

The repo is split into two projects so you can prove the hard part (auth) in
isolation before adding any olap4j/UI complexity.

## Projects

| Directory | What it is | Build / run |
|---|---|---|
| [`kerberos-smoketest/`](kerberos-smoketest/) | Plain-Java sanity check: one XMLA `Discover` over `HttpURLConnection` to verify the Kerberos chain to SSAS works. No olap4j, no UI. | `./run.sh https://ssas.yourcorp.com/olap/msmdpump.dll` |
| [`mdx-javafx/`](mdx-javafx/) | JavaFX app: MDX text box → background olap4j (XMLA) query → `TableView`. Reuses the smoke-test's JVM flags. | `mvn javafx:run` |

Each project has its own README with the full details.

## Recommended order

1. **Validate auth first.** Get a Kerberos ticket (`kinit you@YOURCORP.COM` on
   macOS/Linux; already present on a domain-joined Windows box), edit
   `kerberos-smoketest/krb5.conf` and `jaas.conf`, then run the smoke test. An
   **HTTP 200** with an XMLA `<return>` body means the chain works. See the
   smoke-test README for triaging a **401**.
2. **Then run the app.** With the same `krb5.conf` / `jaas.conf`, build and run
   `mdx-javafx`. Because auth is negotiated by the JVM, olap4j connects with no
   `User`/`Password`.

## Prerequisites

- **JDK 17+** (JavaFX 21 targets `release 17`).
- **Maven** (for `mdx-javafx`).
- A working Kerberos chain to SSAS — SSAS reachable via the IIS `msmdpump` ISAPI
  extension, Windows Authentication with the **Negotiate** provider, and
  **constrained delegation** to the SSAS SPN. Details in the smoke-test README.

## One real snag: the olap4j XMLA driver

Maven Central ships only olap4j *core* — the XMLA client driver
(`XmlaOlap4jDriver`) is in a separate `olap4j-xmla` jar that is **not** on
Central. Build and install it once with the script in `mdx-javafx`:

```bash
cd mdx-javafx
./build-olap4j-xmla.sh   # installs org.olap4j:olap4j-xmla:1.2.0 into ~/.m2
```

After that, `mvn package` / `mvn javafx:run` resolve with no extra repo config.
