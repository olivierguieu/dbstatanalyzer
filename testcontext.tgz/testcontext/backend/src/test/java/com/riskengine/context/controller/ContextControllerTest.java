package com.riskengine.context.controller;

import com.riskengine.context.entity.Context;
import com.riskengine.context.repository.ContextAssociationRepository;
import com.riskengine.context.repository.ContextRepository;
import com.riskengine.context.repository.RiskFactorRepository;
import com.riskengine.context.repository.ScenarioWeightRepository;
import com.riskengine.context.service.ContextService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class ContextControllerTest {

    @Autowired MockMvc mvc;
    @Autowired ContextService service;
    @Autowired ContextRepository contextRepository;
    @Autowired ContextAssociationRepository associationRepository;
    @Autowired RiskFactorRepository riskFactorRepository;
    @Autowired ScenarioWeightRepository scenarioWeightRepository;

    private Context initial;

    @BeforeEach
    void setup() {
        associationRepository.deleteAll();
        contextRepository.deleteAll();
        riskFactorRepository.deleteAll();
        scenarioWeightRepository.deleteAll();

        initial = service.createInitial(
                "Initial",
                LocalDate.of(2026, 1, 1),
                Map.of(
                        "risk_factor", Map.of("factorCode", "EUR.IR.1Y", "currency", "EUR", "value", "0.025"),
                        "scenario_weight", Map.of("scenarioCode", "HIST_2008", "weight", "0.500000")
                )
        );
    }

    @Test
    void parameterTables_returnsRegisteredHandlers() throws Exception {
        mvc.perform(get("/api/parameter-tables"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.name == 'risk_factor')]").exists())
                .andExpect(jsonPath("$[?(@.name == 'scenario_weight')]").exists());
    }

    @Test
    void list_returnsContexts() throws Exception {
        mvc.perform(get("/api/contexts"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].label").value("Initial"));
    }

    @Test
    void active_returnsContext() throws Exception {
        mvc.perform(get("/api/contexts/active").param("date", "2026-03-01"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(initial.getId()));
    }

    @Test
    void active_noMatch_returns404() throws Exception {
        mvc.perform(get("/api/contexts/active").param("date", "2025-01-01"))
                .andExpect(status().isNotFound());
    }

    @Test
    void get_returnsContext() throws Exception {
        mvc.perform(get("/api/contexts/{id}", initial.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.label").value("Initial"));
    }

    @Test
    void versions_returnsAllParameterVersions() throws Exception {
        mvc.perform(get("/api/contexts/{id}/versions", initial.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contextId").value(initial.getId()))
                .andExpect(jsonPath("$.versions.risk_factor").exists())
                .andExpect(jsonPath("$.versions.scenario_weight").exists());
    }

    @Test
    void readParameter_returnsFields() throws Exception {
        Long v = service.getVersions(initial.getId()).get("risk_factor");
        mvc.perform(get("/api/contexts/parameters/{n}/versions/{v}", "risk_factor", v))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.factorCode").value("EUR.IR.1Y"));
    }

    @Test
    void renew_closesAndDuplicates() throws Exception {
        mvc.perform(post("/api/contexts/{id}/renew", initial.getId())
                        .param("label", "Renewed")
                        .param("from", "2026-04-01"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.label").value("Renewed"));
    }

    @Test
    void createInitial_returnsCreatedContext() throws Exception {
        associationRepository.deleteAll();
        contextRepository.deleteAll();
        riskFactorRepository.deleteAll();
        scenarioWeightRepository.deleteAll();

        String body = """
            {
              "label": "Fresh",
              "fromDate": "2026-01-01",
              "parameters": {
                "risk_factor":     {"factorCode":"EUR.IR.1Y","currency":"EUR","value":0.025},
                "scenario_weight": {"scenarioCode":"HIST_2008","weight":0.5}
              }
            }
        """;
        mvc.perform(post("/api/contexts").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.label").value("Fresh"));
    }

    @Test
    void modifyParameter_updates() throws Exception {
        String body = """
            {"factorCode":"EUR.IR.1Y","currency":"EUR","value":0.030}
        """;
        mvc.perform(put("/api/contexts/{id}/parameters/{n}", initial.getId(), "risk_factor")
                        .param("effectiveDate", "2026-04-01")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.label").value("Initial (rev)"));
    }

    @Test
    void modifyParameter_unknownTable_returns400() throws Exception {
        mvc.perform(put("/api/contexts/{id}/parameters/{n}", initial.getId(), "nope")
                        .param("effectiveDate", "2026-04-01")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void renew_alreadyClosed_returns400() throws Exception {
        service.closeAndRenew(initial.getId(), "x", LocalDate.of(2026, 4, 1));
        mvc.perform(post("/api/contexts/{id}/renew", initial.getId())
                        .param("label", "Y")
                        .param("from", "2026-05-01"))
                .andExpect(status().isBadRequest());
    }
}
