package com.quant.trs;

import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class XmlExporterTest {

    private TrsTrade trade() {
        TrsTrade t = new TrsTrade();
        t.tradeId = "TRS-XML";
        t.counterparty = "CP";
        t.underlyingName = "ACME";
        t.currency = "EUR";
        t.numberOfShares = 100_000;
        t.initialPrice = 50.0;
        t.tradeDate = LocalDate.of(2026, 5, 18);
        t.effectiveDate = LocalDate.of(2026, 5, 20);
        t.terminationDate = LocalDate.of(2027, 5, 20);
        t.equityReturnDirection = EquityReturnDirection.RECEIVE;
        t.referenceIndex = "EURIBOR-3M";
        t.indexRate = 0.032;
        t.spread = 0.005;
        t.dayCountConvention = DayCountConvention.ACT_360;
        t.fundingFrequency = Frequency.QUARTERLY;
        t.equityResetFrequency = Frequency.AT_TERMINATION;
        t.dividendPassThrough = 1.0;
        return t;
    }

    private Document parse(String xml) throws Exception {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    void producesWellFormedXmlWithExpectedRoot() throws Exception {
        TrsTrade t = trade();
        List<Cashflow> cfs = new CashflowGenerator().generate(t);
        Document doc = parse(new XmlExporter().toXmlString(t, cfs));

        assertEquals("trsTrade", doc.getDocumentElement().getNodeName());
        assertEquals("TRS-XML",
                doc.getElementsByTagName("tradeId").item(0).getTextContent());
    }

    @Test
    void cashflowCountAttributeMatchesNumberOfElements() throws Exception {
        TrsTrade t = trade();
        List<Cashflow> cfs = new CashflowGenerator().generate(t);
        Document doc = parse(new XmlExporter().toXmlString(t, cfs));

        Element cashflows = (Element) doc.getElementsByTagName("cashflows").item(0);
        assertEquals(cfs.size(), doc.getElementsByTagName("cashflow").getLength());
        assertEquals(String.valueOf(cfs.size()), cashflows.getAttribute("count"));
    }

    @Test
    void everyCashflowCarriesCoreFields() throws Exception {
        TrsTrade t = trade();
        t.dividends.add(new DividendEvent(LocalDate.of(2026, 9, 15), 1.25));
        List<Cashflow> cfs = new CashflowGenerator().generate(t);
        String xml = new XmlExporter().toXmlString(t, cfs);

        for (String tag : List.of("payReceive", "paymentDate", "periodStartDate",
                "periodEndDate", "nominal", "currency", "amount")) {
            assertTrue(xml.contains("<" + tag + ">"), "missing element: " + tag);
        }
    }

    @Test
    void writeFileCreatesReadableXmlOnDisk(@org.junit.jupiter.api.io.TempDir Path dir) throws Exception {
        TrsTrade t = trade();
        List<Cashflow> cfs = new CashflowGenerator().generate(t);
        File out = dir.resolve("trade.xml").toFile();

        new XmlExporter().writeFile(t, cfs, out);

        assertTrue(out.exists() && out.length() > 0);
        Document doc = parse(Files.readString(out.toPath()));
        assertEquals("trsTrade", doc.getDocumentElement().getNodeName());
    }
}
