package com.riskengine.contextui;

import javafx.concurrent.Task;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.Supplier;

public final class AsyncUtil {

    private static final Executor EXEC = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "api-call");
        t.setDaemon(true);
        return t;
    });

    private AsyncUtil() {}

    public static <T> void run(Supplier<T> work,
                                Consumer<T> onSuccess,
                                Consumer<Throwable> onError) {
        Task<T> task = new Task<>() {
            @Override protected T call() { return work.get(); }
        };
        task.setOnSucceeded(e -> onSuccess.accept(task.getValue()));
        task.setOnFailed(e -> onError.accept(task.getException()));
        EXEC.execute(task);
    }
}
