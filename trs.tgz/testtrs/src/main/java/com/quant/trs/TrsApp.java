package com.quant.trs;

import javafx.application.Application;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.time.LocalDate;
import java.util.List;

/**
 * JavaFX application to capture the characteristics of a TRS Equity trade
 * and export the associated cashflows of both legs to an XML file.
 */
public class TrsApp extends Application {

    // --- Trade header / underlier ---
    private final TextField tradeId = new TextField("TRS-0001");
    private final TextField counterparty = new TextField("BANK ABC");
    private final TextField underlyingName = new TextField("ACME EQUITY (ACME.PA)");
    private final ComboBox<String> currency =
            new ComboBox<>(FXCollections.observableArrayList("EUR", "USD", "GBP", "JPY", "CHF"));
    private final TextField numberOfShares = new TextField("100000");
    private final TextField initialPrice = new TextField("50.00");
    private final DatePicker tradeDate = new DatePicker(LocalDate.now());
    private final DatePicker effectiveDate = new DatePicker(LocalDate.now());
    private final DatePicker terminationDate = new DatePicker(LocalDate.now().plusYears(1));

    // --- Legs ---
    private final ComboBox<EquityReturnDirection> equityDir =
            new ComboBox<>(FXCollections.observableArrayList(EquityReturnDirection.values()));
    private final TextField referenceIndex = new TextField("EURIBOR-3M");
    private final TextField indexRate = new TextField("3.20");
    private final TextField spread = new TextField("0.50");
    private final ComboBox<DayCountConvention> dayCount =
            new ComboBox<>(FXCollections.observableArrayList(DayCountConvention.values()));
    private final ComboBox<Frequency> fundingFreq =
            new ComboBox<>(FXCollections.observableArrayList(Frequency.values()));
    private final ComboBox<Frequency> equityFreq =
            new ComboBox<>(FXCollections.observableArrayList(Frequency.values()));
    private final TextField passThrough = new TextField("100");

    // --- Tables ---
    private final ObservableList<DividendEvent> dividends = FXCollections.observableArrayList();
    private final ObservableList<PriceFixing> fixings = FXCollections.observableArrayList();

    private final TextArea output = new TextArea();

    private TrsTrade lastTrade;
    private List<Cashflow> lastCashflows;

    @Override
    public void start(Stage stage) {
        currency.setValue("EUR");
        equityDir.setValue(EquityReturnDirection.RECEIVE);
        dayCount.setValue(DayCountConvention.ACT_360);
        fundingFreq.setValue(Frequency.QUARTERLY);
        equityFreq.setValue(Frequency.AT_TERMINATION);

        VBox sections = new VBox(10,
                tradeSection(), legSection(), dividendSection(), fixingSection());
        sections.setPadding(new Insets(12));
        ScrollPane scroll = new ScrollPane(sections);
        scroll.setFitToWidth(true);

        Button generate = new Button("Generate Cashflows");
        generate.setDefaultButton(true);
        generate.setOnAction(e -> onGenerate());
        Button export = new Button("Export XML…");
        export.setOnAction(e -> onExport(stage));
        HBox actions = new HBox(10, generate, export);
        actions.setPadding(new Insets(8, 12, 4, 12));

        output.setEditable(false);
        output.setPrefRowCount(16);
        output.setStyle("-fx-font-family: 'monospaced';");
        VBox outBox = new VBox(4, new Label("Preview / Log:"), output);
        outBox.setPadding(new Insets(4, 12, 12, 12));
        VBox.setVgrow(output, Priority.ALWAYS);

        BorderPane root = new BorderPane();
        root.setCenter(scroll);
        root.setBottom(new VBox(actions, outBox));

        stage.setScene(new Scene(root, 1000, 880));
        stage.setTitle("TRS Equity – Cashflow Generator");
        stage.show();
    }

    // ----------------------------------------------------------------- form

    private TitledPane tradeSection() {
        GridPane g = grid();
        int r = 0;
        addRow(g, r++, "Trade ID", tradeId);
        addRow(g, r++, "Counterparty", counterparty);
        addRow(g, r++, "Underlying", underlyingName);
        addRow(g, r++, "Currency", currency);
        addRow(g, r++, "Number of shares", numberOfShares);
        addRow(g, r++, "Initial price", initialPrice);
        addRow(g, r++, "Trade date", tradeDate);
        addRow(g, r++, "Effective date (start)", effectiveDate);
        addRow(g, r, "Termination date (end)", terminationDate);
        return section("Trade", g);
    }

    private TitledPane legSection() {
        GridPane g = grid();
        int r = 0;
        addRow(g, r++, "Equity return direction", equityDir);
        addRow(g, r++, "Reference index", referenceIndex);
        addRow(g, r++, "Index rate (%)", indexRate);
        addRow(g, r++, "Spread (%)", spread);
        addRow(g, r++, "Day count convention", dayCount);
        addRow(g, r++, "Funding payment frequency", fundingFreq);
        addRow(g, r++, "Equity reset frequency", equityFreq);
        addRow(g, r, "Dividend pass-through (%)", passThrough);
        return section("Legs", g);
    }

    private TitledPane dividendSection() {
        TableView<DividendEvent> table = new TableView<>(dividends);
        table.setPrefHeight(150);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<DividendEvent, LocalDate> c1 = new TableColumn<>("Ex-date");
        c1.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().exDate));
        TableColumn<DividendEvent, Number> c2 = new TableColumn<>("Dividend / share");
        c2.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().dividendPerShare));
        table.getColumns().add(c1);
        table.getColumns().add(c2);

        DatePicker exDate = new DatePicker();
        TextField amount = new TextField();
        amount.setPromptText("div / share");
        Button add = new Button("Add");
        Button remove = new Button("Remove selected");
        add.setOnAction(e -> {
            try {
                if (exDate.getValue() == null) throw new IllegalArgumentException("ex-date required");
                dividends.add(new DividendEvent(exDate.getValue(),
                        parseDouble(amount.getText(), "Dividend / share")));
                exDate.setValue(null);
                amount.clear();
            } catch (Exception ex) {
                alert("Invalid dividend: " + ex.getMessage());
            }
        });
        remove.setOnAction(e -> {
            DividendEvent sel = table.getSelectionModel().getSelectedItem();
            if (sel != null) dividends.remove(sel);
        });
        HBox input = new HBox(8, new Label("Ex-date:"), exDate, amount, add, remove);
        input.setAlignment(Pos.CENTER_LEFT);

        VBox box = new VBox(8, table, input);
        box.setPadding(new Insets(8));
        return section("Dividend events (pass-through)", box);
    }

    private TitledPane fixingSection() {
        TableView<PriceFixing> table = new TableView<>(fixings);
        table.setPrefHeight(150);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<PriceFixing, LocalDate> c1 = new TableColumn<>("Date");
        c1.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().date));
        TableColumn<PriceFixing, Number> c2 = new TableColumn<>("Equity price");
        c2.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().price));
        table.getColumns().add(c1);
        table.getColumns().add(c2);

        DatePicker date = new DatePicker();
        TextField price = new TextField();
        price.setPromptText("price");
        Button add = new Button("Add");
        Button remove = new Button("Remove selected");
        add.setOnAction(e -> {
            try {
                if (date.getValue() == null) throw new IllegalArgumentException("date required");
                fixings.add(new PriceFixing(date.getValue(), parseDouble(price.getText(), "Equity price")));
                date.setValue(null);
                price.clear();
            } catch (Exception ex) {
                alert("Invalid price fixing: " + ex.getMessage());
            }
        });
        remove.setOnAction(e -> {
            PriceFixing sel = table.getSelectionModel().getSelectedItem();
            if (sel != null) fixings.remove(sel);
        });
        HBox input = new HBox(8, new Label("Date:"), date, price, add, remove);
        input.setAlignment(Pos.CENTER_LEFT);

        VBox box = new VBox(8,
                new Label("Used to value equity performance resets. "
                        + "The effective-date price defaults to the initial price."),
                table, input);
        box.setPadding(new Insets(8));
        return section("Equity price fixings", box);
    }

    // ------------------------------------------------------------- actions

    private void onGenerate() {
        try {
            TrsTrade trade = buildTrade();
            List<Cashflow> cashflows = new CashflowGenerator().generate(trade);
            lastTrade = trade;
            lastCashflows = cashflows;

            String xml = new XmlExporter().toXmlString(trade, cashflows);
            output.setText("Notional = " + trade.notional() + " " + trade.currency + "\n"
                    + "Generated " + cashflows.size() + " cashflow(s).\n\n" + xml);
            output.positionCaret(0);
        } catch (Exception ex) {
            alert("Generation failed: " + ex.getMessage());
        }
    }

    private void onExport(Stage stage) {
        try {
            if (lastCashflows == null) {
                onGenerate();
            }
            if (lastCashflows == null) {
                return;
            }
            FileChooser fc = new FileChooser();
            String id = (lastTrade.tradeId == null || lastTrade.tradeId.isBlank())
                    ? "trs" : lastTrade.tradeId;
            fc.setInitialFileName(id + "_cashflows.xml");
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("XML files", "*.xml"));
            File file = fc.showSaveDialog(stage);
            if (file == null) {
                return;
            }
            new XmlExporter().writeFile(lastTrade, lastCashflows, file);
            output.appendText("\n\nSaved XML to: " + file.getAbsolutePath());
        } catch (Exception ex) {
            alert("Export failed: " + ex.getMessage());
        }
    }

    private TrsTrade buildTrade() {
        TrsTrade t = new TrsTrade();
        t.tradeId = tradeId.getText().trim();
        t.counterparty = counterparty.getText().trim();
        t.underlyingName = underlyingName.getText().trim();
        t.currency = currency.getValue();
        t.numberOfShares = parseDouble(numberOfShares.getText(), "Number of shares");
        t.initialPrice = parseDouble(initialPrice.getText(), "Initial price");
        t.tradeDate = tradeDate.getValue();
        t.effectiveDate = effectiveDate.getValue();
        t.terminationDate = terminationDate.getValue();
        if (t.effectiveDate == null || t.terminationDate == null) {
            throw new IllegalArgumentException("Effective and termination dates are required");
        }
        if (!t.effectiveDate.isBefore(t.terminationDate)) {
            throw new IllegalArgumentException("Effective date must be before termination date");
        }
        t.equityReturnDirection = equityDir.getValue();
        t.referenceIndex = referenceIndex.getText().trim();
        t.indexRate = parseDouble(indexRate.getText(), "Index rate") / 100.0;
        t.spread = parseDouble(spread.getText(), "Spread") / 100.0;
        t.dayCountConvention = dayCount.getValue();
        t.fundingFrequency = fundingFreq.getValue();
        t.equityResetFrequency = equityFreq.getValue();
        t.dividendPassThrough = parseDouble(passThrough.getText(), "Dividend pass-through") / 100.0;
        t.dividends.addAll(dividends);
        t.priceFixings.addAll(fixings);
        return t;
    }

    // -------------------------------------------------------------- helpers

    private static GridPane grid() {
        GridPane g = new GridPane();
        g.setHgap(10);
        g.setVgap(6);
        g.setPadding(new Insets(8));
        ColumnConstraints labelCol = new ColumnConstraints();
        labelCol.setMinWidth(200);
        ColumnConstraints fieldCol = new ColumnConstraints();
        fieldCol.setHgrow(Priority.ALWAYS);
        fieldCol.setFillWidth(true);
        g.getColumnConstraints().addAll(labelCol, fieldCol);
        return g;
    }

    private static void addRow(GridPane g, int row, String label, Control field) {
        g.add(new Label(label), 0, row);
        field.setMaxWidth(Double.MAX_VALUE);
        g.add(field, 1, row);
    }

    private static TitledPane section(String title, javafx.scene.Node content) {
        TitledPane tp = new TitledPane(title, content);
        tp.setCollapsible(false);
        return tp;
    }

    private static double parseDouble(String text, String field) {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException(field + " is required");
        }
        try {
            return Double.parseDouble(text.trim().replace(",", ""));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(field + " must be a number");
        }
    }

    private static void alert(String message) {
        Alert a = new Alert(Alert.AlertType.ERROR, message);
        a.setHeaderText(null);
        a.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
