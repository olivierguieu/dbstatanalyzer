package com.riskengine.contextui;

import com.riskengine.contextui.views.ActiveContextView;
import com.riskengine.contextui.views.ContextDetailView;
import com.riskengine.contextui.views.ContextListView;
import com.riskengine.contextui.views.CreateInitialView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.util.function.Consumer;

public class MainApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        ApiClient api = new ApiClient();
        TabPane tabs = new TabPane();
        Tab listTab = new Tab("All contexts");
        Tab activeTab = new Tab("Active for date");
        Tab detailTab = new Tab("Context detail");
        Tab createTab = new Tab("Create initial");
        for (Tab t : new Tab[]{listTab, activeTab, detailTab, createTab}) t.setClosable(false);
        tabs.getTabs().addAll(listTab, activeTab, detailTab, createTab);

        ContextDetailView detail = new ContextDetailView(api);

        Consumer<Long> openDetail = id -> {
            detail.load(id);
            tabs.getSelectionModel().select(detailTab);
        };

        ContextListView list = new ContextListView(api, openDetail);
        ActiveContextView active = new ActiveContextView(api, openDetail);
        CreateInitialView create = new CreateInitialView(api, id -> {
            openDetail.accept(id);
            list.reload();
        });

        detail.setRefreshList(list::reload);

        listTab.setContent(list);
        activeTab.setContent(active);
        detailTab.setContent(detail);
        createTab.setContent(create);

        BorderPane root = new BorderPane(tabs);
        Label header = new Label("Risk engine — Context management   ·   API: " + api.baseUrl());
        header.setStyle("-fx-padding: 8 12; -fx-background-color: #1f3a5f; "
                + "-fx-text-fill: white; -fx-font-weight: bold;");
        root.setTop(header);

        Scene scene = new Scene(root, 1100, 720);
        stage.setTitle("Risk engine — Context management");
        stage.setScene(scene);
        stage.show();
    }
}
