#!/usr/bin/env bash
# Compile and run the SSAS Kerberos smoke test.
#
# Usage:
#   ./run.sh https://ssas.yourcorp.com/olap/msmdpump.dll
#
# On a domain-joined Windows machine, first make sure you have a ticket:
#   klist                # should show a TGT for krbtgt/YOURCORP.COM
# On macOS/Linux, acquire one with:
#   kinit you@YOURCORP.COM

set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
ENDPOINT="${1:?Usage: ./run.sh <msmdpump-url>}"

javac "$DIR/KerberosXmlaSmokeTest.java"

# The three flags below are what actually wire Kerberos into HttpURLConnection.
# useSubjectCredsOnly=false lets the JGSS layer pull creds from the JAAS entry.
java \
  -Djava.security.krb5.conf="$DIR/krb5.conf" \
  -Djava.security.auth.login.config="$DIR/jaas.conf" \
  -Djavax.security.auth.useSubjectCredsOnly=false \
  -cp "$DIR" \
  KerberosXmlaSmokeTest "$ENDPOINT"

# To debug a failing handshake, add before -cp:
#   -Dsun.security.krb5.debug=true -Dsun.security.spnego.debug=true
