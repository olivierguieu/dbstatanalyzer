package com.oguieu.checksybasestats.db;

import com.oguieu.checksybasestats.model.ColumnInfo;
import com.oguieu.checksybasestats.model.HistogramData;
import com.oguieu.checksybasestats.model.HistogramStep;
import com.oguieu.checksybasestats.model.StatEntry;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.*;

public class SybaseStatisticsDao implements AutoCloseable {

    private final Connection connection;

    public SybaseStatisticsDao(ConnectionConfig config) throws SQLException {
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("jTDS driver not found on classpath", e);
        }
        Properties props = new Properties();
        props.setProperty("user", config.username());
        props.setProperty("password", config.password());
        this.connection = DriverManager.getConnection(config.jdbcUrl(), props);
        try (Statement st = this.connection.createStatement()) {
            st.execute("USE " + config.database());
            st.execute("SET QUOTED_IDENTIFIER ON");
        }
    }

    public List<String> loadTableNames() throws SQLException {
        try (Statement st = connection.createStatement()) {
            try (ResultSet rs = st.executeQuery("SELECT db_name()")) {
                currentDatabase = rs.next() ? rs.getString(1).trim() : "?";
            }
            StringBuilder diag = new StringBuilder("db_name() = ").append(currentDatabase).append("\n\n");
            diag.append("sysobjects type counts:\n");
            try (ResultSet rs = st.executeQuery(
                    "SELECT type, count(*) AS n FROM sysobjects GROUP BY type ORDER BY type")) {
                boolean any = false;
                while (rs.next()) {
                    diag.append("  type='").append(rs.getString("type").trim())
                        .append("'  count=").append(rs.getInt("n")).append("\n");
                    any = true;
                }
                if (!any) diag.append("  (no rows)\n");
            }
            diagnosticInfo = diag.toString();

            List<String> names = new ArrayList<>();
            try (ResultSet rs = st.executeQuery(
                    "SELECT name FROM sysobjects WHERE type = 'U' ORDER BY name")) {
                while (rs.next()) names.add(rs.getString("name").trim());
            }
            if (!names.isEmpty()) return names;

            try (ResultSet rs = connection.getMetaData()
                    .getTables(connection.getCatalog(), null, "%", new String[]{"TABLE"})) {
                while (rs.next()) names.add(rs.getString("TABLE_NAME").trim());
            }
            names.sort(String.CASE_INSENSITIVE_ORDER);
            return names;
        }
    }

    private String diagnosticInfo  = "";
    private String currentDatabase = "";
    public  String getDiagnosticInfo()  { return diagnosticInfo;  }
    public  String getCurrentDatabase() { return currentDatabase; }

    public List<StatEntry> loadStatEntries(String tableName) throws SQLException {
        int tableId = resolveObjectId(tableName);
        if (tableId == 0) throw new SQLException("Table not found: " + tableName);

        Map<Integer, ColumnInfo> cols = loadColumns(tableId);
        List<StatEntry> result = new ArrayList<>();

        String sql = "SELECT statid, indid, colidarray, c0 " +
                     "FROM sysstatistics WHERE id = ? " +
                     "ORDER BY indid, statid, sequence";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tableId);
            try (ResultSet rs = ps.executeQuery()) {
                int lastStatId = Integer.MIN_VALUE;
                while (rs.next()) {
                    int statId = rs.getInt("statid");
                    if (statId == lastStatId) continue;
                    lastStatId = statId;

                    int    indid      = rs.getInt("indid");
                    int[]  colIds     = decodeColIds(readBytes(rs, "colidarray"));

                    // ASE 16: colidarray is null — try sysindexes by indid, then by statid
                    if (colIds.length == 0) colIds = resolveKeyColIds(tableId, indid, statId);

                    String label = colIds.length > 0 ? buildLabel(colIds, cols)
                                                     : resolveIndexName(tableId, indid, statId);
                    byte[] firstChunk = readBytes(rs, "c0");

                    result.add(new StatEntry(statId, indid, colIds, label,
                            0, 0.0, 0.0, 0.0, firstChunk));
                }
            }
        }
        return result;
    }

    public HistogramData buildHistogram(String tableName, StatEntry entry) throws Exception {
        int tableId = resolveObjectId(tableName);
        Map<Integer, ColumnInfo> cols = loadColumns(tableId);

        byte[] blob = assembleBlob(tableId, entry.statId());

        if (blob == null || blob.length == 0) {
            return new HistogramData(tableName, entry.label(), 0, 0, 0, 0,
                    Collections.emptyList());
        }

        // Resolve column: entry may carry empty colIds if colidarray was null at load time
        int[] colIds = entry.colIds().length > 0 ? entry.colIds()
                     : resolveKeyColIds(tableId, entry.indid(), entry.statId());

        ColumnInfo col = colIds.length > 0 ? cols.get(colIds[0]) : null;

        // Absolute fallback: first column of the table
        if (col == null && !cols.isEmpty()) col = cols.values().iterator().next();
        if (col == null) throw new Exception("No column metadata for table id=" + tableId);

        List<HistogramStep> steps = StatBlobParser.parse(blob, Integer.MAX_VALUE, col);
        return new HistogramData(tableName, entry.label(),
                steps.size(), 0.0, 0.0, 0.0, steps);
    }

    // -------------------------------------------------------------------------

    private int resolveObjectId(String tableName) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT id FROM sysobjects WHERE name = ? AND type = 'U'")) {
            ps.setString(1, tableName);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("id") : 0;
            }
        }
    }

    private Map<Integer, ColumnInfo> loadColumns(int tableId) throws SQLException {
        Map<Integer, ColumnInfo> map = new LinkedHashMap<>();
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT colid, name, type, length, prec, scale " +
                "FROM syscolumns WHERE id = ? ORDER BY colid")) {
            ps.setInt(1, tableId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("colid");
                    map.put(id, new ColumnInfo(id,
                            rs.getString("name"),
                            rs.getInt("type"),
                            rs.getInt("length"),
                            rs.getInt("prec"),
                            rs.getInt("scale")));
                }
            }
        }
        return map;
    }

    /**
     * Tries to resolve the first key column ID for a statistics entry.
     * Strategy 1: sysindexes by indid (traditional schema).
     * Strategy 2: sysindexes by statid column (ASE 16 new schema).
     */
    private int[] resolveKeyColIds(int tableId, int indid, int statId) throws SQLException {
        // Strategy 1: match by indid (only meaningful when indid > 0)
        if (indid > 0) {
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT keys1 FROM sysindexes WHERE id = ? AND indid = ?")) {
                ps.setInt(1, tableId);
                ps.setInt(2, indid);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int[] ids = decodeColIds(rs.getBytes("keys1"));
                        if (ids.length > 0) return ids;
                    }
                }
            }
        }

        // Strategy 2: sysindexes may have a statid column in ASE 16
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT keys1 FROM sysindexes WHERE id = ? AND statid = ?")) {
            ps.setInt(1, tableId);
            ps.setInt(2, statId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int[] ids = decodeColIds(rs.getBytes("keys1"));
                    if (ids.length > 0) return ids;
                }
            }
        } catch (SQLException ignored) {
            // sysindexes has no statid column on this version — silently skip
        }

        return new int[0];
    }

    private String resolveIndexName(int tableId, int indid, int statId) throws SQLException {
        if (indid > 0) {
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT name FROM sysindexes WHERE id = ? AND indid = ?")) {
                ps.setInt(1, tableId);
                ps.setInt(2, indid);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String n = rs.getString("name");
                        if (n != null && !n.trim().isEmpty()) return n.trim();
                    }
                }
            }
        }
        return "stat#" + statId;
    }

    private byte[] assembleBlob(int tableId, int statId) throws SQLException {
        StringBuilder colList = new StringBuilder();
        for (int i = 0; i <= 79; i++) {
            if (i > 0) colList.append(", ");
            colList.append("c").append(i);
        }
        String sql = "SELECT " + colList +
                     " FROM sysstatistics WHERE id = ? AND statid = ? ORDER BY sequence";

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tableId);
            ps.setInt(2, statId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    for (int i = 0; i <= 79; i++) {
                        byte[] chunk = readBytes(rs, "c" + i);
                        if (chunk == null || isAllZeros(chunk)) break;
                        try { baos.write(chunk); } catch (java.io.IOException ignored) {}
                    }
                }
            }
        }

        byte[] full = baos.toByteArray();
        int end = full.length;
        while (end > 0 && full[end - 1] == 0) end--;
        return Arrays.copyOf(full, end);
    }

    /**
     * Reads a binary column, falling back to getBinaryStream for IMAGE/TEXT types
     * that jTDS may return null for via getBytes().
     */
    private static byte[] readBytes(ResultSet rs, String col) throws SQLException {
        byte[] b = rs.getBytes(col);
        if (b != null) return b;
        try (InputStream is = rs.getBinaryStream(col)) {
            if (is == null) return null;
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] tmp = new byte[4096];
            int n;
            while ((n = is.read(tmp)) != -1) buf.write(tmp, 0, n);
            return buf.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean isAllZeros(byte[] b) {
        for (byte v : b) if (v != 0) return false;
        return true;
    }

    private static int[] decodeColIds(byte[] arr) {
        if (arr == null) return new int[0];
        List<Integer> ids = new ArrayList<>();
        for (int i = 0; i + 1 < arr.length; i += 2) {
            int id = (arr[i] & 0xFF) | ((arr[i + 1] & 0xFF) << 8);
            if (id == 0) break;
            ids.add(id);
        }
        return ids.stream().mapToInt(Integer::intValue).toArray();
    }

    private static String buildLabel(int[] colIds, Map<Integer, ColumnInfo> cols) {
        StringJoiner sj = new StringJoiner(", ");
        for (int id : colIds) {
            ColumnInfo c = cols.get(id);
            sj.add(c != null ? c.name() : "col#" + id);
        }
        return sj.toString();
    }

    @Override
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) connection.close();
    }
}
