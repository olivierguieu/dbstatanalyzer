package com.oguieu.checksybasestats.model;

public final class StatEntry {
    private final int    statId;
    private final int    indid;
    private final int[]  colIds;
    private final String label;
    private final int    steps;
    private final double density;
    private final double rows;
    private final double rowsSampled;
    private final byte[] statblob;

    public StatEntry(int statId, int indid, int[] colIds, String label, int steps,
                     double density, double rows, double rowsSampled, byte[] statblob) {
        this.statId      = statId;
        this.indid       = indid;
        this.colIds      = colIds;
        this.label       = label;
        this.steps       = steps;
        this.density     = density;
        this.rows        = rows;
        this.rowsSampled = rowsSampled;
        this.statblob    = statblob;
    }

    public int    statId()      { return statId;      }
    public int    indid()       { return indid;       }
    public int[]  colIds()      { return colIds;      }
    public String label()       { return label;       }
    public int    steps()       { return steps;       }
    public double density()     { return density;     }
    public double rows()        { return rows;        }
    public double rowsSampled() { return rowsSampled; }
    public byte[] statblob()    { return statblob;    }

    @Override public String toString() { return label; }
}
