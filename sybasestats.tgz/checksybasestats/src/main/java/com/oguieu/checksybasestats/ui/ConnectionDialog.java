package com.oguieu.checksybasestats.ui;

import com.oguieu.checksybasestats.db.ConnectionConfig;

import javax.swing.*;
import java.awt.*;

public class ConnectionDialog extends JDialog {

    private final JTextField     hostField = new JTextField("localhost", 20);
    private final JTextField     portField = new JTextField("5010", 8);
    private final JTextField     dbField   = new JTextField("testdb", 20);
    private final JTextField     userField = new JTextField("sa", 20);
    private final JPasswordField passField = new JPasswordField("myPassword", 20);

    private ConnectionConfig result = null;

    public ConnectionDialog(Frame parent) {
        super(parent, "Connect to Sybase ASE", true);
        buildUI();
        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    private void buildUI() {
        JPanel fields = new JPanel(new GridBagLayout());
        fields.setBorder(BorderFactory.createEmptyBorder(12, 16, 8, 16));
        GridBagConstraints lc = new GridBagConstraints();
        lc.anchor = GridBagConstraints.WEST;
        lc.insets = new Insets(4, 0, 4, 8);
        GridBagConstraints fc = new GridBagConstraints();
        fc.fill   = GridBagConstraints.HORIZONTAL;
        fc.insets = new Insets(4, 0, 4, 0);
        fc.weightx = 1.0;

        String[] labels = {"Host:", "Port:", "Database:", "User:", "Password:"};
        JComponent[] inputs = {hostField, portField, dbField, userField, passField};
        for (int i = 0; i < labels.length; i++) {
            lc.gridx = 0; lc.gridy = i;
            fc.gridx = 1; fc.gridy = i;
            fields.add(new JLabel(labels[i]), lc);
            fields.add(inputs[i], fc);
        }

        JButton connectBtn = new JButton("Connect");
        JButton cancelBtn  = new JButton("Cancel");
        connectBtn.setPreferredSize(cancelBtn.getPreferredSize());

        connectBtn.addActionListener(e -> {
            try {
                int port = Integer.parseInt(portField.getText().trim());
                result = new ConnectionConfig(
                        hostField.getText().trim(), port,
                        dbField.getText().trim(),
                        userField.getText().trim(),
                        new String(passField.getPassword()));
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                        "Invalid port number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        cancelBtn.addActionListener(e -> dispose());

        // Make Connect the default button
        getRootPane().setDefaultButton(connectBtn);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        buttons.add(cancelBtn);
        buttons.add(connectBtn);

        setLayout(new BorderLayout());
        add(fields,  BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        // Disable Connect until required fields are filled
        Runnable check = new Runnable() {
            public void run() {
                connectBtn.setEnabled(
                        !hostField.getText().trim().isEmpty() &&
                        !dbField.getText().trim().isEmpty()   &&
                        !userField.getText().trim().isEmpty());
            }
        };
        hostField.getDocument().addDocumentListener(new SimpleDocumentListener(check));
        dbField.getDocument().addDocumentListener(new SimpleDocumentListener(check));
        userField.getDocument().addDocumentListener(new SimpleDocumentListener(check));
    }

    public ConnectionConfig showDialog() {
        setVisible(true); // blocks — modal dialog
        return result;
    }

    // Minimal DocumentListener that calls a Runnable on any change
    private static class SimpleDocumentListener implements javax.swing.event.DocumentListener {
        private final Runnable r;
        SimpleDocumentListener(Runnable r) { this.r = r; }
        public void insertUpdate (javax.swing.event.DocumentEvent e) { r.run(); }
        public void removeUpdate (javax.swing.event.DocumentEvent e) { r.run(); }
        public void changedUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
    }
}
