# SSAS Kerberos smoke test

Proves the Kerberos/SPNEGO auth chain from the JVM to an SSAS `msmdpump.dll`
XMLA endpoint **before** you involve olap4j or JavaFX. If this passes, olap4j
will connect with *no* `User`/`Password` — the JVM negotiates Kerberos for you.

## What it does

Sends one XMLA `Discover` (DBSCHEMA_CATALOGS) over `HttpURLConnection`, with no
credentials in code. The JVM answers the IIS `WWW-Authenticate: Negotiate`
challenge using your Kerberos ticket (configured via the JAAS + krb5 flags).

## Prerequisites

1. SSAS reachable over HTTP(S) via the IIS `msmdpump` ISAPI extension.
2. IIS virtual directory set to **Windows Authentication** with the **Negotiate**
   provider enabled (above NTLM).
3. **Constrained delegation** configured in AD so the IIS app-pool account may
   delegate to the SSAS SPN (`MSOLAPSvc.3/ssas.yourcorp.com`). Without this the
   double-hop fails and SSAS sees an anonymous user.
4. A Kerberos ticket on the client:
   - Windows (domain-joined): you already have one — check with `klist`.
   - macOS/Linux: `kinit you@YOURCORP.COM`.

## Run

```bash
./run.sh https://ssas.yourcorp.com/olap/msmdpump.dll
```

Edit `krb5.conf` (realm + KDC) and `jaas.conf` (ticket cache vs. keytab) first.

- **HTTP 200** + an XMLA `<return>` body listing catalogs → the chain works.
- **HTTP 401** → handshake/delegation problem (see below).

## Triaging 401

Re-run with debug on (uncomment in `run.sh`, or add the flags):

```
-Dsun.security.krb5.debug=true -Dsun.security.spnego.debug=true
```

Common causes, in order of likelihood:

| Symptom in debug log | Cause | Fix |
|---|---|---|
| "No valid credentials" / no TGT found | JVM can't see your ticket | `kinit`; check `useTicketCache=true`; set `useSubjectCredsOnly=false` |
| Falls back to NTLM, never Negotiate | IIS offering NTLM first, or no SPN | Register SPN for IIS app-pool acct; enable Negotiate provider |
| Authenticates to IIS but SSAS rejects | Double-hop / no delegation | Configure Kerberos **constrained** delegation to `MSOLAPSvc.3` SPN |
| `Server not found in Kerberos database` | SPN missing/duplicated | `setspn -L` on the service accounts; remove duplicates |
| Ticket "not forwardable" | delegation can't carry identity | `forwardable = true` in krb5.conf; "trust for delegation" in AD |

## Once this passes

In olap4j, keep the **same JVM flags** (`-Djava.security.krb5.conf`,
`-Djava.security.auth.login.config`, `-Djavax.security.auth.useSubjectCredsOnly=false`)
and connect with **no** credentials:

```java
Class.forName("org.olap4j.driver.xmla.XmlaOlap4jDriver");
Connection c = DriverManager.getConnection(
    "jdbc:xmla:Server=https://ssas.yourcorp.com/olap/msmdpump.dll");
```

The stock `XmlaOlap4jHttpProxy` uses the same `HttpURLConnection`, so the
Negotiate handshake works identically.
