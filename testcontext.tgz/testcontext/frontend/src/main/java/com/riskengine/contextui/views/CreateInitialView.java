package com.riskengine.contextui.views;

import com.riskengine.contextui.ApiClient;
import com.riskengine.contextui.AsyncUtil;
import com.riskengine.contextui.Models.ParameterTable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class CreateInitialView extends VBox {

    private final ApiClient api;
    private final Consumer<Long> openDetail;
    private final TextField labelField = new TextField("Initial");
    private final DatePicker fromDate = new DatePicker(LocalDate.now());
    private final VBox tablesBox = new VBox(12);
    private final Label status = new Label();

    private List<ParameterTable> tables = List.of();
    private final Map<String, FormBuilder.Result> forms = new LinkedHashMap<>();

    public CreateInitialView(ApiClient api, Consumer<Long> openDetail) {
        this.api = api;
        this.openDetail = openDetail;

        setSpacing(10);
        setPadding(new Insets(12));

        Label title = new Label("Create initial context");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        HBox topRow = new HBox(8,
                new Label("Label:"), labelField,
                new Label("From date:"), fromDate);

        Button createBtn = new Button("Create");
        createBtn.setOnAction(e -> create());

        Button reloadBtn = new Button("Reload schema");
        reloadBtn.setOnAction(e -> loadSchema());

        getChildren().addAll(title, topRow, new Separator(), tablesBox,
                new HBox(8, createBtn, reloadBtn, status));

        loadSchema();
    }

    private void loadSchema() {
        status.setText("Loading schema…");
        AsyncUtil.run(api::parameterTables,
                ts -> {
                    tables = ts;
                    tablesBox.getChildren().clear();
                    forms.clear();
                    for (ParameterTable t : ts) {
                        Label name = new Label(t.name());
                        name.setStyle("-fx-font-weight: bold;");
                        FormBuilder.Result form = FormBuilder.build(t.schema(), null);
                        forms.put(t.name(), form);
                        tablesBox.getChildren().addAll(name, form.node());
                    }
                    status.setText("");
                },
                err -> status.setText("Schema load failed: " + err.getMessage()));
    }

    private void create() {
        Map<String, Map<String, Object>> payload = new LinkedHashMap<>();
        for (ParameterTable t : tables) {
            payload.put(t.name(),
                    FormBuilder.readValues(forms.get(t.name()).fields(), t.schema()));
        }
        status.setText("Creating…");
        AsyncUtil.run(() -> api.createInitial(labelField.getText(),
                                                fromDate.getValue(),
                                                payload),
                ctx -> {
                    status.setText("Created #" + ctx.id());
                    openDetail.accept(ctx.id());
                },
                err -> status.setText("Failed: " + err.getMessage()));
    }
}
