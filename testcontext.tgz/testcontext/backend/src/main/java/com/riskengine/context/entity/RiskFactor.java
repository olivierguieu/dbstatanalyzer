package com.riskengine.context.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "risk_factor")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RiskFactor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "version_id")
    private Long versionId;

    @Column(nullable = false)
    private String factorCode;

    @Column(nullable = false)
    private String currency;

    @Column(name = "factor_value", nullable = false, precision = 19, scale = 6)
    private BigDecimal value;
}
