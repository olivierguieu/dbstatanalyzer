package com.oguieu.checksybasestats.model;

public final class HistogramStep {
    private final String stepValue;
    private final double eqRows;
    private final double rangeRows;

    public HistogramStep(String stepValue, double eqRows, double rangeRows) {
        this.stepValue = stepValue;
        this.eqRows    = eqRows;
        this.rangeRows = rangeRows;
    }

    public String stepValue() { return stepValue; }
    public double eqRows()    { return eqRows;    }
    public double rangeRows() { return rangeRows; }
    public double totalRows() { return eqRows + rangeRows; }
}
