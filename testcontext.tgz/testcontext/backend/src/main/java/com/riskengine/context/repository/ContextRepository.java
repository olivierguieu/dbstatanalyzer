package com.riskengine.context.repository;

import com.riskengine.context.entity.Context;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;

@Repository
public interface ContextRepository extends JpaRepository<Context, Long> {

    @Query("SELECT c FROM Context c " +
            "WHERE c.fromDate <= :date " +
            "AND (c.endDate IS NULL OR c.endDate > :date) " +
            "ORDER BY c.id DESC LIMIT 1")
    Optional<Context> findActiveContextForDate(@Param("date") LocalDate date);
}
