package com.riskengine.context.service;

import com.riskengine.context.entity.RiskFactor;
import com.riskengine.context.exception.ResourceNotFoundException;
import com.riskengine.context.repository.RiskFactorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class RiskFactorHandler implements ParameterHandler {

    private final RiskFactorRepository repository;

    @Override
    public String name() {
        return "risk_factor";
    }

    @Override
    public List<FieldSpec> schema() {
        return List.of(
                new FieldSpec("factorCode", "string", true),
                new FieldSpec("currency", "string", true),
                new FieldSpec("value", "number", true)
        );
    }

    @Override
    public Long saveNewVersion(Map<String, Object> payload) {
        RiskFactor saved = repository.save(RiskFactor.builder()
                .factorCode(String.valueOf(payload.get("factorCode")))
                .currency(String.valueOf(payload.get("currency")))
                .value(new BigDecimal(String.valueOf(payload.get("value"))))
                .build());
        return saved.getVersionId();
    }

    @Override
    public Map<String, Object> read(Long versionId) {
        RiskFactor rf = repository.findById(versionId)
                .orElseThrow(() -> new ResourceNotFoundException("risk_factor version not found: " + versionId));
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("versionId", rf.getVersionId());
        out.put("factorCode", rf.getFactorCode());
        out.put("currency", rf.getCurrency());
        out.put("value", rf.getValue());
        return out;
    }
}
