package com.quant.trs;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.List;

/**
 * Serialises a {@link TrsTrade} and its cashflows to a simple, readable
 * custom XML schema.
 */
public class XmlExporter {

    /** Build the XML document as a pretty-printed string. */
    public String toXmlString(TrsTrade t, List<Cashflow> cashflows) throws Exception {
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

        Element root = doc.createElement("trsTrade");
        root.setAttribute("product", "EquityTotalReturnSwap");
        root.setAttribute("generated", LocalDate.now().toString());
        doc.appendChild(root);

        // --- Trade header ---
        Element header = child(doc, root, "tradeHeader");
        text(doc, header, "tradeId", t.tradeId);
        text(doc, header, "tradeDate", date(t.tradeDate));
        text(doc, header, "counterparty", t.counterparty);
        text(doc, header, "equityReturnDirection", t.equityReturnDirection.name());

        // --- Equity underlier ---
        Element underlier = child(doc, root, "equityUnderlier");
        text(doc, underlier, "name", t.underlyingName);
        text(doc, underlier, "numberOfShares", num(t.numberOfShares, 4));
        text(doc, underlier, "initialPrice", num(t.initialPrice, 6));
        text(doc, underlier, "currency", t.currency);

        // --- Terms ---
        Element terms = child(doc, root, "terms");
        text(doc, terms, "effectiveDate", date(t.effectiveDate));
        text(doc, terms, "terminationDate", date(t.terminationDate));
        text(doc, terms, "notional", num(t.notional(), 2));
        text(doc, terms, "currency", t.currency);

        Element funding = child(doc, terms, "fundingLeg");
        text(doc, funding, "referenceIndex", t.referenceIndex);
        text(doc, funding, "indexRate", num(t.indexRate, 6));
        text(doc, funding, "spread", num(t.spread, 6));
        text(doc, funding, "allInRate", num(t.indexRate + t.spread, 6));
        text(doc, funding, "dayCountConvention", t.dayCountConvention.name());
        text(doc, funding, "paymentFrequency", t.fundingFrequency.name());

        Element equity = child(doc, terms, "equityLeg");
        text(doc, equity, "resetFrequency", t.equityResetFrequency.name());
        text(doc, equity, "dividendPassThrough", num(t.dividendPassThrough, 4));

        // --- Cashflows ---
        Element cashflowsEl = child(doc, root, "cashflows");
        cashflowsEl.setAttribute("count", String.valueOf(cashflows.size()));
        for (Cashflow c : cashflows) {
            Element e = doc.createElement("cashflow");
            e.setAttribute("type", c.legType.name());
            cashflowsEl.appendChild(e);

            text(doc, e, "payReceive", c.payReceive.name());
            text(doc, e, "paymentDate", date(c.paymentDate));
            text(doc, e, "periodStartDate", date(c.periodStart));
            text(doc, e, "periodEndDate", date(c.periodEnd));
            text(doc, e, "nominal", num(c.nominal, 2));
            if (c.referenceIndex != null) text(doc, e, "referenceIndex", c.referenceIndex);
            if (c.rate != 0.0) text(doc, e, "rate", num(c.rate, 6));
            if (c.dayCountFraction != 0.0) text(doc, e, "dayCountFraction", num(c.dayCountFraction, 6));
            if (c.priceStart != null) text(doc, e, "priceStart", num(c.priceStart, 6));
            if (c.priceEnd != null) text(doc, e, "priceEnd", num(c.priceEnd, 6));
            if (c.dividendPerShare != null) text(doc, e, "dividendPerShare", num(c.dividendPerShare, 6));
            text(doc, e, "currency", c.currency);
            text(doc, e, "amount", num(c.amount, 2));
        }

        Transformer tr = TransformerFactory.newInstance().newTransformer();
        tr.setOutputProperty(OutputKeys.INDENT, "yes");
        tr.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        StringWriter sw = new StringWriter();
        tr.transform(new DOMSource(doc), new StreamResult(sw));
        return sw.toString();
    }

    /** Write the XML document to disk. */
    public void writeFile(TrsTrade t, List<Cashflow> cashflows, File file) throws Exception {
        Files.write(file.toPath(), toXmlString(t, cashflows).getBytes(StandardCharsets.UTF_8));
    }

    private static Element child(Document d, Element parent, String name) {
        Element e = d.createElement(name);
        parent.appendChild(e);
        return e;
    }

    private static void text(Document d, Element parent, String name, String value) {
        Element e = d.createElement(name);
        e.setTextContent(value == null ? "" : value);
        parent.appendChild(e);
    }

    private static String date(LocalDate d) {
        return d == null ? "" : d.toString();
    }

    private static String num(double value, int decimals) {
        return BigDecimal.valueOf(value).setScale(decimals, RoundingMode.HALF_UP).toPlainString();
    }
}
