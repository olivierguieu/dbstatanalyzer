package com.oguieu.checksybasestats.model;

import java.util.List;

public final class HistogramData {
    private final String             tableName;
    private final String             label;
    private final int                steps;
    private final double             density;
    private final double             totalRows;
    private final double             rowsSampled;
    private final List<HistogramStep> histogramSteps;

    public HistogramData(String tableName, String label, int steps, double density,
                         double totalRows, double rowsSampled, List<HistogramStep> histogramSteps) {
        this.tableName      = tableName;
        this.label          = label;
        this.steps          = steps;
        this.density        = density;
        this.totalRows      = totalRows;
        this.rowsSampled    = rowsSampled;
        this.histogramSteps = histogramSteps;
    }

    public String              tableName()      { return tableName;      }
    public String              label()          { return label;          }
    public int                 steps()          { return steps;          }
    public double              density()        { return density;        }
    public double              totalRows()      { return totalRows;      }
    public double              rowsSampled()    { return rowsSampled;    }
    public List<HistogramStep> histogramSteps() { return histogramSteps; }
}
