package com.riskengine.context.repository;

import com.riskengine.context.entity.ContextAssociation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContextAssociationRepository extends JpaRepository<ContextAssociation, Long> {

    List<ContextAssociation> findByContextId(Long contextId);
}
