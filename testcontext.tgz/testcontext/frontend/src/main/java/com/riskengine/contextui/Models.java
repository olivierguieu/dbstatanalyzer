package com.riskengine.contextui;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public final class Models {

    private Models() {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ContextDto(Long id, LocalDate fromDate, LocalDate endDate, String label) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record FieldSpec(String name, String type, boolean required) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ParameterTable(String name, List<FieldSpec> schema) {}

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ContextVersions(Long contextId, Map<String, Long> versions) {}
}
