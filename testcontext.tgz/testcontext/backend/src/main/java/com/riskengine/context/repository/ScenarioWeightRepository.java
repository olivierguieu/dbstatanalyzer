package com.riskengine.context.repository;

import com.riskengine.context.entity.ScenarioWeight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ScenarioWeightRepository extends JpaRepository<ScenarioWeight, Long> {
}
