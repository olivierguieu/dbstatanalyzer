package com.riskengine.context.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Generic association row: one row per (context, parameter table) tuple.
 * Adding a new parameter table requires no schema change here.
 */
@Entity
@Table(name = "context_association",
        uniqueConstraints = @UniqueConstraint(columnNames = {"context_id", "parameter_name"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContextAssociation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "context_id", nullable = false)
    private Long contextId;

    @Column(name = "parameter_name", nullable = false)
    private String parameterName;

    @Column(name = "version_id", nullable = false)
    private Long versionId;
}
