import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Minimal Kerberos/SPNEGO smoke test against an SSAS msmdpump.dll XMLA endpoint.
 *
 * Goal: prove the Kerberos auth chain (desktop TGT -> IIS Negotiate -> SSAS via
 * constrained delegation) works from the JVM, WITHOUT olap4j or JavaFX in the way.
 *
 * It relies on the JVM's built-in HTTP "Negotiate" support in HttpURLConnection.
 * We send NO username/password: the JVM answers the WWW-Authenticate: Negotiate
 * challenge automatically using the Kerberos ticket configured via JAAS.
 *
 * Run (see run.sh / the README for the JVM flags that wire up Kerberos):
 *   javac KerberosXmlaSmokeTest.java
 *   java <kerberos flags> KerberosXmlaSmokeTest "https://ssas.yourcorp.com/olap/msmdpump.dll"
 *
 * A successful run prints HTTP 200 and an XMLA <return> payload listing catalogs.
 * HTTP 401 means the Negotiate handshake or delegation failed (see README triage).
 */
public class KerberosXmlaSmokeTest {

    // XMLA Discover of DBSCHEMA_CATALOGS: the cheapest "can I see anything?" call.
    private static final String DISCOVER_CATALOGS =
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
        "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
          "<soap:Body>" +
            "<Discover xmlns=\"urn:schemas-microsoft-com:xml-analysis\">" +
              "<RequestType>DBSCHEMA_CATALOGS</RequestType>" +
              "<Restrictions><RestrictionList/></Restrictions>" +
              "<Properties><PropertyList/></Properties>" +
            "</Discover>" +
          "</soap:Body>" +
        "</soap:Envelope>";

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Usage: java KerberosXmlaSmokeTest <msmdpump-url>");
            System.exit(2);
        }
        String endpoint = args[0];

        // Helpful when diagnosing the handshake; comment out once it works.
        // (These can also be passed as -D flags instead.)
        // System.setProperty("sun.security.krb5.debug", "true");
        // System.setProperty("sun.security.spnego.debug", "true");

        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15_000);
        conn.setReadTimeout(30_000);
        conn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
        // SOAPAction is required by some msmdpump configurations.
        conn.setRequestProperty("SOAPAction", "\"urn:schemas-microsoft-com:xml-analysis:Discover\"");

        byte[] body = DISCOVER_CATALOGS.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body);
        }

        int code = conn.getResponseCode();
        System.out.println("HTTP status: " + code + " " + conn.getResponseMessage());
        System.out.println("WWW-Authenticate: " + conn.getHeaderField("WWW-Authenticate"));

        InputStream stream = (code >= 200 && code < 400)
            ? conn.getInputStream()
            : conn.getErrorStream();

        String response = stream == null ? "(no body)" : readAll(stream);
        System.out.println("---- response body ----");
        System.out.println(response);

        if (code == 200) {
            System.out.println("\nSUCCESS: Kerberos auth chain to SSAS works. olap4j should now work with NO User/Password.");
        } else if (code == 401) {
            System.out.println("\nFAIL (401): Negotiate handshake or delegation failed. See README 'Triaging 401'.");
        } else {
            System.out.println("\nUnexpected status " + code + " — check the body above for an XMLA fault.");
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int n;
        while ((n = in.read(chunk)) != -1) {
            buf.write(chunk, 0, n);
        }
        return buf.toString(StandardCharsets.UTF_8.name());
    }
}
