package com.riskengine.context.service;

import com.riskengine.context.entity.Context;
import com.riskengine.context.entity.ContextAssociation;
import com.riskengine.context.exception.ResourceNotFoundException;
import com.riskengine.context.repository.ContextAssociationRepository;
import com.riskengine.context.repository.ContextRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Generic context service. Parameter-specific behaviour lives in
 * {@link ParameterHandler} beans, which are auto-discovered via Spring.
 * Adding a new parameter table = add a new entity, repository and handler;
 * <strong>this class never needs to change</strong>.
 */
@Service
@RequiredArgsConstructor
public class ContextService {

    private final ContextRepository contextRepository;
    private final ContextAssociationRepository associationRepository;
    private final List<ParameterHandler> handlers;

    private Map<String, ParameterHandler> handlerByName;

    @PostConstruct
    void indexHandlers() {
        this.handlerByName = handlers.stream()
                .collect(Collectors.toMap(ParameterHandler::name, h -> h));
    }

    public Map<String, ParameterHandler> handlers() {
        return Map.copyOf(handlerByName);
    }

    public ParameterHandler handler(String name) {
        ParameterHandler h = handlerByName.get(name);
        if (h == null) {
            throw new IllegalArgumentException("Unknown parameter table: " + name);
        }
        return h;
    }

    public List<Context> listAll() {
        return contextRepository.findAll();
    }

    public Context getById(Long id) {
        return contextRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Context not found: " + id));
    }

    public Context getActiveContextForDate(LocalDate date) {
        return contextRepository.findActiveContextForDate(date)
                .orElseThrow(() -> new ResourceNotFoundException("No active context for " + date));
    }

    public List<ContextAssociation> getAssociations(Long contextId) {
        getById(contextId); // 404 if missing
        return associationRepository.findByContextId(contextId);
    }

    /** Returns parameter_name → version_id for the context. */
    public Map<String, Long> getVersions(Long contextId) {
        Map<String, Long> out = new LinkedHashMap<>();
        for (ContextAssociation a : getAssociations(contextId)) {
            out.put(a.getParameterName(), a.getVersionId());
        }
        return out;
    }

    public Map<String, Object> readParameter(String parameterName, Long versionId) {
        return handler(parameterName).read(versionId);
    }

    /**
     * Close the current context and open a new one with the same association rows
     * copied over — fully generic over the registered handlers.
     */
    @Transactional
    public Context closeAndRenew(Long currentContextId, String newLabel, LocalDate newFromDate) {
        Context current = getById(currentContextId);
        ensureOpen(current);

        current.setEndDate(newFromDate);
        contextRepository.save(current);

        Context renewed = contextRepository.save(Context.builder()
                .fromDate(newFromDate)
                .endDate(null)
                .label(newLabel)
                .build());

        for (ContextAssociation prev : associationRepository.findByContextId(currentContextId)) {
            associationRepository.save(ContextAssociation.builder()
                    .contextId(renewed.getId())
                    .parameterName(prev.getParameterName())
                    .versionId(prev.getVersionId())
                    .build());
        }
        return renewed;
    }

    /**
     * Modify a single parameter table:
     *  - close the current context
     *  - create a new version row through the handler
     *  - open a new context whose association points to the new version
     *    (other parameters keep their previous version ids)
     */
    @Transactional
    public Context modifyParameter(Long currentContextId,
                                   String parameterName,
                                   Map<String, Object> payload,
                                   LocalDate effectiveDate) {
        ParameterHandler h = handler(parameterName);
        Context current = getById(currentContextId);
        ensureOpen(current);

        List<ContextAssociation> prevAssocs = associationRepository.findByContextId(currentContextId);
        if (prevAssocs.stream().noneMatch(a -> a.getParameterName().equals(parameterName))) {
            throw new IllegalArgumentException(
                    "Context " + currentContextId + " has no association for " + parameterName);
        }

        current.setEndDate(effectiveDate);
        contextRepository.save(current);

        Long newVersionId = h.saveNewVersion(payload);

        Context renewed = contextRepository.save(Context.builder()
                .fromDate(effectiveDate)
                .endDate(null)
                .label(current.getLabel() + " (rev)")
                .build());

        for (ContextAssociation prev : prevAssocs) {
            Long versionId = prev.getParameterName().equals(parameterName)
                    ? newVersionId
                    : prev.getVersionId();
            associationRepository.save(ContextAssociation.builder()
                    .contextId(renewed.getId())
                    .parameterName(prev.getParameterName())
                    .versionId(versionId)
                    .build());
        }
        return renewed;
    }

    /**
     * Create the very first context. The payload is a map from parameter name
     * to its field values; every registered handler must be supplied a payload.
     */
    @Transactional
    public Context createInitial(String label, LocalDate fromDate,
                                  Map<String, Map<String, Object>> parameters) {
        for (String name : handlerByName.keySet()) {
            if (!parameters.containsKey(name)) {
                throw new IllegalArgumentException("Missing parameter payload for: " + name);
            }
        }

        Context created = contextRepository.save(Context.builder()
                .fromDate(fromDate)
                .endDate(null)
                .label(label)
                .build());

        for (Map.Entry<String, Map<String, Object>> entry : parameters.entrySet()) {
            ParameterHandler h = handler(entry.getKey());
            Long versionId = h.saveNewVersion(entry.getValue());
            associationRepository.save(ContextAssociation.builder()
                    .contextId(created.getId())
                    .parameterName(h.name())
                    .versionId(versionId)
                    .build());
        }
        return created;
    }

    private void ensureOpen(Context c) {
        if (c.getEndDate() != null) {
            throw new IllegalArgumentException("Context " + c.getId() + " is already closed");
        }
    }
}
