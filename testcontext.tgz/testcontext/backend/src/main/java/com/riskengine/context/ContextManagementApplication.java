package com.riskengine.context;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContextManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(ContextManagementApplication.class, args);
    }
}
