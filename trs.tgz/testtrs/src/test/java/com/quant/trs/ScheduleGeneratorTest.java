package com.quant.trs;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScheduleGeneratorTest {

    private static final LocalDate START = LocalDate.of(2026, 5, 20);

    @Test
    void quarterlyOverOneYearProducesFourContiguousPeriods() {
        List<ScheduleGenerator.Period> periods =
                ScheduleGenerator.generate(START, START.plusYears(1), Frequency.QUARTERLY);

        assertEquals(4, periods.size());
        assertEquals(START, periods.get(0).start());
        assertEquals(START.plusYears(1), periods.get(3).end());
        for (int i = 1; i < periods.size(); i++) {
            assertEquals(periods.get(i - 1).end(), periods.get(i).start(),
                    "periods must be contiguous");
        }
    }

    @Test
    void atTerminationProducesSingleFullPeriod() {
        List<ScheduleGenerator.Period> periods =
                ScheduleGenerator.generate(START, START.plusYears(2), Frequency.AT_TERMINATION);

        assertEquals(1, periods.size());
        assertEquals(START, periods.get(0).start());
        assertEquals(START.plusYears(2), periods.get(0).end());
    }

    @Test
    void finalPeriodIsTruncatedToTerminationDate() {
        LocalDate end = LocalDate.of(2027, 1, 10);
        List<ScheduleGenerator.Period> periods =
                ScheduleGenerator.generate(START, end, Frequency.QUARTERLY);

        ScheduleGenerator.Period last = periods.get(periods.size() - 1);
        assertEquals(end, last.end());
        assertTrue(last.start().isBefore(last.end()));
    }

    @Test
    void noPeriodsWhenStartNotBeforeEnd() {
        assertTrue(ScheduleGenerator.generate(START, START, Frequency.QUARTERLY).isEmpty());
        assertTrue(ScheduleGenerator.generate(START, START.minusDays(1), Frequency.QUARTERLY).isEmpty());
    }

    @Test
    void monthlyFrequencyProducesTwelvePeriodsOverOneYear() {
        List<ScheduleGenerator.Period> periods =
                ScheduleGenerator.generate(START, START.plusYears(1), Frequency.MONTHLY);
        assertEquals(12, periods.size());
    }
}
