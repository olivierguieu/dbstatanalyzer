package com.oguieu.checksybasestats.db;

public final class ConnectionConfig {
    private final String host;
    private final int    port;
    private final String database;
    private final String username;
    private final String password;

    public ConnectionConfig(String host, int port, String database,
                            String username, String password) {
        this.host     = host;
        this.port     = port;
        this.database = database;
        this.username = username;
        this.password = password;
    }

    public String host()     { return host;     }
    public int    port()     { return port;      }
    public String database() { return database; }
    public String username() { return username; }
    public String password() { return password; }

    public String jdbcUrl() {
        return "jdbc:jtds:sybase://" + host + ":" + port + "/" + database;
    }
}
