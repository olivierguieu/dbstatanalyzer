package com.quant.trs;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * The characteristics of a TRS (Total Return Swap) Equity trade,
 * as captured on the input form. All inputs needed to generate the
 * cashflows of both legs are held here.
 */
public class TrsTrade {

    // --- Trade header ---
    public String tradeId;
    public String counterparty;
    public LocalDate tradeDate;

    // --- Equity underlier ---
    public String underlyingName;
    public String currency = "EUR";
    public double numberOfShares;
    public double initialPrice;

    // --- Terms ---
    public LocalDate effectiveDate;
    public LocalDate terminationDate;

    /** Whether the booking party receives or pays the equity total return. */
    public EquityReturnDirection equityReturnDirection = EquityReturnDirection.RECEIVE;

    // --- Funding leg (floating index + spread) ---
    public String referenceIndex = "EURIBOR-3M";
    public double indexRate;   // decimal, e.g. 0.0320 for 3.20%
    public double spread;      // decimal, e.g. 0.0050 for 0.50%
    public DayCountConvention dayCountConvention = DayCountConvention.ACT_360;
    public Frequency fundingFrequency = Frequency.QUARTERLY;

    // --- Equity leg ---
    public Frequency equityResetFrequency = Frequency.AT_TERMINATION;
    public double dividendPassThrough = 1.0;  // 1.0 = 100%

    public List<DividendEvent> dividends = new ArrayList<>();
    public List<PriceFixing> priceFixings = new ArrayList<>();

    /** Trade notional = number of shares * initial price. */
    public double notional() {
        return numberOfShares * initialPrice;
    }
}
