package com.riskengine.context.controller;

import com.riskengine.context.dto.ContextDto;
import com.riskengine.context.service.ContextService;
import com.riskengine.context.service.ParameterHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ContextController {

    private final ContextService service;

    @GetMapping("/parameter-tables")
    public List<Map<String, Object>> parameterTables() {
        return service.handlers().values().stream()
                .map(h -> {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("name", h.name());
                    m.put("schema", h.schema());
                    return m;
                })
                .toList();
    }

    @GetMapping("/contexts")
    public List<ContextDto> list() {
        return service.listAll().stream().map(ContextDto::from).toList();
    }

    @GetMapping("/contexts/active")
    public ContextDto getActive(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ContextDto.from(service.getActiveContextForDate(date));
    }

    @GetMapping("/contexts/{id}")
    public ContextDto get(@PathVariable Long id) {
        return ContextDto.from(service.getById(id));
    }

    @GetMapping("/contexts/{id}/versions")
    public Map<String, Object> versions(@PathVariable Long id) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("contextId", id);
        out.put("versions", service.getVersions(id));
        return out;
    }

    @GetMapping("/contexts/parameters/{name}/versions/{versionId}")
    public Map<String, Object> readParameter(@PathVariable String name,
                                             @PathVariable Long versionId) {
        return service.readParameter(name, versionId);
    }

    @PostMapping("/contexts")
    public ContextDto createInitial(@RequestBody InitialContextRequest req) {
        return ContextDto.from(service.createInitial(req.label, req.fromDate, req.parameters));
    }

    @PostMapping("/contexts/{id}/renew")
    public ContextDto renew(@PathVariable Long id,
                            @RequestParam String label,
                            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from) {
        return ContextDto.from(service.closeAndRenew(id, label, from));
    }

    @PutMapping("/contexts/{id}/parameters/{name}")
    public ContextDto modifyParameter(@PathVariable Long id,
                                      @PathVariable String name,
                                      @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate effectiveDate,
                                      @RequestBody Map<String, Object> payload) {
        return ContextDto.from(service.modifyParameter(id, name, payload, effectiveDate));
    }

    public static class InitialContextRequest {
        public String label;
        public LocalDate fromDate;
        public Map<String, Map<String, Object>> parameters;
    }
}
