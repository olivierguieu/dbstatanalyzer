Context are a way to store various parameters required for a financial risk engine application. It enables full auditability.

A context is referenced by:
a numeric id, a from date, an end date (may be NULL) and a label

the valid context for any requested date is:
the context with the highest id with "from date" <= "requested date" < "end date" or NULL

each one of the parameter tables contains a version id, a few columns keys (one or more) and a value column

an association table provides for each context , the version ids of each parameter table.

To manage these contexts can you 
- create a set of services to enable to
-- list all contexts 
-- get the active context for a specific date
-- for a specific context list all version id of the parameter tables
-- modifying a context is done by:
--- modifying one of the parameter tables
---- performing a save (after a modification of the parameter table in the GUI) will close the current context, duplicate it and create a new version of the parameter table, a new context containing the newly created id of the parameter table (instead of the old one)
-- close the current context and get a new one by copying all items in the association table 
- a GUI interface to interact with these services (in angular if possible)


Please use Java, spring boot, angular and SQLite for the database.
ensure that unit tests cover at least 80% of the source code


