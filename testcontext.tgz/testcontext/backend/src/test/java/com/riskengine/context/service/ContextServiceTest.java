package com.riskengine.context.service;

import com.riskengine.context.entity.Context;
import com.riskengine.context.entity.ContextAssociation;
import com.riskengine.context.exception.ResourceNotFoundException;
import com.riskengine.context.repository.ContextAssociationRepository;
import com.riskengine.context.repository.ContextRepository;
import com.riskengine.context.repository.RiskFactorRepository;
import com.riskengine.context.repository.ScenarioWeightRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
class ContextServiceTest {

    @Autowired
    ContextService service;
    @Autowired
    ContextRepository contextRepository;
    @Autowired
    ContextAssociationRepository associationRepository;
    @Autowired
    RiskFactorRepository riskFactorRepository;
    @Autowired
    ScenarioWeightRepository scenarioWeightRepository;

    private Context initial;

    @BeforeEach
    void setup() {
        associationRepository.deleteAll();
        contextRepository.deleteAll();
        riskFactorRepository.deleteAll();
        scenarioWeightRepository.deleteAll();

        initial = service.createInitial(
                "Initial",
                LocalDate.of(2026, 1, 1),
                Map.of(
                        "risk_factor", Map.of("factorCode", "EUR.IR.1Y", "currency", "EUR", "value", "0.025"),
                        "scenario_weight", Map.of("scenarioCode", "HIST_2008", "weight", "0.500000")
                )
        );
    }

    @Test
    void createInitial_persistsContextAndOneAssociationPerHandler() {
        assertThat(initial.getId()).isNotNull();
        assertThat(initial.getEndDate()).isNull();
        assertThat(associationRepository.findByContextId(initial.getId())).hasSize(2);
    }

    @Test
    void createInitial_missingParameter_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.createInitial(
                "Bad",
                LocalDate.of(2026, 1, 1),
                Map.of("risk_factor", Map.of("factorCode", "X", "currency", "EUR", "value", "1"))));
    }

    @Test
    void handlersExposed() {
        assertThat(service.handlers()).containsKeys("risk_factor", "scenario_weight");
    }

    @Test
    void handler_unknown_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.handler("nope"));
    }

    @Test
    void listAll_returnsContexts() {
        List<Context> all = service.listAll();
        assertThat(all).hasSize(1);
    }

    @Test
    void getById_missing_throws() {
        assertThrows(ResourceNotFoundException.class, () -> service.getById(99999L));
    }

    @Test
    void getActiveContextForDate_returnsLatestOpen() {
        Context active = service.getActiveContextForDate(LocalDate.of(2026, 3, 1));
        assertThat(active.getId()).isEqualTo(initial.getId());
    }

    @Test
    void getActiveContextForDate_beforeStart_throws() {
        assertThrows(ResourceNotFoundException.class,
                () -> service.getActiveContextForDate(LocalDate.of(2025, 1, 1)));
    }

    @Test
    void getActiveContextForDate_picksHighestIdWhenOverlap() {
        Context c2 = service.closeAndRenew(initial.getId(), "v2", LocalDate.of(2026, 4, 1));
        Context active = service.getActiveContextForDate(LocalDate.of(2026, 5, 1));
        assertThat(active.getId()).isEqualTo(c2.getId());
    }

    @Test
    void getVersions_returnsMap() {
        Map<String, Long> versions = service.getVersions(initial.getId());
        assertThat(versions).containsKeys("risk_factor", "scenario_weight");
        assertThat(versions.values()).allMatch(v -> v != null && v > 0);
    }

    @Test
    void getAssociations_missingContext_throws() {
        assertThrows(ResourceNotFoundException.class, () -> service.getAssociations(99999L));
    }

    @Test
    void readParameter_returnsValues() {
        Long versionId = service.getVersions(initial.getId()).get("risk_factor");
        Map<String, Object> v = service.readParameter("risk_factor", versionId);
        assertThat(v).containsEntry("factorCode", "EUR.IR.1Y");
    }

    @Test
    void readParameter_unknownVersion_throws() {
        assertThrows(ResourceNotFoundException.class,
                () -> service.readParameter("risk_factor", 99999L));
    }

    @Test
    void readParameter_scenarioWeight() {
        Long versionId = service.getVersions(initial.getId()).get("scenario_weight");
        Map<String, Object> v = service.readParameter("scenario_weight", versionId);
        assertThat(v).containsEntry("scenarioCode", "HIST_2008");
    }

    @Test
    void readParameter_scenarioWeight_unknown_throws() {
        assertThrows(ResourceNotFoundException.class,
                () -> service.readParameter("scenario_weight", 99999L));
    }

    @Test
    void closeAndRenew_closesPreviousAndCopiesAllAssociations() {
        Map<String, Long> prevVersions = service.getVersions(initial.getId());

        Context renewed = service.closeAndRenew(initial.getId(), "v2", LocalDate.of(2026, 4, 1));

        Context oldRefreshed = service.getById(initial.getId());
        assertThat(oldRefreshed.getEndDate()).isEqualTo(LocalDate.of(2026, 4, 1));
        assertThat(renewed.getEndDate()).isNull();

        Map<String, Long> newVersions = service.getVersions(renewed.getId());
        assertThat(newVersions).isEqualTo(prevVersions);
    }

    @Test
    void closeAndRenew_alreadyClosed_throws() {
        Context closed = contextRepository.findById(initial.getId()).orElseThrow();
        closed.setEndDate(LocalDate.of(2026, 6, 1));
        contextRepository.save(closed);
        assertThrows(IllegalArgumentException.class,
                () -> service.closeAndRenew(closed.getId(), "x", LocalDate.of(2026, 7, 1)));
    }

    @Test
    void modifyParameter_createsNewVersionAndContext() {
        Map<String, Long> prev = service.getVersions(initial.getId());

        Context renewed = service.modifyParameter(initial.getId(), "risk_factor",
                Map.of("factorCode", "EUR.IR.1Y", "currency", "EUR", "value", "0.030"),
                LocalDate.of(2026, 4, 1));

        Map<String, Long> updated = service.getVersions(renewed.getId());
        assertThat(updated.get("risk_factor")).isNotEqualTo(prev.get("risk_factor"));
        assertThat(updated.get("scenario_weight")).isEqualTo(prev.get("scenario_weight"));

        Map<String, Object> stored = service.readParameter("risk_factor", updated.get("risk_factor"));
        assertThat(new java.math.BigDecimal(stored.get("value").toString()))
                .isEqualByComparingTo("0.030");
    }

    @Test
    void modifyParameter_alreadyClosed_throws() {
        Context closed = contextRepository.findById(initial.getId()).orElseThrow();
        closed.setEndDate(LocalDate.of(2026, 6, 1));
        contextRepository.save(closed);
        assertThrows(IllegalArgumentException.class,
                () -> service.modifyParameter(closed.getId(), "risk_factor",
                        Map.of("factorCode", "X", "currency", "EUR", "value", "1"),
                        LocalDate.of(2026, 7, 1)));
    }

    @Test
    void modifyParameter_unknownTable_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> service.modifyParameter(initial.getId(), "nope",
                        Map.of(), LocalDate.of(2026, 4, 1)));
    }

    @Test
    void modifyParameter_contextWithoutAssociation_throws() {
        // simulate a context that has only one association
        Context ctx = contextRepository.save(Context.builder()
                .fromDate(LocalDate.of(2026, 1, 1)).label("partial").build());
        associationRepository.save(ContextAssociation.builder()
                .contextId(ctx.getId()).parameterName("risk_factor").versionId(1L).build());

        assertThrows(IllegalArgumentException.class,
                () -> service.modifyParameter(ctx.getId(), "scenario_weight",
                        Map.of("scenarioCode", "X", "weight", "1"),
                        LocalDate.of(2026, 4, 1)));
    }

    @Test
    void modifyParameter_scenarioWeight() {
        Map<String, Long> prev = service.getVersions(initial.getId());
        Context renewed = service.modifyParameter(initial.getId(), "scenario_weight",
                Map.of("scenarioCode", "HIST_2008", "weight", "0.75"),
                LocalDate.of(2026, 4, 1));
        Map<String, Long> updated = service.getVersions(renewed.getId());
        assertThat(updated.get("scenario_weight")).isNotEqualTo(prev.get("scenario_weight"));
        assertThat(updated.get("risk_factor")).isEqualTo(prev.get("risk_factor"));
    }
}
