package com.example.monitor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Continuous workload monitor for Sybase ASE, reading the MDA (monitoring)
 * tables over a jTDS JDBC connection.
 *
 * <p>On each interval it samples three areas and prints them like a lightweight
 * "top" for ASE:
 * <ul>
 *   <li>CPU / engine / device I/O  (from monEngine, monDeviceIO)</li>
 *   <li>Locks &amp; contention      (from monLocks / blocking in monProcess)</li>
 *   <li>Sessions &amp; active SQL    (from monProcess + monProcessSQLText)</li>
 * </ul>
 *
 * <p>Engine and I/O figures in the MDA tables are cumulative counters, so the
 * monitor keeps the previous sample and reports the <em>delta</em> per interval,
 * which is what actually reflects current load.
 *
 * <p>Server prerequisites:
 * <pre>
 *   sp_configure 'enable monitoring', 1
 *   sp_configure 'wait event timing', 1
 *   sp_configure 'SQL batch capture', 1
 *   -- and the login needs: sp_role 'grant', mon_role, &lt;login&gt;
 * </pre>
 */
public class AseWorkloadMonitor {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final String url;
    private final String user;
    private final String password;
    private final int intervalSeconds;

    /** Previous cumulative engine counters, keyed by engine number. */
    private Map<Integer, long[]> prevEngine = new LinkedHashMap<>();
    /** Previous total device reads/writes for delta computation. */
    private long[] prevDeviceIO = null;

    public AseWorkloadMonitor(String url, String user, String password, int intervalSeconds) {
        this.url = url;
        this.user = user;
        this.password = password;
        this.intervalSeconds = intervalSeconds;
    }

    public static void main(String[] args) throws Exception {
        // Configuration via environment variables, with CLI overrides:
        //   args: <host> <port> <user> <password> [intervalSeconds]
        String host = envOr("ASE_HOST", arg(args, 0, "localhost"));
        String port = envOr("ASE_PORT", arg(args, 1, "5000"));
        String user = envOr("ASE_USER", arg(args, 2, "sa"));
        String pass = envOr("ASE_PASSWORD", arg(args, 3, ""));
        int interval = Integer.parseInt(envOr("ASE_INTERVAL", arg(args, 4, "10")));

        // jTDS connects to the master db; MDA tables live there.
        String url = String.format("jdbc:jtds:sybase://%s:%s/master", host, port);

        System.out.printf("Connecting to %s as %s, sampling every %ds (Ctrl-C to stop)%n",
                url, user, interval);

        new AseWorkloadMonitor(url, user, pass, interval).run();
    }

    private void run() throws InterruptedException {
        // Driver self-registers, but be explicit so a missing jar fails clearly.
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("jTDS driver not on classpath: " + e.getMessage());
            return;
        }

        while (true) {
            try (Connection con = DriverManager.getConnection(url, user, password)) {
                sampleOnce(con);
            } catch (SQLException e) {
                System.err.printf("[%s] sample failed: %s%n", LocalTime.now().format(TS), e.getMessage());
            }
            Thread.sleep(intervalSeconds * 1000L);
        }
    }

    private void sampleOnce(Connection con) throws SQLException {
        String banner = "═".repeat(72);
        System.out.printf("%n%s%n %s  workload sample%n%s%n",
                banner, LocalTime.now().format(TS), banner);
        reportEngineAndIO(con);
        reportLocksAndContention(con);
        reportSessionsAndSql(con);
    }

    // ---- CPU / engine / device I/O ---------------------------------------

    private void reportEngineAndIO(Connection con) throws SQLException {
        System.out.println("\n── CPU / engines (delta per interval) ──");
        // monEngine: cumulative CPUTime / SystemCPUTime / IdleCPUTime in ticks.
        String engSql =
            "select EngineNumber, CPUTime, SystemCPUTime, IdleCPUTime, Status " +
            "from master..monEngine order by EngineNumber";
        Map<Integer, long[]> current = new LinkedHashMap<>();
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(engSql)) {
            System.out.printf("  %-7s %-10s %10s %10s %10s%n",
                    "engine", "status", "busy%", "user-cpu", "sys-cpu");
            while (rs.next()) {
                int eng = rs.getInt("EngineNumber");
                long cpu = rs.getLong("CPUTime");
                long sys = rs.getLong("SystemCPUTime");
                long idle = rs.getLong("IdleCPUTime");
                String status = rs.getString("Status");
                current.put(eng, new long[]{cpu, sys, idle});

                long[] prev = prevEngine.get(eng);
                if (prev != null) {
                    long dCpu = cpu - prev[0];
                    long dSys = sys - prev[1];
                    long dIdle = idle - prev[2];
                    long total = dCpu + dSys + dIdle;
                    double busy = total > 0 ? 100.0 * (dCpu + dSys) / total : 0.0;
                    System.out.printf("  %-7d %-10s %9.1f%% %10d %10d%n",
                            eng, status, busy, dCpu, dSys);
                } else {
                    System.out.printf("  %-7d %-10s %10s %10s %10s%n",
                            eng, status, "(baseline)", "-", "-");
                }
            }
        }
        prevEngine = current;

        System.out.println("\n── Device I/O (delta per interval) ──");
        // Aggregate reads/writes across all devices for a single throughput line.
        String ioSql =
            "select sum(Reads) Reads, sum(Writes) Writes, sum(IOTime) IOTime " +
            "from master..monDeviceIO";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(ioSql)) {
            if (rs.next()) {
                long reads = rs.getLong("Reads");
                long writes = rs.getLong("Writes");
                long ioTime = rs.getLong("IOTime");
                if (prevDeviceIO != null) {
                    System.out.printf("  reads=%d  writes=%d  io-time-ms=%d%n",
                            reads - prevDeviceIO[0],
                            writes - prevDeviceIO[1],
                            ioTime - prevDeviceIO[2]);
                } else {
                    System.out.println("  (baseline captured)");
                }
                prevDeviceIO = new long[]{reads, writes, ioTime};
            }
        }
    }

    // ---- Locks & contention ----------------------------------------------

    private void reportLocksAndContention(Connection con) throws SQLException {
        System.out.println("\n── Locks & contention ──");
        // Blocking: any process whose BlockingSPID points at another SPID.
        String blockSql =
            "select p.SPID, p.BlockingSPID, p.WaitEventID, p.SecondsWaiting, " +
            "       p.Login, p.Application, p.Command " +
            "from master..monProcess p " +
            "where p.BlockingSPID is not null and p.BlockingSPID > 0 " +
            "order by p.SecondsWaiting desc";
        boolean any = false;
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(blockSql)) {
            while (rs.next()) {
                any = true;
                System.out.printf("  SPID %d blocked by %d for %ds  [%s/%s] %s%n",
                        rs.getInt("SPID"), rs.getInt("BlockingSPID"),
                        rs.getInt("SecondsWaiting"),
                        trim(rs.getString("Login"), 12),
                        trim(rs.getString("Application"), 14),
                        trim(rs.getString("Command"), 16));
            }
        }
        if (!any) System.out.println("  no blocking detected");

        // Total lock count gives a quick contention gauge.
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("select count(*) c from master..monLocks")) {
            if (rs.next()) System.out.printf("  active locks held: %d%n", rs.getInt("c"));
        }
    }

    // ---- Sessions & active SQL -------------------------------------------

    private void reportSessionsAndSql(Connection con) throws SQLException {
        System.out.println("\n── Active sessions & SQL ──");
        // Only running/runnable user processes carrying real work.
        String sql =
            "select p.SPID, p.Login, p.Application, p.Command, " +
            "       p.CPUTime, p.PhysicalReads, p.MemUsageKB, p.SecondsConnected, " +
            "       t.SQLText " +
            "from master..monProcess p " +
            "left join master..monProcessSQLText t on p.SPID = t.SPID " +
            "where p.Command is not null and p.Login is not null " +
            "order by p.CPUTime desc";
        int shown = 0;
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            System.out.printf("  %-6s %-12s %-14s %-10s %8s  %s%n",
                    "SPID", "login", "app", "command", "cpu", "sql");
            while (rs.next() && shown < 15) {
                shown++;
                String sqlText = rs.getString("SQLText");
                System.out.printf("  %-6d %-12s %-14s %-10s %8d  %s%n",
                        rs.getInt("SPID"),
                        trim(rs.getString("Login"), 12),
                        trim(rs.getString("Application"), 14),
                        trim(rs.getString("Command"), 10),
                        rs.getLong("CPUTime"),
                        sqlText == null ? "" : trim(sqlText.replaceAll("\\s+", " "), 60));
            }
        }
        if (shown == 0) System.out.println("  (no active user sessions)");
    }

    // ---- helpers ----------------------------------------------------------

    private static String trim(String s, int max) {
        if (s == null) return "";
        s = s.trim();
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    private static String arg(String[] a, int i, String def) {
        return i < a.length ? a[i] : def;
    }

    private static String envOr(String key, String def) {
        String v = System.getenv(key);
        return v != null && !v.isEmpty() ? v : def;
    }
}
