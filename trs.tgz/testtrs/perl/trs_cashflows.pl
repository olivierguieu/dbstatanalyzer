#!/usr/bin/env perl
#
# trs_cashflows.pl - TRS Equity cashflow generator (Perl port)
#
# Equivalent of the JavaFX application's cashflow logic: given the
# characteristics of a TRS (Total Return Swap) Equity trade, generate the
# cashflows of both legs and emit them as XML.
#
#   Funding leg        : notional * (indexRate + spread) * dayCountFraction
#   Equity performance : numberOfShares * (priceEnd - priceStart)
#   Dividend           : numberOfShares * dividendPerShare * passThrough
#
# Amounts are signed from the booking party's perspective: the party that
# receives the equity total return pays the funding leg and receives the
# dividend pass-through.
#
# Uses only core modules.
#
# Usage:
#   perl trs_cashflows.pl [options] > trade.xml
#
#   --trade-id ID            --counterparty NAME      --underlying NAME
#   --currency CCY           --shares N               --initial-price P
#   --trade-date YYYY-MM-DD  --effective YYYY-MM-DD   --termination YYYY-MM-DD
#   --direction RECEIVE|PAY  --index NAME             --index-rate PCT
#   --spread PCT             --day-count ACT_360|ACT_365|THIRTY_360
#   --funding-freq FREQ      --equity-freq FREQ       --pass-through PCT
#   --dividend YYYY-MM-DD:AMOUNT   (repeatable)
#   --fixing   YYYY-MM-DD:PRICE    (repeatable)
#   --out FILE               (default: stdout)
#
#   FREQ = MONTHLY | QUARTERLY | SEMI_ANNUAL | ANNUAL | AT_TERMINATION
#   Rates and pass-through are entered in percent (3.20 means 3.20%).

use strict;
use warnings;
use Getopt::Long qw(GetOptions);

# --------------------------------------------------------------------------
# Date helpers (ISO YYYY-MM-DD strings; lexical comparison is chronological)
# --------------------------------------------------------------------------

sub split_date { return split /-/, $_[0]; }

sub is_leap {
    my $y = shift;
    return ($y % 4 == 0 && $y % 100 != 0) || ($y % 400 == 0);
}

sub days_in_month {
    my ($y, $m) = @_;
    my @dim = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    return ($m == 2 && is_leap($y)) ? 29 : $dim[$m - 1];
}

# Julian day number - used for actual day counts.
sub jdn {
    my ($y, $m, $d) = @_;
    my $a  = int((14 - $m) / 12);
    my $yy = $y + 4800 - $a;
    my $mm = $m + 12 * $a - 3;
    return $d + int((153 * $mm + 2) / 5) + 365 * $yy
        + int($yy / 4) - int($yy / 100) + int($yy / 400) - 32045;
}

sub actual_days {
    my ($s, $e) = @_;
    return jdn(split_date($e)) - jdn(split_date($s));
}

# Add a number of whole months, clamping the day to the target month length
# (matches java.time.LocalDate::plusMonths).
sub add_months {
    my ($date, $n) = @_;
    my ($y, $m, $d) = split_date($date);
    my $idx = $y * 12 + ($m - 1) + $n;
    my $ny  = int($idx / 12);
    my $nm  = ($idx % 12) + 1;
    my $dim = days_in_month($ny, $nm);
    my $nd  = $d < $dim ? $d : $dim;
    return sprintf("%04d-%02d-%02d", $ny, $nm, $nd);
}

# --------------------------------------------------------------------------
# Day count fractions
# --------------------------------------------------------------------------

sub days_30_360 {
    my ($s, $e) = @_;
    my ($y1, $m1, $d1) = split_date($s);
    my ($y2, $m2, $d2) = split_date($e);
    $d1 = 30 if $d1 == 31;
    $d2 = 30 if ($d2 == 31 && $d1 == 30);
    return 360 * ($y2 - $y1) + 30 * ($m2 - $m1) + ($d2 - $d1);
}

sub day_count_fraction {
    my ($s, $e, $conv) = @_;
    return actual_days($s, $e) / 365.0  if $conv eq 'ACT_365';
    return days_30_360($s, $e) / 360.0  if $conv eq 'THIRTY_360';
    return actual_days($s, $e) / 360.0;   # ACT_360 (default)
}

# --------------------------------------------------------------------------
# Schedule generation
# --------------------------------------------------------------------------

my %FREQ_MONTHS = (
    MONTHLY        => 1,
    QUARTERLY      => 3,
    SEMI_ANNUAL    => 6,
    ANNUAL         => 12,
    AT_TERMINATION => 0,
);

# Returns a list of { start => ..., end => ... } period hashrefs.
sub generate_schedule {
    my ($start, $end, $freq) = @_;
    my @periods;
    return @periods unless defined $start && defined $end && $start lt $end;

    my $months = $FREQ_MONTHS{$freq} // 0;
    if ($months == 0) {                          # AT_TERMINATION
        return ({ start => $start, end => $end });
    }
    my $current = $start;
    my $step    = 1;
    while ($current lt $end) {
        my $next = add_months($start, $months * $step);
        $next = $end if $next gt $end;
        push @periods, { start => $current, end => $next };
        $current = $next;
        $step++;
    }
    return @periods;
}

# --------------------------------------------------------------------------
# Cashflow generation
# --------------------------------------------------------------------------

# Latest price fixing on or before $date, falling back to the initial price.
sub price_at {
    my ($trade, $date) = @_;
    my $price = $trade->{initialPrice};
    my $best  = $trade->{effectiveDate};
    for my $f (@{ $trade->{priceFixings} }) {
        next if $f->{date} gt $date;
        if ($f->{date} ge $best) {
            $best  = $f->{date};
            $price = $f->{price};
        }
    }
    return $price;
}

sub generate_cashflows {
    my ($t) = @_;
    my @cf;

    # +1 if we receive the equity return, -1 if we pay it.
    my $dir_sign  = $t->{equityReturnDirection} eq 'RECEIVE' ? 1 : -1;
    my $equity_pr = $dir_sign > 0 ? 'RECEIVE' : 'PAY';
    my $funding_pr = $dir_sign > 0 ? 'PAY' : 'RECEIVE';

    my $notional   = $t->{numberOfShares} * $t->{initialPrice};
    my $all_in     = $t->{indexRate} + $t->{spread};

    # --- Funding leg ---
    for my $p (generate_schedule($t->{effectiveDate}, $t->{terminationDate},
                                 $t->{fundingFrequency})) {
        my $dcf = day_count_fraction($p->{start}, $p->{end}, $t->{dayCountConvention});
        push @cf, {
            legType          => 'FUNDING',
            payReceive       => $funding_pr,
            paymentDate      => $p->{end},
            periodStart      => $p->{start},
            periodEnd        => $p->{end},
            nominal          => $notional,
            rate             => $all_in,
            dayCountFraction => $dcf,
            referenceIndex   => $t->{referenceIndex},
            currency         => $t->{currency},
            amount           => -$dir_sign * $notional * $all_in * $dcf,
        };
    }

    # --- Equity performance leg ---
    for my $p (generate_schedule($t->{effectiveDate}, $t->{terminationDate},
                                 $t->{equityResetFrequency})) {
        my $ps = price_at($t, $p->{start});
        my $pe = price_at($t, $p->{end});
        push @cf, {
            legType     => 'EQUITY_PERFORMANCE',
            payReceive  => $equity_pr,
            paymentDate => $p->{end},
            periodStart => $p->{start},
            periodEnd   => $p->{end},
            nominal     => $t->{numberOfShares} * $ps,
            priceStart  => $ps,
            priceEnd    => $pe,
            currency    => $t->{currency},
            amount      => $dir_sign * $t->{numberOfShares} * ($pe - $ps),
        };
    }

    # --- Dividend pass-through ---
    for my $d (@{ $t->{dividends} }) {
        next if $d->{exDate} lt $t->{effectiveDate}
             || $d->{exDate} gt $t->{terminationDate};
        push @cf, {
            legType         => 'DIVIDEND',
            payReceive      => $equity_pr,
            paymentDate     => $d->{exDate},
            periodStart     => $d->{exDate},
            periodEnd       => $d->{exDate},
            nominal         => $t->{numberOfShares},
            dividendPerShare => $d->{dividendPerShare},
            currency        => $t->{currency},
            amount          => $dir_sign * $t->{numberOfShares}
                                 * $d->{dividendPerShare} * $t->{dividendPassThrough},
        };
    }

    @cf = sort {
        $a->{paymentDate} cmp $b->{paymentDate}
            || $a->{legType} cmp $b->{legType}
    } @cf;
    return @cf;
}

# --------------------------------------------------------------------------
# XML output
# --------------------------------------------------------------------------

sub xml_escape {
    my $s = shift // '';
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    return $s;
}

sub num {
    my ($v, $dp) = @_;
    return sprintf("%.${dp}f", $v);
}

# <name>value</name> at the given indent level.
sub tag {
    my ($indent, $name, $value) = @_;
    return ('  ' x $indent) . "<$name>" . xml_escape($value) . "</$name>\n";
}

sub to_xml {
    my ($t, @cf) = @_;
    my $notional = $t->{numberOfShares} * $t->{initialPrice};
    my @today    = (localtime)[5, 4, 3];
    my $today    = sprintf("%04d-%02d-%02d", $today[0] + 1900, $today[1] + 1, $today[2]);

    my $xml = qq{<?xml version="1.0" encoding="UTF-8"?>\n};
    $xml .= qq{<trsTrade product="EquityTotalReturnSwap" generated="$today">\n};

    $xml .= "  <tradeHeader>\n";
    $xml .= tag(2, 'tradeId',               $t->{tradeId});
    $xml .= tag(2, 'tradeDate',             $t->{tradeDate});
    $xml .= tag(2, 'counterparty',          $t->{counterparty});
    $xml .= tag(2, 'equityReturnDirection', $t->{equityReturnDirection});
    $xml .= "  </tradeHeader>\n";

    $xml .= "  <equityUnderlier>\n";
    $xml .= tag(2, 'name',           $t->{underlyingName});
    $xml .= tag(2, 'numberOfShares', num($t->{numberOfShares}, 4));
    $xml .= tag(2, 'initialPrice',   num($t->{initialPrice}, 6));
    $xml .= tag(2, 'currency',       $t->{currency});
    $xml .= "  </equityUnderlier>\n";

    $xml .= "  <terms>\n";
    $xml .= tag(2, 'effectiveDate',   $t->{effectiveDate});
    $xml .= tag(2, 'terminationDate', $t->{terminationDate});
    $xml .= tag(2, 'notional',        num($notional, 2));
    $xml .= tag(2, 'currency',        $t->{currency});
    $xml .= "    <fundingLeg>\n";
    $xml .= tag(3, 'referenceIndex',     $t->{referenceIndex});
    $xml .= tag(3, 'indexRate',          num($t->{indexRate}, 6));
    $xml .= tag(3, 'spread',             num($t->{spread}, 6));
    $xml .= tag(3, 'allInRate',          num($t->{indexRate} + $t->{spread}, 6));
    $xml .= tag(3, 'dayCountConvention', $t->{dayCountConvention});
    $xml .= tag(3, 'paymentFrequency',   $t->{fundingFrequency});
    $xml .= "    </fundingLeg>\n";
    $xml .= "    <equityLeg>\n";
    $xml .= tag(3, 'resetFrequency',      $t->{equityResetFrequency});
    $xml .= tag(3, 'dividendPassThrough', num($t->{dividendPassThrough}, 4));
    $xml .= "    </equityLeg>\n";
    $xml .= "  </terms>\n";

    $xml .= '  <cashflows count="' . scalar(@cf) . "\">\n";
    for my $c (@cf) {
        $xml .= '    <cashflow type="' . xml_escape($c->{legType}) . "\">\n";
        $xml .= tag(3, 'payReceive',      $c->{payReceive});
        $xml .= tag(3, 'paymentDate',     $c->{paymentDate});
        $xml .= tag(3, 'periodStartDate', $c->{periodStart});
        $xml .= tag(3, 'periodEndDate',   $c->{periodEnd});
        $xml .= tag(3, 'nominal',         num($c->{nominal}, 2));
        $xml .= tag(3, 'referenceIndex',  $c->{referenceIndex}) if defined $c->{referenceIndex};
        $xml .= tag(3, 'rate',            num($c->{rate}, 6))
            if defined $c->{rate} && $c->{rate} != 0;
        $xml .= tag(3, 'dayCountFraction', num($c->{dayCountFraction}, 6))
            if defined $c->{dayCountFraction} && $c->{dayCountFraction} != 0;
        $xml .= tag(3, 'priceStart',      num($c->{priceStart}, 6)) if defined $c->{priceStart};
        $xml .= tag(3, 'priceEnd',        num($c->{priceEnd}, 6))   if defined $c->{priceEnd};
        $xml .= tag(3, 'dividendPerShare', num($c->{dividendPerShare}, 6))
            if defined $c->{dividendPerShare};
        $xml .= tag(3, 'currency',        $c->{currency});
        $xml .= tag(3, 'amount',          num($c->{amount}, 2));
        $xml .= "    </cashflow>\n";
    }
    $xml .= "  </cashflows>\n";
    $xml .= "</trsTrade>\n";
    return $xml;
}

# --------------------------------------------------------------------------
# Main - trade defaults, command-line overrides, run
# --------------------------------------------------------------------------

my %trade = (
    tradeId               => 'TRS-0001',
    counterparty          => 'BANK ABC',
    tradeDate             => '2026-05-18',
    underlyingName        => 'ACME EQUITY (ACME.PA)',
    currency              => 'EUR',
    numberOfShares        => 100000,
    initialPrice          => 50.00,
    effectiveDate         => '2026-05-20',
    terminationDate       => '2027-05-20',
    equityReturnDirection => 'RECEIVE',
    referenceIndex        => 'EURIBOR-3M',
    indexRate             => 0.0320,   # decimal
    spread                => 0.0050,   # decimal
    dayCountConvention    => 'ACT_360',
    fundingFrequency      => 'QUARTERLY',
    equityResetFrequency  => 'AT_TERMINATION',
    dividendPassThrough   => 1.0,
    dividends             => [],
    priceFixings          => [],
);

my (@div_opt, @fix_opt, $out_file);
my ($index_rate_pct, $spread_pct, $pass_through_pct);

GetOptions(
    'trade-id=s'      => \$trade{tradeId},
    'counterparty=s'  => \$trade{counterparty},
    'underlying=s'    => \$trade{underlyingName},
    'currency=s'      => \$trade{currency},
    'shares=f'        => \$trade{numberOfShares},
    'initial-price=f' => \$trade{initialPrice},
    'trade-date=s'    => \$trade{tradeDate},
    'effective=s'     => \$trade{effectiveDate},
    'termination=s'   => \$trade{terminationDate},
    'direction=s'     => \$trade{equityReturnDirection},
    'index=s'         => \$trade{referenceIndex},
    'index-rate=f'    => \$index_rate_pct,
    'spread=f'        => \$spread_pct,
    'day-count=s'     => \$trade{dayCountConvention},
    'funding-freq=s'  => \$trade{fundingFrequency},
    'equity-freq=s'   => \$trade{equityResetFrequency},
    'pass-through=f'  => \$pass_through_pct,
    'dividend=s'      => \@div_opt,
    'fixing=s'        => \@fix_opt,
    'out=s'           => \$out_file,
    'help'            => sub { exec('perldoc', '-t', $0) or print_usage(); exit 0; },
) or die "Invalid options. See --help.\n";

# Percent inputs -> decimal.
$trade{indexRate}           = $index_rate_pct / 100.0   if defined $index_rate_pct;
$trade{spread}              = $spread_pct / 100.0       if defined $spread_pct;
$trade{dividendPassThrough} = $pass_through_pct / 100.0 if defined $pass_through_pct;

for my $d (@div_opt) {
    my ($date, $amt) = split /:/, $d, 2;
    die "Bad --dividend '$d' (expected YYYY-MM-DD:AMOUNT)\n" unless defined $amt;
    push @{ $trade{dividends} }, { exDate => $date, dividendPerShare => $amt + 0 };
}
for my $f (@fix_opt) {
    my ($date, $price) = split /:/, $f, 2;
    die "Bad --fixing '$f' (expected YYYY-MM-DD:PRICE)\n" unless defined $price;
    push @{ $trade{priceFixings} }, { date => $date, price => $price + 0 };
}

die "Effective date must be before termination date\n"
    unless $trade{effectiveDate} lt $trade{terminationDate};

my @cashflows = generate_cashflows(\%trade);
my $xml       = to_xml(\%trade, @cashflows);

if (defined $out_file) {
    open(my $fh, '>', $out_file) or die "Cannot write $out_file: $!\n";
    print {$fh} $xml;
    close($fh);
    print STDERR "Generated " . scalar(@cashflows) . " cashflow(s) -> $out_file\n";
} else {
    print $xml;
}

sub print_usage {
    print STDERR "See the comment header of $0 for usage.\n";
}
